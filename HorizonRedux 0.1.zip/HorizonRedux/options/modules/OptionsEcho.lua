--[[
    Horizon Suite - Echo - Options page
    One dashboard category for Echo. Every setting is in ECHO_KEYS, so a change re-applies
    through Echo.ApplyOptions (options/OptionsData.lua) without a reload.
]]
local addon = _G.HorizonSuite
if not addon or not addon.OptionCategories then return end
local L = addon.L
local function getDB(k, d) return addon.OptionsData_GetDB(k, d) end
local function setDB(k, v) addon.OptionsData_SetDB(k, v) end
local Section, Button, Toggle = addon.Section, addon.Button, addon.Toggle
-- The dashboard's reload prompt: shown while a reload is recommended.
local ReloadPrompt = addon.ModuleReloadPrompt or function(opts)
    local t = { type = "moduleReloadPrompt" }
    for k, v in pairs(opts or {}) do t[k] = v end
    return t
end
local D   = addon.ECHO_DEFAULTS
local LIM = addon.ECHO_LIMITS
if not D or not LIM then return end

local function clamp(v, key)
    local lim = LIM[key]
    return math.max(lim.min, math.min(lim.max, v))
end

local function Echo() return addon.Echo end

-- Style picker entries come from the shared ToastStyles registry.
local function toastStyleOptions()
    local TS = addon.Augment and addon.Augment.ToastStyles
    return TS and TS.StyleOptions(L) or {}
end

local WHISPER_SOUND_OPTIONS = {
    { L["ECHO_SOUND_BLIZZARD"], "blizzard" },
    { L["ECHO_SOUND_TOAST"],    "toast"    },
    { L["ECHO_SOUND_PING"],     "ping"     },
    { L["ECHO_SOUND_OFF"],      "off"      },
}

local COMBAT_LOG_OPTIONS = {
    { L["ECHO_COMBAT_LOG_ECHO"],     "echo"     },
    { L["ECHO_COMBAT_LOG_BLIZZARD"], "blizzard" },
    { L["ECHO_COMBAT_LOG_HIDE"],     "hide"     },
}

local TIER_OPTIONS = {
    { L["ECHO_TIER_LOUD"],  "loud"  },
    { L["ECHO_TIER_COUNT"], "count" },
    { L["ECHO_TIER_QUIET"], "quiet" },
    { L["ECHO_TIER_MUTED"], "muted" },
}

local HISTORY_DAYS_OPTIONS = {
    { L["ECHO_HISTORY_DAYS_7"],  7  },
    { L["ECHO_HISTORY_DAYS_30"], 30 },
    { L["ECHO_HISTORY_DAYS_90"], 90 },
    { L["ECHO_HISTORY_FOREVER"], 0  },
}

local function TierDropdown(kind, label)
    local key = addon.Echo.TierKey(kind)
    return { type = "dropdown", name = label, desc = L["ECHO_TIER_DESC"], tooltip = L["ECHO_TIER_TIP"], dbKey = key,
        options = TIER_OPTIONS, preserveOrder = true,
        get = function() return getDB(key, D[key]) end,
        set = function(v) setDB(key, v) end }
end

local function IntSlider(key, name, desc, step)
    return { type = "slider", name = name, desc = desc, dbKey = key,
        min = LIM[key].min, max = LIM[key].max, step = step,
        get = function() return tonumber(getDB(key, D[key])) or D[key] end,
        set = function(v) setDB(key, clamp(math.floor(v + 0.5), key)) end }
end

addon.RegisterModulePages("echo", {
    { key = "feeds", name = L["ECHO_PAGE_FEEDS"] },
})

local options = {
    Section(L["ECHO_SECTION_GENERAL"], { page = "layout", card = "position" }),
    { type = "dropdown", name = L["ECHO_COLUMN_EDGE"], desc = L["ECHO_COLUMN_EDGE_DESC"], dbKey = "echoColumnEdge",
      options = { { L["ECHO_EDGE_AUTO"], "auto" }, { L["ECHO_EDGE_RIGHT"], "right" }, { L["ECHO_EDGE_LEFT"], "left" } },
      preserveOrder = true,
      get = function() return getDB("echoColumnEdge", D.echoColumnEdge) end,
      set = function(v)
          if v == "left" or v == "right" then
              setDB("echoX", nil)
              setDB("echoY", nil)
              setDB("echoColumnEdge", v)
          else
              setDB("echoColumnEdge", "auto")
          end
      end },
    Toggle(L["ECHO_LOCK"], L["ECHO_LOCK_DESC"], "echoLockPosition", D.echoLockPosition),
    Button(L["AXIS_RESET_POSITION"], L["ECHO_RESET_POSITION_DESC"], function()
        setDB("echoX", nil)
        setDB("echoY", nil)
    end),
    { type = "dropdown", name = L["ECHO_STRATA"], desc = L["ECHO_STRATA_DESC"], dbKey = "echoFrameStrata",
      options = {
          { L["FOCUS_STRATA_BACKGROUND"], "BACKGROUND" }, { L["FOCUS_STRATA_LOW"], "LOW" },
          { L["FOCUS_STRATA_MEDIUM"], "MEDIUM" }, { L["FOCUS_STRATA_HIGH"], "HIGH" },
          { L["ECHO_STRATA_DIALOG"], "DIALOG" },
      }, preserveOrder = true,
      get = function() return getDB("echoFrameStrata", D.echoFrameStrata) end,
      set = function(v) setDB("echoFrameStrata", v) end },
    Section(L["ECHO_SECTION_GENERAL"], { page = "layout", card = "size" }),
    { type = "slider", name = L["ECHO_SCALE"], desc = L["ECHO_SCALE_DESC"], dbKey = "echoScale",
      min = LIM.echoScale.min * 100, max = LIM.echoScale.max * 100, step = 5,
      get = function() return math.floor((tonumber(getDB("echoScale", D.echoScale)) or 1) * 100 + 0.5) end,
      set = function(v) setDB("echoScale", clamp(v / 100, "echoScale")) end },
    Section(L["ECHO_SECTION_GENERAL"], { page = "general", card = "behaviour" }),
    IntSlider("echoMaxTiles", L["ECHO_MAX_TILES"], L["ECHO_MAX_TILES_DESC"], 1),
    { type = "dropdown", name = L["ECHO_COLLAPSE"], desc = L["ECHO_COLLAPSE_DESC"], dbKey = "echoCollapse",
      options = {
          { L["ECHO_COLLAPSE_OFF"], "off" }, { L["ECHO_COLLAPSE_ALL"], "all" },
          { L["ECHO_COLLAPSE_KEEPNEW"], "keepnew" },
      }, preserveOrder = true,
      get = function() return getDB("echoCollapse", D.echoCollapse) end,
      set = function(v) setDB("echoCollapse", v) end },

    -- New-message pop-ups: how they look and behave. Which chats pop up is set per chat type
    -- on Feeds & groups › Alerts by chat type.
    Section(L["ECHO_SECTION_POPUPS"], { page = "general", card = "notifications" }),
    { type = "dropdown", name = L["ECHO_TOAST_STYLE"], desc = L["ECHO_TOAST_STYLE_DESC"], dbKey = "echoToastStyle",
      options = toastStyleOptions(), preserveOrder = true,
      get = function() return getDB("echoToastStyle", D.echoToastStyle) end,
      set = function(v) setDB("echoToastStyle", v) end },
    IntSlider("echoToastSeconds", L["ECHO_TOAST_SECONDS"], L["ECHO_TOAST_SECONDS_DESC"], 1),
    Toggle(L["ECHO_HOLD_IN_COMBAT"], L["ECHO_HOLD_IN_COMBAT_DESC"], "echoHoldToastsInCombat", D.echoHoldToastsInCombat),
    -- Echo plays its own whisper sound only for whispers it hides from Blizzard's chat
    -- (EchoFilter). Anywhere else Blizzard's sound plays, so these rows follow "Hide stored
    -- whispers" (itself shown only while Blizzard's chat is shown) and the card hides with them.
    Section(L["ECHO_SECTION_SOUNDS"], { page = "general", card = "sounds" }),
    { type = "dropdown", name = L["ECHO_WHISPER_SOUND"], desc = L["ECHO_WHISPER_SOUND_DESC"], dbKey = "echoWhisperSound",
      options = WHISPER_SOUND_OPTIONS, preserveOrder = true, parent = "echoHideStoredWhispers",
      get = function() return getDB("echoWhisperSound", D.echoWhisperSound) end,
      set = function(v) setDB("echoWhisperSound", v) end },
    (function()
        local b = Button(L["ECHO_SOUND_PREVIEW"], L["ECHO_SOUND_PREVIEW_DESC"], function()
            local E = Echo()
            if E and E.Sound then E.Sound.Whisper(false, true) end
        end)
        b.dbKey = "__echoSoundPreview"  -- a row id for the parent link; buttons save nothing
        b.parent = "echoHideStoredWhispers"
        return b
    end)(),
    Toggle(L["ECHO_SOUND_IN_COMBAT"], L["ECHO_SOUND_IN_COMBAT_DESC"], "echoSoundInCombat", D.echoSoundInCombat,
        { parent = "echoHideStoredWhispers" }),
    Toggle(L["ECHO_SOUND_BNET"], L["ECHO_SOUND_BNET_DESC"], "echoSoundBnet", D.echoSoundBnet,
        { parent = "echoHideStoredWhispers" }),

    Section(L["ECHO_SECTION_TIERS"], { page = "feeds" }),
    TierDropdown("whisper",  L["ECHO_KIND_WHISPER"]),
    TierDropdown("bnet",     L["ECHO_KIND_BNET"]),
    TierDropdown("party",    L["ECHO_KIND_PARTY"]),
    TierDropdown("raid",     L["ECHO_KIND_RAID"]),
    TierDropdown("instance", L["ECHO_KIND_INSTANCE"]),
    TierDropdown("guild",    L["ECHO_KIND_GUILD"]),
    TierDropdown("officer",  L["ECHO_KIND_OFFICER"]),
    TierDropdown("channel",  L["ECHO_KIND_CHANNEL"]),
    TierDropdown("nearby",   L["ECHO_NEARBY"]),
    -- Mention words decide what alerts you, so they sit with the per-chat alerts.
    { type = "editbox", name = L["ECHO_KEYWORDS"], labelText = L["ECHO_KEYWORDS"], tooltip = L["ECHO_KEYWORDS_DESC"],
      dbKey = "echoKeywords", height = 24,
      get = function() return getDB("echoKeywords", D.echoKeywords) or "" end,
      set = function(v) setDB("echoKeywords", type(v) == "string" and v:gsub("[\r\n]+", ",") or "") end },

    Section(L["ECHO_SECTION_FEEDS"], { page = "feeds" }),
    -- While Blizzard's chat is hidden the All view is always on (Echo.FeedEnabled). That
    -- setting is on another page, so this is a condition rather than a parent link.
    Toggle(L["ECHO_ALL_VIEW"], L["ECHO_ALL_VIEW_DESC"], "echoAllView", D.echoAllView,
        { visibleWhen = function() return getDB("echoHideBlizzardChat", D.echoHideBlizzardChat) == false end }),
}

for _, kind in ipairs({ "loot", "progress", "system" }) do
    local name = L["ECHO_KIND_" .. kind:upper()]
    local feedKey = addon.Echo.FeedKey(kind)
    options[#options + 1] = Toggle(L["ECHO_FEED_SHOW"]:format(name), L["ECHO_FEED_SHOW_DESC"], feedKey, D[feedKey])
    local tier = TierDropdown(kind, L["ECHO_FEED_TIER"]:format(name))
    tier.parent = feedKey
    tier.parentIs = function(v) return v ~= false end
    options[#options + 1] = tier
end

-- Groups: up to four named groups of chats (modules/Echo/EchoGroups.lua). The member ids and
-- their order mirror the Global Constraints table in Docs/Engineering/2026-09-26-echo-groups-plan.md.
local GROUP_MEMBERS = {
    { id = "ch:General",             label = L["ECHO_GROUP_MEMBER_GENERAL"] },
    { id = "ch:Trade",                label = L["ECHO_GROUP_MEMBER_TRADE"] },
    { id = "ch:Trade (Services)",     label = L["ECHO_GROUP_MEMBER_SERVICES"] },
    { id = "ch:LocalDefense",         label = L["ECHO_GROUP_MEMBER_LOCAL_DEFENSE"] },
    { id = "ch:LookingForGroup",      label = L["ECHO_GROUP_MEMBER_LFG"] },
    { id = "ch:WorldDefense",         label = L["ECHO_GROUP_MEMBER_WORLD_DEFENSE"] },
    { id = "ch:NewcomerChat",         label = L["ECHO_GROUP_MEMBER_NEWCOMER"] },
    { id = "ch:*",                    label = L["ECHO_GROUP_MEMBER_OTHER_CHANNELS"] },
    { id = "guild",                   label = L["ECHO_KIND_GUILD"] },
    { id = "officer",                 label = L["ECHO_KIND_OFFICER"] },
    { id = "party",                   label = L["ECHO_KIND_PARTY"] },
    { id = "raid",                    label = L["ECHO_KIND_RAID"] },
    { id = "instance",                label = L["ECHO_KIND_INSTANCE"] },
    { id = "loot",                    label = L["ECHO_KIND_LOOT"] },
    { id = "progress",                label = L["ECHO_KIND_PROGRESS"] },
    { id = "system",                  label = L["ECHO_KIND_SYSTEM"] },
}

-- A member id starting "ch:" but not the "ch:*" wildcard: an exact channel entry. For these,
-- "None" must write `false` (not remove the entry), so a per-channel None beats a grouped
-- "Other channels" (ch:*) fallback. Every other member id just clears its entry.
local function IsExactChannel(id)
    return type(id) == "string" and id:sub(1, 3) == "ch:" and id ~= "ch:*"
end

-- A fresh copy of a 4-entry group-names table, defaulting missing/invalid entries to "".
local function GroupNamesCopy()
    local names = getDB("echoGroupNames", D.echoGroupNames)
    local copy = { "", "", "", "" }
    if type(names) == "table" then
        for i = 1, 4 do
            if type(names[i]) == "string" then copy[i] = names[i] end
        end
    end
    return copy
end

-- A fresh copy of the member-id -> group-index table.
local function GroupOfCopy()
    local of = getDB("echoGroupOf", D.echoGroupOf)
    local copy = {}
    if type(of) == "table" then
        for k, v in pairs(of) do copy[k] = v end
    end
    return copy
end

-- A fresh copy of the group-index -> chosen-icon table.
local function GroupIconsCopy()
    local icons = getDB("echoGroupIcons", D.echoGroupIcons)
    local copy = {}
    if type(icons) == "table" then
        for k, v in pairs(icons) do copy[k] = v end
    end
    return copy
end

options[#options + 1] = Section(L["ECHO_SECTION_GROUPS"], { page = "feeds" })
options[#options + 1] = Toggle(L["ECHO_GROUPS_ENABLE"], L["ECHO_GROUPS_ENABLE_DESC"], "echoGroupsEnabled", D.echoGroupsEnabled)

for i = 1, 4 do
    options[#options + 1] = {
        type = "editbox", name = L["ECHO_GROUP_NAME"]:format(i), labelText = L["ECHO_GROUP_NAME"]:format(i),
        tooltip = L["ECHO_GROUP_NAME_DESC"], height = 24,
        dbKey = (i == 1) and "echoGroupNames" or nil,
        get = function()
            local names = getDB("echoGroupNames", D.echoGroupNames)
            if type(names) ~= "table" or type(names[i]) ~= "string" then return "" end
            return names[i]
        end,
        set = function(v)
            local copy = GroupNamesCopy()
            copy[i] = (type(v) == "string") and v or ""
            setDB("echoGroupNames", copy)
        end,
    }
    options[#options + 1] = Button(L["ECHO_GROUP_ICON"], L["ECHO_GROUP_ICON_DESC"], function()
        local names = getDB("echoGroupNames", D.echoGroupNames)
        local name = (type(names) == "table" and type(names[i]) == "string" and names[i]:find("%S"))
            and names[i] or string.format(L["ECHO_GROUP_DEFAULT_TITLE"], i)
        if not addon.OpenIconPicker then return end
        addon.OpenIconPicker({
            title = name,
            get = function()
                local icons = getDB("echoGroupIcons", D.echoGroupIcons)
                return (type(icons) == "table") and icons[i] or nil
            end,
            set = function(icon)
                local copy = GroupIconsCopy()
                copy[i] = icon
                setDB("echoGroupIcons", copy)
            end,
            allowDefault = true,
        })
    end, { dbKey = (i == 1) and "echoGroupIcons" or nil })
end

for i, member in ipairs(GROUP_MEMBERS) do
    local id = member.id
    if i == 1 then options[#options + 1] = Section(L["ECHO_SECTION_GROUP_CHANNELS"], { page = "feeds" }) end
    if i == 9 then options[#options + 1] = Section(L["ECHO_SECTION_GROUP_CHATS"], { page = "feeds" }) end
    options[#options + 1] = {
        type = "dropdown", name = member.label, desc = L["ECHO_GROUP_MEMBER_DESC"],
        dbKey = (i == 1) and "echoGroupOf" or nil,
        preserveOrder = true,
        options = function()
            local names = getDB("echoGroupNames", D.echoGroupNames)
            -- Only named groups are offered; a blank-named group groups nothing, so it isn't
            -- worth choosing even when something is still (stale) assigned to it.
            local opts = { { L["ECHO_GROUP_NONE"], "none" } }
            for gi = 1, 4 do
                local name = (type(names) == "table") and names[gi] or nil
                if type(name) == "string" and name:find("%S") then
                    opts[#opts + 1] = { name, gi }
                end
            end
            return opts
        end,
        -- nil and false both read as "None": false is the explicit "not grouped, no
        -- ch:* fallback" marker an exact channel writes below.
        get = function()
            local of = getDB("echoGroupOf", D.echoGroupOf)
            local v = (type(of) == "table") and of[id] or nil
            if v == nil or v == false then return "none" end
            return v
        end,
        set = function(v)
            local copy = GroupOfCopy()
            if v == "none" then
                -- Lua's `and/or` idiom can't choose `false` here (it would fall through to
                -- the `or` branch), so this stays an explicit if.
                if IsExactChannel(id) then copy[id] = false else copy[id] = nil end
            else
                copy[id] = v
            end
            setDB("echoGroupOf", copy)
        end,
    }
end

local tail = {
    Section(L["ECHO_SECTION_HISTORY"], { page = "general", card = "history" }),
    Toggle(L["ECHO_SAVE_HISTORY"], L["ECHO_SAVE_HISTORY_DESC"], "echoSaveHistory", D.echoSaveHistory),
    Toggle(L["ECHO_SAVE_GUILD"], L["ECHO_SAVE_GUILD_DESC"], "echoSaveGuild", D.echoSaveGuild,
        { parent = "echoSaveHistory", parentIs = function(v) return v ~= false end }),
    Toggle(L["ECHO_SAVE_OFFICER"], L["ECHO_SAVE_OFFICER_DESC"], "echoSaveOfficer", D.echoSaveOfficer,
        { parent = "echoSaveHistory", parentIs = function(v) return v ~= false end }),
    { type = "dropdown", name = L["ECHO_HISTORY_DAYS"], desc = L["ECHO_HISTORY_DAYS_DESC"], dbKey = "echoHistoryDays",
      options = HISTORY_DAYS_OPTIONS, preserveOrder = true,
      get = function() return getDB("echoHistoryDays", D.echoHistoryDays) end,
      set = function(v) setDB("echoHistoryDays", v) end },
    Button(L["ECHO_CLEAR_HISTORY"], L["ECHO_CLEAR_HISTORY_DESC"], function()
        local E = Echo()
        if E and E.ConfirmClearHistory then E.ConfirmClearHistory() end
    end),

    Section(L["ECHO_SECTION_BLIZZARD_CHAT"], { page = "general", card = "blizzardChat" }),
    Toggle(L["ECHO_HIDE_CHAT"], L["ECHO_HIDE_CHAT_DESC"], "echoHideBlizzardChat", D.echoHideBlizzardChat),
    { type = "dropdown", name = L["ECHO_COMBAT_LOG"], desc = L["ECHO_COMBAT_LOG_DESC"], dbKey = "echoCombatLog",
      options = COMBAT_LOG_OPTIONS, preserveOrder = true,
      parent = "echoHideBlizzardChat", parentIs = function(v) return v == true end,
      get = function()
          local E = Echo()
          if E and E.CombatLog then return E.CombatLog.Mode(getDB) end
          return getDB("echoCombatLog", D.echoCombatLog)
      end,
      set = function(v) setDB("echoCombatLog", v) end },
    -- No effect while Blizzard's chat is hidden (Echo.ApplyOptions keeps the filter off then).
    Toggle(L["ECHO_HIDE_STORED"], L["ECHO_HIDE_STORED_DESC"], "echoHideStoredWhispers", D.echoHideStoredWhispers,
        { parent = "echoHideBlizzardChat", parentIs = function(v) return v == false end }),
    Toggle(L["ECHO_DOCK_INPUT"], L["ECHO_DOCK_INPUT_DESC"], "echoDockInput", D.echoDockInput),
    Toggle(L["ECHO_INPUT_ALWAYS_VISIBLE"], L["ECHO_INPUT_ALWAYS_VISIBLE_DESC"], "echoInputAlwaysVisible", D.echoInputAlwaysVisible,
        { parent = "echoDockInput", parentIs = function(v) return v ~= false end }),
    { type = "dropdown", name = L["ECHO_ENTER_OPENS"], desc = L["ECHO_ENTER_OPENS_DESC"], dbKey = "echoEnterOpens",
      options = { { L["ECHO_NEARBY"], "nearby" }, { L["ECHO_ALL"], "all" } }, preserveOrder = true,
      parent = "echoDockInput", parentIs = function(v) return v ~= false end,
      get = function() return getDB("echoEnterOpens", D.echoEnterOpens) end,
      set = function(v) setDB("echoEnterOpens", v) end },
    ReloadPrompt({ hintText = L["ECHO_HIDE_CHAT_RELOAD"] }),

    -- The font covers Echo's tiles, stack and card alike, so it sits on its own Text card.
    Section(L["ECHO_SECTION_TEXT"], { page = "look", card = "text" }),
    { type = "dropdown", name = L["ECHO_FONT"], desc = L["ECHO_FONT_DESC"], dbKey = "echoFontPath", searchable = true,
      options = function() return addon.GetPerElementFontDropdownOptions("echoFontPath") end,
      get = function() return getDB("echoFontPath", D.echoFontPath) end,
      set = function(v) setDB("echoFontPath", v) end,
      displayFn = addon.DisplayPerElementFont, fontPreviewInList = true },
    Section(L["ECHO_SECTION_CARD"], { page = "look", card = "card" }),
    IntSlider("echoCardWidth",  L["ECHO_CARD_WIDTH"],  L["ECHO_CARD_SIZE_DESC"], 10),
    IntSlider("echoCardHeight", L["ECHO_CARD_HEIGHT"], L["ECHO_CARD_SIZE_DESC"], 10),
    IntSlider("echoCardTextSize", L["ECHO_CARD_TEXT_SIZE"], L["ECHO_CARD_TEXT_SIZE_DESC"], 1),
    Toggle(L["ECHO_SHOW_TIMESTAMPS"], L["ECHO_SHOW_TIMESTAMPS_DESC"], "echoShowTimestamps", D.echoShowTimestamps),
    Toggle(L["ECHO_ANIMATE_CARD"], L["ECHO_ANIMATE_CARD_DESC"], "echoAnimateCard", D.echoAnimateCard),
    IntSlider("echoCardIdleClose", L["ECHO_CARD_IDLE_CLOSE"], L["ECHO_CARD_IDLE_CLOSE_DESC"], 5),
}
for _, opt in ipairs(tail) do options[#options + 1] = opt end

addon.OptionCategories[#addon.OptionCategories + 1] = {
    key = "Echo", name = L["NAME_ADDON_CHAT"], desc = L["ECHO_DESC"], moduleKey = "echo",
    options = options,
}
