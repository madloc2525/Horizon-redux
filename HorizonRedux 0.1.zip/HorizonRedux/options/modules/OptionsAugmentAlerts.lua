--[[
    Horizon Suite - Augment / Alerts - options category
    Self-registers into addon.OptionCategories after OptionsData.lua runs.
]]

local addon = _G.HorizonSuite
if not addon or not addon.OptionCategories then return end

local L   = addon.L
local D   = addon.AUGMENT_DEFAULTS
local LIM = addon.AUGMENT_LIMITS
local function clamp(v, key) local lim = LIM[key]; return math.max(lim.min, math.min(lim.max, v)) end

local function getDB(k, d) return addon.OptionsData_GetDB(k, d) end
local function setDB(k, v) addon.OptionsData_SetDB(k, v) end
local Section = addon.Section
local FontRow = addon.FontRow

local FONT_USE_GLOBAL                  = addon.FONT_USE_GLOBAL
local GetPerElementFontDropdownOptions = addon.GetPerElementFontDropdownOptions
local DisplayPerElementFont            = addon.DisplayPerElementFont

-- Style picker entries come from the shared ToastStyles registry.
local function toastStyleOptions()
    local TS = addon.Augment and addon.Augment.ToastStyles
    return TS and TS.StyleOptions(L) or {}
end

-- One colour picker per kind, all sharing the same get/set/default shape
-- (3 float DB keys per kind — see AugmentAlertsState.lua's A.GetKindColor).
local function ColorOption(nameKey, descKey, prefix, opts)
    local row = {
        type = "color",
        name = L[nameKey], desc = L[descKey],
        dbKey = prefix,
        liveThrottle = 0.08,
        default = { D[prefix .. "R"], D[prefix .. "G"], D[prefix .. "B"] },
        get = function() return getDB(prefix .. "R", D[prefix .. "R"]), getDB(prefix .. "G", D[prefix .. "G"]), getDB(prefix .. "B", D[prefix .. "B"]) end,
        set = function(r, g, b)
            local batchingLive = addon._colorPickerLive and true or false
            if batchingLive then addon._suspendColorPickerLiveNotify = true end
            setDB(prefix .. "R", r)
            setDB(prefix .. "G", g)
            if batchingLive then addon._suspendColorPickerLiveNotify = nil end
            setDB(prefix .. "B", b)
        end,
    }
    if opts then for k, v in pairs(opts) do row[k] = v end end
    return row
end

-- Re-apply live state after a toggle/slider changes. Cheap to call on every
-- option change since each step early-outs when nothing actually needs it.
local function applyAlerts()
    local A = addon.Augment and addon.Augment.Alerts
    if not A then return end
    if A.UpdateEventRegistrations then A.UpdateEventRegistrations() end
    if A.ApplyScale then A.ApplyScale() end
    if A.RestoreSavedPosition then A.RestoreSavedPosition() end
    if A.Bags and A.Bags.RefreshReminderState then A.Bags.RefreshReminderState() end
    if A.Durability and A.Durability.RefreshReminderState then A.Durability.RefreshReminderState() end
end

local function GetBagThresholdHint()
    local A = addon.Augment and addon.Augment.Alerts
    if A and A.GetThresholdHint then
        return A.GetThresholdHint()
    end
    local threshold = tonumber(getDB("alertsBagsThreshold", D.alertsBagsThreshold)) or D.alertsBagsThreshold
    local total = 0
    for bag = 0, NUM_BAG_SLOTS do
        local slots = C_Container and C_Container.GetContainerNumSlots and C_Container.GetContainerNumSlots(bag)
        if slots and slots > 0 then
            total = total + slots
        end
    end
    if total <= 0 then
        return L["AUGMENT_ALERTS_BAGS_THRESHOLD_DESC"]
    end

    local maxFree = math.floor(total * (100 - threshold) / 100)
    return string.format("%s\n\nWith your bags now: %d or fewer free slots.", L["AUGMENT_ALERTS_BAGS_THRESHOLD_DESC"], maxFree)
end

local function GetReminderOptions()
    return {
        { L["AUGMENT_ALERTS_THRESHOLD"], "threshold" },
        { "1 min", "1min" },
        { "5 min", "5min" },
        { "10 min", "10min" },
        { "30 min", "30min" },
    }
end

local category = {
    key         = "AugmentAlerts",
    name        = L["AUGMENT_ALERTS"],
    desc        = L["AUGMENT_ALERTS_PAGE_DESC"],
    icon        = "Interface\\Icons\\INV_Misc_Bell_01",
    accentColor = { 0.95, 0.65, 0.25 },
    moduleKey   = "augment",
    enabledKey  = "augmentAlertsEnabled",
    getEnabled  = function() return getDB("augmentAlertsEnabled", D.augmentAlertsEnabled) ~= false end,
    setEnabled  = function(v)
        v = v and true or false
        setDB("augmentAlertsEnabled", v)
        if addon.IsModuleEnabled and not addon:IsModuleEnabled("augment") then return end
        local A = addon.Augment and addon.Augment.Alerts
        if not A then return end
        if v then A.Enable() else A.Disable() end
    end,
    options = {
        -- One card per group of alert types: each type's switch, then its threshold, reminder and colour.
        Section(L["AUGMENT_ALERTS_CARD_GEAR"], { page = "alerts" }),
            { type = "toggle",
              name = L["AUGMENT_ALERTS_DURABILITY"], desc = L["AUGMENT_ALERTS_DURABILITY_DESC"],
              dbKey = "alertsDurabilityEnabled",
              get = function() return getDB("alertsDurabilityEnabled", D.alertsDurabilityEnabled) end,
              set = function(v) setDB("alertsDurabilityEnabled", v); applyAlerts() end,
            },
            { type = "slider",
              name = L["AUGMENT_ALERTS_DURABILITY_THRESHOLD"], desc = L["AUGMENT_ALERTS_DURABILITY_THRESHOLD_DESC"],
              dbKey = "alertsDurabilityThreshold",
              min = LIM.alertsDurabilityThreshold.min, max = LIM.alertsDurabilityThreshold.max,
              get = function() return math.max(LIM.alertsDurabilityThreshold.min, math.min(LIM.alertsDurabilityThreshold.max, tonumber(getDB("alertsDurabilityThreshold", D.alertsDurabilityThreshold)) or D.alertsDurabilityThreshold)) end,
              set = function(v) setDB("alertsDurabilityThreshold", clamp(v, "alertsDurabilityThreshold")) end,
              parent = "alertsDurabilityEnabled",
            },
            { type = "dropdown",
              name = L["AUGMENT_ALERTS_DURABILITY_REMINDER"], desc = L["AUGMENT_ALERTS_DURABILITY_REMINDER_DESC"],
              dbKey = "alertsDurabilityReminder",
              options = GetReminderOptions(),
              get = function() return getDB("alertsDurabilityReminder", D.alertsDurabilityReminder) end,
              set = function(v) setDB("alertsDurabilityReminder", v); applyAlerts() end,
              parent = "alertsDurabilityEnabled",
              preserveOrder = true,
            },
            ColorOption("AUGMENT_ALERTS_DURABILITY_COLOUR", "AUGMENT_ALERTS_DURABILITY_COLOUR_DESC", "alertsDurabilityColor", { name = L["DASH_ROW_COLOUR"], parent = "alertsDurabilityEnabled", keywords = { L["AUGMENT_ALERTS_DURABILITY_COLOUR"] } }),
            { type = "toggle",
              name = L["AUGMENT_ALERTS_BAGS"], desc = L["AUGMENT_ALERTS_BAGS_DESC"],
              dbKey = "alertsBagsEnabled",
              get = function() return getDB("alertsBagsEnabled", D.alertsBagsEnabled) end,
              set = function(v) setDB("alertsBagsEnabled", v); applyAlerts() end,
            },
            { type = "slider",
              name = L["AUGMENT_ALERTS_BAGS_THRESHOLD"], desc = L["AUGMENT_ALERTS_BAGS_THRESHOLD_DESC"],
              dbKey = "alertsBagsThreshold",
              min = LIM.alertsBagsThreshold.min, max = LIM.alertsBagsThreshold.max,
              get = function() return math.max(LIM.alertsBagsThreshold.min, math.min(LIM.alertsBagsThreshold.max, tonumber(getDB("alertsBagsThreshold", D.alertsBagsThreshold)) or D.alertsBagsThreshold)) end,
              set = function(v) setDB("alertsBagsThreshold", clamp(v, "alertsBagsThreshold")) end,
              parent = "alertsBagsEnabled",
              tooltip = GetBagThresholdHint,
            },
            { type = "dropdown",
              name = L["AUGMENT_ALERTS_BAGS_REMINDER"], desc = L["AUGMENT_ALERTS_BAGS_REMINDER_DESC"],
              dbKey = "alertsBagsReminder",
              options = GetReminderOptions(),
              get = function() return getDB("alertsBagsReminder", D.alertsBagsReminder) end,
              set = function(v) setDB("alertsBagsReminder", v); applyAlerts() end,
              parent = "alertsBagsEnabled",
              preserveOrder = true,
            },
            ColorOption("AUGMENT_ALERTS_BAGS_COLOUR", "AUGMENT_ALERTS_BAGS_COLOUR_DESC", "alertsBagsColor", { name = L["DASH_ROW_COLOUR"], parent = "alertsBagsEnabled", keywords = { L["AUGMENT_ALERTS_BAGS_COLOUR"] } }),
        Section(L["AUGMENT_ALERTS_CARD_MESSAGES"], { page = "alerts" }),
            { type = "toggle",
              name = L["AUGMENT_ALERTS_MAIL"], desc = L["AUGMENT_ALERTS_MAIL_DESC"],
              dbKey = "alertsMailEnabled",
              get = function() return getDB("alertsMailEnabled", D.alertsMailEnabled) end,
              set = function(v) setDB("alertsMailEnabled", v); applyAlerts() end,
            },
            ColorOption("AUGMENT_ALERTS_MAIL_COLOUR", "AUGMENT_ALERTS_MAIL_COLOUR_DESC", "alertsMailColor", { name = L["DASH_ROW_COLOUR"], parent = "alertsMailEnabled", keywords = { L["AUGMENT_ALERTS_MAIL_COLOUR"] } }),
            { type = "toggle", requires = "weeklyVault",
              name = L["AUGMENT_ALERTS_VAULT"], desc = L["AUGMENT_ALERTS_VAULT_DESC"],
              dbKey = "alertsVaultEnabled",
              get = function() return getDB("alertsVaultEnabled", D.alertsVaultEnabled) end,
              set = function(v) setDB("alertsVaultEnabled", v); applyAlerts() end,
            },
            addon.RequireCapability("weeklyVault", ColorOption("AUGMENT_ALERTS_VAULT_COLOUR", "AUGMENT_ALERTS_VAULT_COLOUR_DESC", "alertsVaultColor", { name = L["DASH_ROW_COLOUR"], parent = "alertsVaultEnabled", keywords = { L["AUGMENT_ALERTS_VAULT_COLOUR"] } })),
            { type = "toggle", requires = "professions",
              name = L["AUGMENT_ALERTS_RECIPE"], desc = L["AUGMENT_ALERTS_RECIPE_DESC"],
              dbKey = "alertsRecipeEnabled",
              get = function() return getDB("alertsRecipeEnabled", D.alertsRecipeEnabled) end,
              set = function(v) setDB("alertsRecipeEnabled", v); applyAlerts() end,
            },
            addon.RequireCapability("professions", ColorOption("AUGMENT_ALERTS_RECIPE_COLOUR", "AUGMENT_ALERTS_RECIPE_COLOUR_DESC", "alertsRecipeColor", { name = L["DASH_ROW_COLOUR"], parent = "alertsRecipeEnabled", keywords = { L["AUGMENT_ALERTS_RECIPE_COLOUR"] } })),
            { type = "toggle",
              name = L["AUGMENT_ALERTS_FRIENDS"], desc = L["AUGMENT_ALERTS_FRIENDS_DESC"],
              dbKey = "alertsFriendsEnabled",
              get = function() return getDB("alertsFriendsEnabled", D.alertsFriendsEnabled) end,
              set = function(v) setDB("alertsFriendsEnabled", v); applyAlerts() end,
            },
            ColorOption("AUGMENT_ALERTS_FRIEND_ON_COLOUR", "AUGMENT_ALERTS_FRIEND_ON_COLOUR_DESC", "alertsFriendOnColor", { parent = "alertsFriendsEnabled" }),
            ColorOption("AUGMENT_ALERTS_FRIEND_OFF_COLOUR", "AUGMENT_ALERTS_FRIEND_OFF_COLOUR_DESC", "alertsFriendOffColor", { parent = "alertsFriendsEnabled" }),
            -- The card returns when alert sounds ship (with A.SOUNDS_READY in
            -- AugmentAlertsQueue.lua, which keeps them silent until then).
            { type = "section", name = L["AUGMENT_ALERTS_SOUND"], page = "alerts", visibleWhen = function() return false end },
            { type = "toggle",
              name = L["AUGMENT_ALERTS_SOUND_ENABLED"], desc = L["AUGMENT_ALERTS_SOUND_ENABLED_DESC"],
              dbKey = "alertsSoundEnabled",
              get = function() return getDB("alertsSoundEnabled", D.alertsSoundEnabled) end,
              set = function(v) setDB("alertsSoundEnabled", v) end,
              disabled = function() return true end,
            },
            { type = "dropdown",
              name = L["AUGMENT_ALERTS_SOUND_CHANNEL"], desc = L["AUGMENT_ALERTS_SOUND_CHANNEL_DESC"],
              dbKey = "alertsSoundChannel",
              options = {
                  { L["AUGMENT_SOUND_CH_SFX"],      "SFX"      },
                  { L["AUGMENT_SOUND_CH_MASTER"],   "Master"   },
                  { L["AUGMENT_SOUND_CH_DIALOG"],   "Dialog"   },
                  { L["AUGMENT_SOUND_CH_AMBIENCE"], "Ambience" },
                  { L["AUGMENT_SOUND_CH_MUSIC"],    "Music"    },
              },
              get = function() return getDB("alertsSoundChannel", D.alertsSoundChannel) end,
              set = function(v) setDB("alertsSoundChannel", v) end,
              parent = "alertsSoundEnabled",
            },
            { type = "slider",
              name = L["AUGMENT_ALERTS_SOUND_COOLDOWN"], desc = L["AUGMENT_ALERTS_SOUND_COOLDOWN_DESC"],
              dbKey = "alertsSoundCooldown",
              min = LIM.alertsSoundCooldown.min, max = LIM.alertsSoundCooldown.max,
              get = function() return math.max(LIM.alertsSoundCooldown.min, math.min(LIM.alertsSoundCooldown.max, tonumber(getDB("alertsSoundCooldown", D.alertsSoundCooldown)) or D.alertsSoundCooldown)) end,
              set = function(v) setDB("alertsSoundCooldown", clamp(v, "alertsSoundCooldown")) end,
              parent = "alertsSoundEnabled",
            },
            { type = "toggle",
              name = L["AUGMENT_ALERTS_SOUND_DURABILITY"], desc = L["AUGMENT_ALERTS_SOUND_DURABILITY_DESC"],
              dbKey = "alertsSoundDurability",
              get = function() return getDB("alertsSoundDurability", D.alertsSoundDurability) end,
              set = function(v) setDB("alertsSoundDurability", v) end,
              parent = "alertsSoundEnabled",
              shiftClick = function() if addon.Augment and addon.Augment.Alerts and addon.Augment.Alerts.PlaySoundPreview then addon.Augment.Alerts.PlaySoundPreview("DURABILITY") end end,
            },
            { type = "toggle",
              name = L["AUGMENT_ALERTS_SOUND_BAGS"], desc = L["AUGMENT_ALERTS_SOUND_BAGS_DESC"],
              dbKey = "alertsSoundBags",
              get = function() return getDB("alertsSoundBags", D.alertsSoundBags) end,
              set = function(v) setDB("alertsSoundBags", v) end,
              parent = "alertsSoundEnabled",
              shiftClick = function() if addon.Augment and addon.Augment.Alerts and addon.Augment.Alerts.PlaySoundPreview then addon.Augment.Alerts.PlaySoundPreview("BAGS") end end,
            },
            { type = "toggle",
              name = L["AUGMENT_ALERTS_SOUND_MAIL"], desc = L["AUGMENT_ALERTS_SOUND_MAIL_DESC"],
              dbKey = "alertsSoundMail",
              get = function() return getDB("alertsSoundMail", D.alertsSoundMail) end,
              set = function(v) setDB("alertsSoundMail", v) end,
              parent = "alertsSoundEnabled",
              shiftClick = function() if addon.Augment and addon.Augment.Alerts and addon.Augment.Alerts.PlaySoundPreview then addon.Augment.Alerts.PlaySoundPreview("MAIL") end end,
            },
            { type = "toggle", requires = "weeklyVault",
              name = L["AUGMENT_ALERTS_SOUND_VAULT"], desc = L["AUGMENT_ALERTS_SOUND_VAULT_DESC"],
              dbKey = "alertsSoundVault",
              get = function() return getDB("alertsSoundVault", D.alertsSoundVault) end,
              set = function(v) setDB("alertsSoundVault", v) end,
              parent = "alertsSoundEnabled",
              shiftClick = function() if addon.Augment and addon.Augment.Alerts and addon.Augment.Alerts.PlaySoundPreview then addon.Augment.Alerts.PlaySoundPreview("VAULT") end end,
            },
            { type = "toggle", requires = "professions",
              name = L["AUGMENT_ALERTS_SOUND_RECIPE"], desc = L["AUGMENT_ALERTS_SOUND_RECIPE_DESC"],
              dbKey = "alertsSoundRecipe",
              get = function() return getDB("alertsSoundRecipe", D.alertsSoundRecipe) end,
              set = function(v) setDB("alertsSoundRecipe", v) end,
              parent = "alertsSoundEnabled",
              shiftClick = function() if addon.Augment and addon.Augment.Alerts and addon.Augment.Alerts.PlaySoundPreview then addon.Augment.Alerts.PlaySoundPreview("RECIPE") end end,
            },
            { type = "toggle",
              name = L["AUGMENT_ALERTS_SOUND_FRIENDS"], desc = L["AUGMENT_ALERTS_SOUND_FRIENDS_DESC"],
              dbKey = "alertsSoundFriends",
              get = function() return getDB("alertsSoundFriends", D.alertsSoundFriends) end,
              set = function(v) setDB("alertsSoundFriends", v) end,
              parent = "alertsSoundEnabled",
              shiftClick = function() if addon.Augment and addon.Augment.Alerts and addon.Augment.Alerts.PlaySoundPreview then addon.Augment.Alerts.PlaySoundPreview("FRIEND_ON") end end,
            },

        Section(L["AUGMENT_ALERTS_DISPLAY"], { page = "alerts" }),
        { type = "slider",
          name = L["AUGMENT_ALERTS_OPACITY"], desc = L["AUGMENT_ALERTS_OPACITY_DESC"],
          dbKey = "alertsOpacity",
          min = LIM.alertsOpacity.min, max = LIM.alertsOpacity.max,
          get = function() return math.max(LIM.alertsOpacity.min, math.min(LIM.alertsOpacity.max, tonumber(getDB("alertsOpacity", D.alertsOpacity)) or D.alertsOpacity)) end,
          set = function(v) setDB("alertsOpacity", clamp(v, "alertsOpacity")) end,
        },
        { type = "slider",
          name = L["AUGMENT_ALERTS_SCALE"], desc = L["AUGMENT_ALERTS_SCALE_DESC"],
          dbKey = "alertsScale",
          min = LIM.alertsScale.min, max = LIM.alertsScale.max, step = 0.1,
          get = function() return math.max(LIM.alertsScale.min, math.min(LIM.alertsScale.max, tonumber(getDB("alertsScale", D.alertsScale)) or D.alertsScale)) end,
          set = function(v) setDB("alertsScale", clamp(v, "alertsScale")); applyAlerts() end,
        },
        { type = "dropdown",
          name = L["AUGMENT_TOAST_STYLE"], desc = L["AUGMENT_TOAST_STYLE_DESC"],
          dbKey = "alertsToastStyle",
          options = toastStyleOptions(),
          get = function() return getDB("alertsToastStyle", D.alertsToastStyle) end,
          set = function(v) setDB("alertsToastStyle", v); applyAlerts() end,
          preserveOrder = true,
        },
        FontRow(L["AUGMENT_ALERTS_FONT"], L["AUGMENT_ALERTS_FONT_DESC"], {
            family = {
                dbKey = "alertsFontPath",
                searchable = true,
                options = function() return GetPerElementFontDropdownOptions("alertsFontPath") end,
                get = function() return getDB("alertsFontPath", FONT_USE_GLOBAL) end,
                set = function(v) setDB("alertsFontPath", v); applyAlerts() end,
                displayFn = DisplayPerElementFont,
                fontPreviewInList = true,
            },
            size = {
                dbKey = "alertsFontSize",
                tooltip = L["AUGMENT_ALERTS_FONT_SIZE_DESC"],
                min = LIM.alertsFontSize.min, max = LIM.alertsFontSize.max, step = 1,
                get = function() return math.max(LIM.alertsFontSize.min, math.min(LIM.alertsFontSize.max, tonumber(getDB("alertsFontSize", D.alertsFontSize)) or D.alertsFontSize)) end,
                set = function(v) setDB("alertsFontSize", clamp(v, "alertsFontSize")); applyAlerts() end,
            },
            outline = {
                dbKey = "alertsTextOutlineType",
                tooltip = L["AUGMENT_ALERTS_OUTLINE_TYPE_DESC"],
                options = addon.OUTLINE_OPTIONS,
                get = function() return getDB("alertsTextOutlineType", D.alertsTextOutlineType) end,
                set = function(v) setDB("alertsTextOutlineType", v); applyAlerts() end,
            },
        }, { keywords = { L["AUGMENT_ALERTS_FONT_SIZE"], L["AUGMENT_ALERTS_OUTLINE_TYPE"] } }),
        { type = "slider",
          name = L["AUGMENT_ALERTS_HOLD_DURATION"], desc = L["AUGMENT_ALERTS_HOLD_DURATION_DESC"],
          dbKey = "alertsHoldDuration",
          min = LIM.alertsHoldDuration.min, max = LIM.alertsHoldDuration.max, step = 0.5,
          get = function() return math.max(LIM.alertsHoldDuration.min, math.min(LIM.alertsHoldDuration.max, tonumber(getDB("alertsHoldDuration", D.alertsHoldDuration)) or D.alertsHoldDuration)) end,
          set = function(v) setDB("alertsHoldDuration", clamp(v, "alertsHoldDuration")) end,
        },

        Section(L["PAGE_LAYOUT"], { page = "alerts" }),
        { type = "slider",
          name = L["AUGMENT_ALERTS_MAX_VISIBLE"], desc = L["AUGMENT_ALERTS_MAX_VISIBLE_DESC"],
          dbKey = "alertsMaxVisible",
          min = LIM.alertsMaxVisible.min, max = LIM.alertsMaxVisible.max,
          get = function() return math.max(LIM.alertsMaxVisible.min, math.min(LIM.alertsMaxVisible.max, tonumber(getDB("alertsMaxVisible", D.alertsMaxVisible)) or D.alertsMaxVisible)) end,
          set = function(v) setDB("alertsMaxVisible", clamp(v, "alertsMaxVisible")) end,
        },
        { type = "slider",
          name = L["AUGMENT_ICON_SIZE"], desc = L["AUGMENT_ICON_SIZE_DESC"],
          dbKey = "alertsIconSize",
          min = LIM.alertsIconSize.min, max = LIM.alertsIconSize.max, step = 1,
          get = function() return math.max(LIM.alertsIconSize.min, math.min(LIM.alertsIconSize.max, tonumber(getDB("alertsIconSize", D.alertsIconSize)) or D.alertsIconSize)) end,
          set = function(v) setDB("alertsIconSize", clamp(v, "alertsIconSize")); applyAlerts() end,
        },
        { type = "slider",
          name = L["AUGMENT_ICON_GAP"], desc = L["AUGMENT_ICON_GAP_DESC"],
          dbKey = "alertsIconGap",
          min = LIM.alertsIconGap.min, max = LIM.alertsIconGap.max, step = 1,
          get = function() return math.max(LIM.alertsIconGap.min, math.min(LIM.alertsIconGap.max, tonumber(getDB("alertsIconGap", D.alertsIconGap)) or D.alertsIconGap)) end,
          set = function(v) setDB("alertsIconGap", clamp(v, "alertsIconGap")); applyAlerts() end,
        },
        { type = "dropdown",
          name = L["AUGMENT_ALERTS_ICON_SIDE"], desc = L["AUGMENT_ALERTS_ICON_SIDE_DESC"],
          dbKey = "alertsIconSide",
          options = {
              { L["AUGMENT_LAYOUT_LEFT"],  "left"  },
              { L["AUGMENT_LAYOUT_RIGHT"], "right" },
          },
          get = function() return getDB("alertsIconSide", D.alertsIconSide) end,
          set = function(v) setDB("alertsIconSide", v); applyAlerts() end,
          preserveOrder = true,
        },
        { type = "dropdown",
          name = L["AUGMENT_ALERTS_SLIDE_SIDE"], desc = L["AUGMENT_ALERTS_SLIDE_SIDE_DESC"],
          dbKey = "alertsSlideSide",
          options = {
              { L["AUGMENT_LAYOUT_LEFT"],  "left"  },
              { L["AUGMENT_LAYOUT_RIGHT"], "right" },
          },
          get = function() return getDB("alertsSlideSide", D.alertsSlideSide) end,
          set = function(v) setDB("alertsSlideSide", v); applyAlerts() end,
          preserveOrder = true,
        },
        { type = "dropdown",
          name = L["AUGMENT_ALERTS_GROW_DIRECTION"], desc = L["AUGMENT_ALERTS_GROW_DIRECTION_DESC"],
          dbKey = "alertsGrowDirection",
          options = {
              { L["AUGMENT_LAYOUT_UP"],   "up"   },
              { L["AUGMENT_LAYOUT_DOWN"], "down" },
          },
          get = function() return getDB("alertsGrowDirection", D.alertsGrowDirection) end,
          set = function(v) setDB("alertsGrowDirection", v); applyAlerts() end,
          preserveOrder = true,
        },

    },
}

addon.RegisterModulePages("augment", {
    addon.OptionsPages.FromCategory(category, "alerts", {
        headerButtons = {
            preview = function() if addon.Augment and addon.Augment.Alerts and addon.Augment.Alerts.PreviewAlerts then addon.Augment.Alerts.PreviewAlerts() end end,
            reset   = function() if addon.Augment and addon.Augment.Alerts and addon.Augment.Alerts.ResetPosition then addon.Augment.Alerts.ResetPosition() end end,
            anchor  = function() if addon.Augment and addon.Augment.Alerts and addon.Augment.Alerts.ToggleEditMode then addon.Augment.Alerts.ToggleEditMode() end end,
        },
    }),
})

-- Insert after the last Augment category to preserve sidebar order
local insertAt = #addon.OptionCategories + 1
for i, cat in ipairs(addon.OptionCategories) do
    if cat.moduleKey == "augment" then insertAt = i + 1 end
end
table.insert(addon.OptionCategories, insertAt, category)
