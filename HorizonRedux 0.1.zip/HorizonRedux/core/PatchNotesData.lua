--[[
    Horizon Suite - Patch Notes Data
    Update this file each release. Key must exactly match ## Version in HorizonSuite.toc.
    In-game notes should be player-facing summaries — not every internal/CI entry.

    Per version table:
    - date = "YYYY-MM-DD" (optional but preferred) — store ISO for CHANGELOG parity; the dashboard shows long UK text
      (e.g. 31 March 2026) in parentheses after the version.
    - Array entries { section = "...", bullets = { ... } } — bullets may use "Module: rest"; the UI capitalizes the
      first letter after ": " when it is lowercase (ASCII). Data can stay lowercase after the colon if you prefer.
    - A bullet that only one client can notice carries the flavour inside the prefix: "Focus (Forever): rest" or
      "Core (Retail): rest". No flavour means both. Every client renders every bullet — do not filter by flavour
      here, or a release that only touches one client shows an empty popup on the other. The renderer colours the
      flavour as its own badge, so write it plainly here and leave the styling to it; a flavour it does not know
      is left as written rather than badged.
]]

local addon = _G.HorizonSuite

addon.PATCH_NOTES = {

    ["6.11.1"] = {
        date = "2026-10-20",
        {
            section = "Fixes",
            bullets = {
                "Focus: tracked achievements now list only the criteria you still need by default. Turn off Missing Criteria Only to see them all.",
                "Focus: in Minimal mode the header chevron and Options text stay hidden after a reload, and hide again when the cursor leaves.",
            },
        },
    },

    ["6.11.0"] = {
        date = "2026-10-19",
        {
            section = "New Features",
            bullets = {
                "Focus: a new Reverse order switch under Sorting flips the Quest level, Alphabetical and Zone sorts, so you can work through your lowest-level quests first or read your list Z to A. Quests that tie stay in A to Z order.",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Axis: the bottom of a settings page is no longer cut off after it opens; Focus > Layout scrolls all the way down to the Spacing options again.",
            },
        },
    },

    ["6.10.0"] = {
        date = "2026-10-18",
        {
            section = "New Features",
            bullets = {
                "Focus: Active quest highlight now offers Left bar, Right bar, Gradient fade, Pointer, Coloured title and None, and none of them push your quests out of line. Each style keeps its own colour and turns green when the quest is ready to turn in, and with Show progress on the bars light up in four steps as you complete objectives.",
            },
        },
        {
            section = "Improvements",
            bullets = {
                "Focus: Top bar, Bottom bar, Outline, Glow, Dual bars, Pill accent and Highlight have been retired. If you used one, you're moved to Left bar or Gradient fade automatically.",
            },
        },
    },

    ["6.9.0"] = {
        date = "2026-10-16",
        {
            section = "New Features",
            bullets = {
                "Augment: a new Faster auto-loot option takes every item on a corpse at once when auto-loot is on. Anything that won't fit in your bags stays behind and the loot window opens straight away showing just those. Turn it on under Augment > Loot Frame > Loot window.",
                "Augment: a new Recipe learned alert shows the \"new recipe learned\" pop-up in your Horizon alert style, and Train all at a trainer shows one \"12 Recipes Learned\" alert instead of one per recipe. Turn it on in Augment Alerts.",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Axis: hovering Reset loot window position no longer raises a Lua error, and settings search no longer shows \"function: 0x...\" as a setting's description.",
            },
        },
    },

    ["6.8.1"] = {
        date = "2026-10-14",
        {
            section = "Fixes",
            bullets = {
                "Augment: gold, currency and reputation toasts no longer play the friend-online chime: gold plays the coin clink, currency and reputation play the loot toast sound, and the durability, bags and mail alerts play a neutral chime.",
                "Focus: quest items the game can't look up no longer flood chat with a warning every second, and their cooldown shows on the quest item button again.",
                "Axis: the Integrations page shows an installed add-on built for a different game version as \"Out of date\" instead of calling it missing.",
            },
        },
    },

    ["6.8.0"] = {
        date = "2026-10-12",
        {
            section = "New Features",
            bullets = {
                "Vista: a new Map icon size slider under Layout > Size & shape resizes the inn, repair and herb icons on the minimap without switching Vista off. It and Minimap size now redraw as you drag.",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Focus: Lock position now only controls the lock: it can be turned off with Shrink to fit on, and both the header and the body obey it.",
                "Focus: turning on Shrink to fit redraws every quest in full instead of cutting entries off half-way with gaps between sections.",
                "Augment: the money, currency and reputation toast sounds play the toast chime again, and the durability, bags and mail alerts do too.",
            },
        },
    },

    ["6.7.1"] = {
        date = "2026-10-11",
        {
            section = "Fixes",
            bullets = {
                "Focus (Forever): group quests no longer show a group finder eye that does nothing when clicked; its option is greyed out until Forever supports group search.",
                "Echo: long messages stay inside their chat bubble instead of spilling their last word into the next one.",
            },
        },
    },

    ["6.7.0"] = {
        date = "2026-10-09",
        {
            section = "New Features",
            bullets = {
                "Axis: a rebuilt settings dashboard. Every on-screen element now has one card, with its switch at the top and everything for it underneath, across every module. Related settings sit under topic headings inside each card.",
                "Axis: smarter settings search. It forgives typos, understands synonyms, highlights what matched, remembers recent searches and takes you straight to the setting.",
                "Axis: new Welcome and News pages. Welcome shows every module at a glance with its on or off state, and News carries what's new in each version, with stories you can open.",
                "Echo: choose what Enter opens. Pressing Enter to talk can open All chat instead of Nearby. It stays on Nearby unless you change it.",
            },
        },
        {
            section = "Improvements",
            bullets = {
                "Axis: a cleaner settings window, with a modern look, a matching icon for every module, shorter labels, and smooth animation as sub-settings appear and disappear.",
                "Axis: a marker shows which settings differ from their defaults, each with a reset arrow, and every card shows how many of its settings you've changed.",
                "Axis: font, size and outline now sit together on one row.",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Axis: settings that did nothing now work, and settings that can't apply right now are greyed out instead of silently ignored.",
            },
        },
    },

    ["6.6.0"] = {
        date = "2026-10-05",
        {
            section = "New Features",
            bullets = {
                "Presence: drag the zone-entry and quest text from the settings page or Blizzard's Edit Mode, or set its position with two sliders, which helps on multi-monitor setups. Opening Edit Mode shows an empty box to drag, and Shift-clicking it plays a sample.",
                "Echo: a new switch shows the time beside each message, just outside its bubble. It starts off, so nothing changes unless you turn it on.",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Augment: opening Edit Mode no longer fills the screen with sample loot rolls and alerts; Shift-click a loot box to see a sample.",
                "Augment: with Blizzard's controller interface on, Blizzard's loot window no longer flashes up beside Augment's loot toast when auto-looting.",
                "Echo: long messages sent in dungeons and fights fit inside their chat bubble instead of spilling into the next message.",
            },
        },
    },

    ["6.5.1"] = {
        date = "2026-10-04",
        {
            section = "New Features",
            bullets = {
                "Focus: a new option hides the group finder eye beside group quests, and the quest text uses the space it leaves. It starts on, so nothing changes unless you turn it off.",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Augment: with auto-loot on, items you can't pick up, such as when your bags are full, show in the loot window straight away instead of after several clicks.",
                "Augment: with Blizzard's controller interface on, taking loot no longer triggers a \"blocked action\" warning; the loot window keeps Blizzard's own look in that mode.",
                "Core: with Blizzard's controller interface on, the Escape menu no longer triggers a \"blocked action\" warning. Horizon Suite's button is left off that menu in controller mode, and /horizon still opens the settings.",
            },
        },
    },

    ["6.5.0"] = {
        date = "2026-10-03",
        {
            section = "New Features",
            bullets = {
                "Augment: two new switches on the Loot Frame page, Loot Toasts and Loot Window Skin, let you use Augment's loot toasts and its loot window skin independently. Both start on.",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Vista: the queue eye and the Omnium Folio button sit behind the World Map instead of drawing on top of it.",
                "Augment: with auto-loot on, Blizzard's loot window no longer flashes up beside Augment's loot toast.",
            },
        },
    },

    ["6.4.1"] = {
        date = "2026-10-02",
        {
            section = "Fixes",
            bullets = {
                "Core (Forever): Horizon Suite recognises World of Warcraft: Forever again after the October 1 beta update, so dungeons and zones are no longer labelled as Delves, and settings for systems Forever does not have stay hidden.",
            },
        },
    },

    ["6.4.0"] = {
        date = "2026-10-01",
        {
            section = "New Features",
            bullets = {
                "Augment: two new toast styles, Ribbon (a colour wash fading away from the icon) and Rail (a dark bar with a thin coloured stripe along the icon's edge), for loot toasts, alerts, loot rolls, Echo pop-ups and the loot window.",
                "Augment: the new Card toast style has a larger framed icon and, on loot toasts, a second line with the item level and slot for gear, the type for other items, and your new total for gold and currencies.",
            },
        },
    },

    ["6.3.1"] = {
        date = "2026-09-30",
        {
            section = "Fixes",
            bullets = {
                "Focus: quest level colours match the game's own quest log again, so a quest a few levels below you shows green instead of yellow.",
                "Insight: tooltip level colours match the game's target frame again, so a mob a few levels below you shows green instead of yellow.",
            },
        },
    },

    ["6.3.0"] = {
        date = "2026-09-30",
        {
            section = "New Features",
            bullets = {
                "Augment: the Framed look for loot toasts, alerts, loot rolls and the loot window can use square corners instead of rounded ones, with a border thickness set in screen pixels so it stays crisp at any UI scale. Rounded stays the default.",
                "Focus: with Quest Level on, each quest's level is coloured by how hard it is for you (grey, green, yellow, orange or red), matching the game's quest log. It has its own switch, and it starts on.",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Presence: boss emotes show once again, in Presence's style only, instead of also appearing in the game's own red text. Raid leader warnings are unaffected.",
            },
        },
    },

    ["6.2.0"] = {
        date = "2026-09-29",
        {
            section = "New Features",
            bullets = {
                "Echo: with Blizzard's chat hidden, the combat log moves into Echo on its own tile. Opening it shows Blizzard's combat log, filter buttons and all, and it stays open when a fight starts. The new Combat log setting keeps it in Blizzard's own tab or hides it instead.",
            },
        },
    },

    ["6.1.0"] = {
        date = "2026-09-28",
        {
            section = "New Features",
            bullets = {
                "Insight: when tooltips are anchored to a fixed spot, choose whether they grow up and right, up and left, down and right, or down and left from the anchor. Automatic keeps the current behaviour and stays the default.",
                "Insight: a creature's level is coloured by how hard it is for you, matching the game's nameplates, and the name on the Targeting line is coloured by class for players or by reaction for everything else. Each colour has its own switch, and both start on.",
            },
        },
        {
            section = "Improvements",
            bullets = {
                "Echo: the highlight colour follows your class colour when you turn it on in Axis, and the \"all modules\" switch now includes Echo. Other people's colours stay their own.",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Echo: right-clicking a player's line in the All feed offers Whisper and Invite as well as Pin, including on WoW: Forever.",
                "Echo: on WoW: Forever, Echo uses your full name with surname in emotes, the All feed and pinned messages, and group members with surnames show their class colour.",
                "Axis: the Discord button in the dashboard footer links to the current server again.",
            },
        },
    },

    ["6.0.0"] = {
        date = "2026-09-27",
        {
            section = "New Features",
            bullets = {
                "Echo: a new module that gives every conversation its own tile on the edge of your screen: each person you whisper, Battle.net friends, party, raid, guild, your channels, and feeds for loot, progress and system messages. Hover a tile to peek and reply, or click it to read the whole conversation as a thread.",
                "Echo: whispers and guild chat are kept between sessions, any message can be pinned, and channels can share one tile with a tab for each.",
                "Echo: while it is on, Echo takes the place of Blizzard's chat windows, with Blizzard's own input line docked beneath it so slash commands and replies work as before. The combat log stays where it is. Echo starts switched off: turn it on under Axis → Modules and reload.",
            },
        },
        {
            section = "Improvements",
            bullets = {
                "Augment: loot roll frames follow your loot toast style unless you have already chosen a style for them, and Match Loot Toasts now heads the roll frame style list.",
                "Augment: the Modules page no longer labels Augment as a Preview module.",
            },
        },
    },

    ["5.11.0"] = {
        date = "2026-09-26",
        {
            section = "New Features",
            bullets = {
                "Augment: loot roll frames. When your group rolls on loot, Horizon draws its own Need and Greed frame, showing who has rolled so far and who is winning, whether the item's appearance is new to you, how its item level compares with what you have equipped, and whether it binds on pickup.",
                "Augment: rolls below the quality you choose, and any beyond the number of frames you allow on screen, keep Blizzard's own frame, so no roll goes missing. Find it under Augment → Loot Rolls, and try it with Show Demo Rolls, which needs no group.",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Presence: switching off an achievement, achievement progress or world quest notification brings back the game's own version of it immediately, with no need to turn Presence off.",
                "Presence: switching off zone names or area names brings back the game's own versions of them. With zone names off, area names no longer keep showing when the settings say they are off.",
                "Focus: the dungeon run tracker no longer shows an error when a system chat message arrives inside a dungeon.",
            },
        },
    },

    ["5.10.0"] = {
        date = "2026-09-20",
        {
            section = "New Features",
            bullets = {
                "Focus: a dungeon run tracker. In any party dungeon that is not a Mythic+ run, a banner above the tracker shows how long you have been inside, the experience and money you have earned, and the rate of each per hour.",
                "Focus: hover the run banner for the bosses you have defeated, how long the next level is at your current pace, and a button to start the run over. The run carries on through a reload, and picks up where it left off after a corpse run.",
            },
        },
        {
            section = "Improvements",
            bullets = {
                "Core: patch notes give the core of the addon its own colour, and each entry that applies to only one client carries a coloured badge naming it.",
            },
        },
    },

    ["5.9.1"] = {
        date = "2026-09-19",
        {
            section = "Fixes",
            bullets = {
                "Core (Forever): dungeons and cities are no longer treated as Delves, so the tracker heading, its colour and the zone banner say what you are actually in.",
                "Insight (Forever): a character's surname appears once in the tooltip header instead of twice.",
                "Essence: the character panel shows your full name, surname included, and a suffix title such as \"the Explorer\" no longer comes through cut short.",
                "Focus: switching the tracker off and back on without reloading brings its entries back, instead of leaving section headings over blank space.",
            },
        },
    },

    ["5.9.0"] = {
        date = "2026-09-18",
        {
            section = "New Features",
            bullets = {
                "Core: Horizon Suite now loads on World of Warcraft: Forever from the same package as Retail. Settings for systems Forever does not have (Mythic+, Delves, housing, the Great Vault, specialisations and the Traveler's Log) stay out of the way there, and /h platform shows what your client supports. Known beta issue: the Forever client does not yet read saved settings back at login, so settings reset on reload until Blizzard fixes it.",
            },
        },
        {
            section = "Improvements",
            bullets = {
                "Core: SubtleGrind joins the supporters wall on the Welcome page.",
                "Core: a module that fails to start now says so in chat instead of silently staying off.",
            },
        },
    },

    ["5.8.0"] = {
        date = "2026-09-12",
        {
            section = "New Features",
            bullets = {
                "Focus: choose which layer the tracker draws on, so it sits in front of or behind other addon windows. Dialogs and tooltips always stay above it. Set it under Focus > Layout > Position & Layout.",
            },
        },
    },

    ["5.7.0"] = {
        date = "2026-09-09",
        {
            section = "New Features",
            bullets = {
                "Insight: the class line now names your specialisation and ends with a role tag, with the active hero talent on its own line beneath it. Both toggle under Insight > Player Characters > Class.",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Insight: the role tag no longer goes missing from the identity line when Total RP 3's race and class display is turned on.",
            },
        },
    },

    ["5.6.5"] = {
        date = "2026-09-06",
        {
            section = "Fixes",
            bullets = {
                "Core: the patch notes panel was empty after updating to 5.6.4. Those notes now appear here, below this release.",
            },
        },
    },

    ["5.6.4"] = {
        date = "2026-09-06",
        {
            section = "Fixes",
            bullets = {
                "Focus: collapsed categories no longer leave a gap when section headers are turned off.",
                "Focus: quests ready to turn in stay listed when Current Zone Only is on, including click-to-complete quests that have no zone of their own.",
            },
        },
    },

    ["5.6.3"] = {
        date = "2026-08-24",
        {
            section = "Improvements",
            bullets = {
                "Marked current for World of Warcraft 12.1 so the addon no longer shows as out of date.",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Focus: clicking a tracked achievement opens the achievement journal again.",
            },
        },
    },

    ["5.6.2"] = {
        date = "2026-08-22",
        {
            section = "Improvements",
            bullets = {
                "Focus: background opacity change on mouseover — optional stronger backdrop and border only while the cursor is over the tracker.",
            },
        },
    },

    ["5.6.1"] = {
        date = "2026-08-20",
        {
            section = "Fixes",
            bullets = {
                "Augment: opening Edit Mode no longer errors when other addons show resource bars, such as Enhance QoL.",
            },
        },
    },

    ["5.6.0"] = {
        date = "2026-08-20",
        {
            section = "New Features",
            bullets = {
                "Vista: default and combat minimap opacity, with hover restoring the cluster to full opacity. At 0 the map hides so tracking icons disappear; hover the empty square to bring it back.",
            },
        },
    },

    ["5.5.3"] = {
        date = "2026-08-11",
        {
            section = "Fixes",
            bullets = {
                "Focus: Shrink to Fit Content applies on login and reload without toggling the setting.",
            },
        },
    },

    ["5.5.2"] = {
        date = "2026-08-09",
        {
            section = "Fixes",
            bullets = {
                "Augment: Accent toast style matches on loot and alert toasts again.",
            },
        },
    },

    ["5.5.1"] = {
        date = "2026-08-08",
        {
            section = "Fixes",
            bullets = {
                "Augment: Auto Vendor sells grey/junk items at merchants again, including items marked with the bag junk coin.",
            },
        },
    },

    ["5.5.0"] = {
        date = "2026-08-07",
        {
            section = "New Features",
            bullets = {
                "Augment: skinned personal loot window — when Auto Loot is off, the personal loot window stays usable and matches Compact / Framed / Accent toast chrome, with a drag position that persists across reload.",
            },
        },
    },

    ["5.4.1"] = {
        date = "2026-08-06",
        {
            section = "Fixes",
            bullets = {
                "Vista: Omnium Folio minimap button restored, with show, lock, size, and position options like other Vista buttons.",
            },
        },
    },

    ["5.4.0"] = {
        date = "2026-08-04",
        {
            section = "New Features",
            bullets = {
                "Augment: shared toast styles — Compact, Framed, or Accent chrome for loot toasts and status alerts, with matching slide and fade timing (chosen separately so both can match or differ). Fresh installs default both stacks to Framed.",
            },
        },
    },

    ["5.3.5"] = {
        date = "2026-08-02",
        {
            section = "Improvements",
            bullets = {
                "Augment: toast layout options — choose icon side, slide-in side, and grow direction separately for loot and alert toasts (including grow down for top-of-screen placement).",
            },
        },
    },

    ["5.3.4"] = {
        date = "2026-07-21",
        {
            section = "Improvements",
            bullets = {
                "Focus: Auto-Focus Behaviour — choose Always Closest, Respect Manual Focus, or Only When Unfocused so a nearby quest does not override the one you focused on purpose.",
            },
        },
    },

    ["5.3.3"] = {
        date = "2026-07-20",
        {
            section = "Fixes",
            bullets = {
                "Insight: Total RP 3 character info once again shows inside Horizon's tooltip, while Blizzard Edit Mode stays free of errors blamed on Horizon Suite.",
            },
        },
    },

    ["5.3.2"] = {
        date = "2026-07-18",
        {
            section = "Fixes",
            bullets = {
                "Insight: Player tooltips in battlegrounds and arenas no longer error when Midnight hides unit names from addons.",
            },
        },
    },

    ["5.3.1"] = {
        date = "2026-07-18",
        {
            section = "Fixes",
            bullets = {
                "Insight: Opening Blizzard Edit Mode with Total RP 3 no longer shows Boss Warnings errors blamed on Horizon Suite.",
            },
        },
    },

    ["5.3.0"] = {
        date = "2026-07-18",
        {
            section = "New Features",
            bullets = {
                "Augment: Alerts mini-module — Status toasts for low durability, bags nearly full, new mail, Great Vault rewards ready, and friends coming online/offline, with a Dashboard page, Edit Mode positioning, and per-kind toggles (off by default until you enable them).",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Core: Opening the Game Menu with EllesmereUI no longer triggers a protected-action error blamed on Horizon.",
                "Augment: Currency transfers no longer hit an action-forbidden error from loot-alert suppression.",
            },
        },
    },

    ["5.2.0"] = {
        date = "2026-07-10",
        {
            section = "New Features",
            bullets = {
                "Vista: Vista button for quick teleport overview (toys, hearthstones, etc.) — Minimap button opens a menu of unlocked teleports (hearthstones, profession, class, dungeon & raid, event) with favourites, recents, and cooldowns; cast in place without opening the map or bags.",
                "Focus: Proximity sort and auto-focus closest quest — New Proximity (Closest First) sort mode, plus an optional Auto-Focus Closest Quest toggle (/h focus autofocus and a keybind) that keeps the waypoint on the nearest quest.",
            },
        },
        {
            section = "Improvements",
            bullets = {
                "Focus: Total achievement points on Achievements header — Optional readout of your account achievement points on the Achievements section header (off by default).",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Options: Colour picker hex and RGB values stay readable with large fonts, the window collapses when opacity is unused, and it remembers its dragged position.",
            },
        },
    },

    ["5.1.2"] = {
        date = "2026-07-05",
        {
            section = "Improvements",
            bullets = {
                "Presence: the zone/area \"Discovered\" line now has its own font, outline, and size controls, instead of inheriting the subtitle font.",
            },
        },
    },

    ["5.1.1"] = {
        date = "2026-07-05",
        {
            section = "Improvements",
            bullets = {
                "General: general updates and fixes.",
                "Focus: the RareScanner and SilverDragon bridge add-ons now register as optional dependencies, so they load in the correct order and their integration alerts surface reliably.",
            },
        },
    },

    ["5.1.0"] = {
        date = "2026-06-19",
        {
            section = "New Features",
            bullets = {
                "Augment: quality-of-life mini-modules — Augment now splits into five independently-toggled features: Loot Toasts, Self Highlight (highlights your character in combat and when targeted by hostiles), Auto Vendor (auto-sells junk and repairs gear at merchants), Talking Head (customise the frame's font, position, and hold duration), and Achievement Tracker (auto-removes earned achievements from the objective tracker).",
                "Focus: RareScanner & SilverDragon integration — rare NPC, treasure, and event alerts now surface inside the Focus tracker, with a 3D portrait, click-to-waypoint coordinates (TomTom or map pin), click-to-target with a raid marker, Ctrl+Click Wowhead link copy, and a configurable alert queue; both appear in the Dashboard Integrations view.",
            },
        },
        {
            section = "Improvements",
            bullets = {
                "General: every colour swatch in the Options panel and Dashboard now opens a dark, Horizon-styled colour picker (wheel, brightness, hex/RGB entry, opacity, compare view) with an account-wide saved-colours palette shared across your characters.",
                "General: options sliders get a visual refresh — a gradient bar with a square handle and hover/drag feedback.",
                "Augment: loot toasts gain new options — show the item count before the name, and adjust icon size and icon-to-name spacing.",
                "Augment: the Style options are reworked into a cleaner two-column layout, and the text-outline toggle becomes an Outline Type dropdown (None / Thin / Thick).",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Insight: cursor-anchored tooltips no longer get stuck using the Fixed anchor's dynamic position after switching anchor modes.",
                "Insight: tooltips no longer get stuck in cursor mode in certain cases.",
                "General: fixed a frame leak in the hidden-quests list and a dropdown popup highlight-clipping issue.",
            },
        },
    },

    ["5.0.2"] = {
        date = "2026-06-02",
        {
            section = "Fixes",
            bullets = {
                "General: various bug fixes and taint error fixes.",
            },
        },
    },

    ["5.0.1"] = {
        date = "2026-05-29",
        {
            section = "Improvements",
            bullets = {
                "Axis: added an option to show or hide the Horizon Suite entry in the Esc game menu.",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Focus: the bullet point option is now selectable in the objective prefix dropdown.",
                "Dashboard: LibSharedMedia is now correctly detected as installed in the Integrations view when it loads on demand.",
                "Essence: custom fonts chosen via LibSharedMedia now display correctly, and a related refresh error has been fixed.",
                "Insight: resolved a frame-rate drop caused by repeated tooltip font hooks.",
            },
        },
    },

    ["5.0.0"] = {
        date = "2026-05-22",
        {
            section = "New Features",
            bullets = {
                "Augment: New Module — a full quality-of-life module with its own dashboard and settings, currently including the on-screen toast module for loot, currency and reputation (previously named \"Cache\").",
                "Dashboard: Integrations view — every third-party addon integrated with Horizon Suite now exists within a sidebar tab showing which are installed, disabled, or missing, with an Install link to each missing addon's CurseForge page and a Settings button into installed addons' own config.",
                "Insight: Total RP 3 profile integration — TRP3's character icon, name colour, IC/OOC badge, pronouns, race, class, guild, and Currently text now render inside the Insight-styled tooltip instead of a separate TRP3 frame.",
                "Core: in-game menu button — a Horizon Suite entry in the Esc menu that opens the dashboard.",
            },
        },
        {
            section = "Improvements",
            bullets = {
                "Focus: objectives can now be prefixed with a bullet point instead of the current hyphen or numbering system.",
                "Insight: a player's total achievement points may now be shown, with or without a modifier, next to a star in gold.",
                "Localisation: German update and general upkeep across all locales.",
                "Backend: began to introduce maintenance helpers and scaffolding for future upkeep.",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Focus: coloured shadow text in objective rows no longer leaks colour escape codes into the shadow string.",
            },
        },
    },

    ["4.18.2"] = {
        date = "2026-05-15",
        {
            section = "Fixes",
            bullets = {
                "Focus: quest entries no longer throw a Lua error when the tracked quest's zone is anything other than \"Activity\" (regression from 4.18.1).",
            },
        },
    },

    ["4.18.1"] = {
        date = "2026-05-15",
        {
            section = "Improvements",
            bullets = {
                "Localisation: strings now fall back to English only when a locale key is missing, surfacing untranslated entries instead of masking them with English text.",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Presence: World Quest complete sound is no longer suppressed when the Presence banner replaces the default Blizzard banner.",
            },
        },
    },

    ["4.18.0"] = {
        date = "2026-05-14",
        {
            section = "New Features",
            bullets = {
                "Presence: Talking Head customisation — fonts, colours, portrait/frame visibility, scale, and voice-over mute.",
                "Focus: Focused Quest category — super-tracked quests hoist into their own reorderable section.",
                "Focus: Mythic+ split timers — remaining time to the +1, +2, and +3 cut-offs, with crossed tiers dimmed.",
                "Insight: Tooltip preview window and new toggles — content-sized previews, Shift-modifier refresh, per-stat display modes, per-status-badge toggles, Spec-Override class icon, Realm Names and Section Separation dropdowns, and bundled race icons.",
            },
        },
        {
            section = "Improvements",
            bullets = {
                "Focus: Shrink-to-fit width — tracker grows to the longest visible row, capped at a configurable maximum.",
                "Focus: Progress bar text inherits the objective's category colour by default; the custom colour picker still overrides.",
                "Localisation: German locale refresh plus ongoing locale hygiene across the other non-English locales.",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Presence: Disabling Zone Notifications now hides them correctly.",
                "Focus: Objective lines with a leading dash no longer double up the bullet prefix.",
            },
        },
    },

    ["4.17.7"] = {
        date = "2026-05-09",
        {
            section = "Improvements",
            bullets = {
                "Vista: circular Horizon button variant to match SexyMap and HidingBar-style round minimap buttons.",
                "Presence: font outline options (None, Thin Outline, Thick Outline, Monochrome Outline, SLUG).",
                "Insight: suffix character titles now render correctly (including comma forms), with a new Title Colour mode picker (Match Name / Match Name (Gradient) / Custom).",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Insight: guild rank now displays correctly in player tooltips without realm name leakage.",
                "Vista: square minimap mode no longer errors when clearing the Horizon button's highlight texture.",
            },
        },
    },

    ["4.17.6"] = {
        date = "2026-05-08",
        {
            section = "Improvements",
            bullets = {
                "Focus: bar texture and colour changes now apply live without requiring a UI reload.",
                "Axis: Welcome and News content now honours the Dashboard Font option.",
                "Axis: choose a softer heading colour for the Dashboard Welcome and News blocks — previously locked to pure white, which is uncomfortable on HDR displays.",
            },
        },
    },

    ["4.17.5"] = {
        date = "2026-05-07",
        {
            section = "Fixes",
            bullets = {
                "Focus: Mythic+ block 'Always Show' toggle now previews the block outside of a Mythic+ dungeon — previously it did nothing. The toggle is reset to off on upgrade.",
            },
        },
    },

    ["4.17.4"] = {
        date = "2026-05-04",
        {
            section = "Improvements",
            bullets = {
                "Axis: SLUG, SLUG Outline, and SLUG Thick Outline are now selectable in the shared outline dropdown alongside Outline and Thick Outline.",
                "Localisation: English settings labels and tooltip descriptions now follow Title Case consistently.",
            },
        },
    },

    ["4.17.3"] = {
        date = "2026-05-02",
        {
            section = "Fixes",
            bullets = {
                "Localisation: non-English clients now display in the player's selected language again instead of falling back to English (regression introduced in 4.17.2).",
            },
        },
    },

    ["4.17.2"] = {
        date = "2026-05-02",
        {
            section = "Improvements",
            bullets = {
                "Focus: Ritual Site scenario headers now show their currency icons and progress values alongside the other objectives.",
                "Vista: choose a custom icon for the floating drawer button — accepts a Blizzard icon name or texture path.",
            },
        },
    },

    ["4.17.1"] = {
        date = "2026-04-29",
        {
            section = "Fixes",
            bullets = {
                "Insight: tooltip quality colour now matches the item's actual rarity instead of occasionally showing the wrong border and name colour.",
            },
        },
    },

    ["4.17.0"] = {
        date = "2026-04-28",
        {
            section = "New Features",
            bullets = {
                "Focus: static background size option — lock the Focus tracker background to a fixed size regardless of how many entries are tracked.",
            },
        },
        {
            section = "Improvements",
            bullets = {
                "Cache: per-module font picker with locale-aware default — Cyrillic, Korean, and other non-Latin glyphs now render correctly in the loot display, and each module can pick its own font.",
            },
        },
    },

    ["4.16.1"] = {
        date = "2026-04-26",
        {
            section = "Improvements",
            bullets = {
                "Vista: mail icon tooltip now lists senders like the default Blizzard tooltip.",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Focus: quest icon clicks in Blizzard+ mode now reliably focus the quest, even after the slot previously rendered a non-quest row.",
                "Focus: Auctionator search button now appears immediately on tracked recipe entries when the Auction House opens.",
            },
        },
    },

    ["4.16.0"] = {
        date = "2026-04-25",
        {
            section = "New Features",
            bullets = {
                "Axis: Dashboard smart open routing — the dashboard now resumes wherever you left it (including module sub-categories), and the Welcome page only appears once on first install.",
                "Axis: patch notes popup — on the first reload after an update, a small standalone popup shows the latest release notes instead of taking over the dashboard, so your last view is preserved.",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Vista: the Crafting Orders minimap icon no longer flashes briefly on characters with no pending orders.",
                "Vista: the Crafting Orders tooltip now lists each profession with a pending order beneath the total, instead of only showing a count.",
            },
        },
    },

    ["4.15.0"] = {
        date = "2026-04-24",
        {
            section = "New Features",
            bullets = {
                "Axis: settings overhaul begins — start of a broader Horizon settings and Dashboard overhaul. Axis is the first module to land with a reorganised, more consistent options layout; other modules will follow in subsequent releases.",
            },
        },
        {
            section = "Improvements",
            bullets = {
                "Axis: staged Reload UI for profile changes — profile toggles and dropdowns now queue a single reload prompt instead of reloading on every click, matching the Modules pattern.",
                "Axis: Dashboard class-colour controls — new master toggle gates the Dashboard's class-colour treatments, with sub-toggles for the class-colour background and class icon.",
                "Focus: Timer Text and Options Text fonts are now independent of the Title and Objective font settings.",
                "Vista: Crafting Orders minimap indicator — adds Crafting Orders support on the Vista minimap with the same trigger conditions as the default UI.",
                "Vista: unlocked minimap icons now render semi-transparent for a clear visual cue when they're in a movable state.",
                "Localisation: updated German (deDE) translations from a Discord submission.",
                "Localisation: options name labels now use headline-style capitalisation across the panel.",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Focus: daily recurring quests now appear in their own Daily section instead of being grouped under Weekly.",
                "Focus: collapsing then quickly re-expanding a category no longer leaves a blank space with no quests rendered.",
                "Focus: accepting a quest now animates in smoothly instead of popping the slot open and flashing into position.",
                "Focus: disabling a per-element font toggle now reverts that element to the global font immediately.",
                "Vista: Crafting Orders indicator now repairs correctly and honours the unified minimap drag positioning.",
                "Axis: toggling the minimap icon now saves immediately so the setting survives an instant reload.",
            },
        },
    },

    ["4.14.0"] = {
        date = "2026-04-22",
        {
            section = "New Features",
            bullets = {
                "Focus: Delve Nemesis groups indicator — while in a Delve, the main Focus row can show Nemesis enemy groups remaining (and the completed checkmark state).",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Focus: Blizzard+ Click Style — clicking a tracked line with the chat window open now shares the item to chat instead of untracking it, Ctrl+Left-click on collection items opens the preview/wardrobe, and Right-click → Open Collections navigates to the correct category and item.",
            },
        },
    },

    ["4.13.0"] = {
        date = "2026-04-21",
        {
            section = "New Features",
            bullets = {
                "Insight: Gradient tooltip fonts — item tooltips render in quality-colour gradients; player character tooltips use class-colour gradients.",
            },
        },
        {
            section = "Improvements",
            bullets = {
                "Focus: Significant performance improvements — quest update events are debounced, rare and treasure vignette scans are consolidated and cached, and layout passes are skipped when position hasn't changed.",
                "Vista: Minimap button collector now offers alphabetical sorting for a more predictable button order.",
            },
        },
    },

    ["4.12.6"] = {
        date = "2026-04-19",
        {
            section = "Improvements",
            bullets = {
                "Focus: hover tooltips now pin to the outer edge of the Horizon panel so they never cover the tracker, whether it's docked on the left or right side of the screen.",
                "Insight: new toggle keeps Focus tracker tooltips on the dynamic edge anchor even when all other Insight tooltips are pinned to a fixed position.",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Focus: hover tooltips (quests, rares, endeavors, recipes, LFG/AH buttons, floating quest item, M+ block) now honour the Insight anchor mode (Cursor / Fixed) instead of always opening right of the hovered widget.",
                "Insight: Cursor:Center anchor now correctly centres the tooltip at the cursor instead of using the Fixed anchor position.",
                "Focus: WoWhead click-combo hint now shows 'Shift + Left click' etc. instead of raw tokens like 'shiftLeft'.",
            },
        },
    },

    ["4.12.5"] = {
        date = "2026-04-18",
        {
            section = "Improvements",
            bullets = {
                "Focus: weekly meta quests now group under the Weekly section alongside other weekly-reset activities.",
                "Focus: completed-count suffixes (e.g. 0/1, 1/1) no longer appear on single-objective quests.",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Focus: tracked recipe title and objective colours now follow the Axis Colours Recipes swatches instead of forcing the default sage-green.",
                "Axis: profile switching now fully refreshes class colours, frame positions, and imported settings without requiring a reload.",
            },
        },
    },

    ["4.12.4"] = {
        date = "2026-04-16",
        {
            section = "Fixes",
            bullets = {
                "Insight: rolled back a recent change that was causing issues.",
            },
        },
    },

    ["4.12.3"] = {
        date = "2026-04-16",
        {
            section = "Improvements",
            bullets = {
                "Axis: module name style setting — Horizon (code-name only), Subtitle (e.g. 'Vista – Minimap'), or Simple (plain-language only). Applies across options navigation and headers.",
                "Focus: with Grow Upwards enabled, section header priority order now flips so High priority sits closest to the Objectives header.",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Focus: Current Event reappears for untracked World Quests when you enter their zone, without needing to re-track the quest.",
            },
        },
    },

    ["4.12.2"] = {
        date = "2026-04-14",
        {
            section = "Improvements",
            bullets = {
                "Insight: Gate NotifyInspect on player tooltip options — disabling every Player Characters option fully stops inspect requests on mouseover, so other inspect-dependent addons are no longer interrupted. A new 'Spec icon & role' toggle controls the spec/role display and its inspect query.",
            },
        },
    },

    ["4.12.1"] = {
        date = "2026-04-13",
        {
            section = "Fixes",
            bullets = {
                "Focus: Warbound weekly quests now sort and track correctly; right-click to untrack no longer fails for Warbound weeklies.",
                "Focus: Quest item button cooldowns now update properly while in combat.",
            },
        },
    },

    ["4.12.0"] = {
        date = "2026-04-12",
        {
            section = "New Features",
            bullets = {
                "Axis: resizable dashboard with corner grabber, saved size and position, and layout scaling helpers",
                "Axis: Ctrl+F opens dashboard search from the options UI; search focuses after sidebar changes",
            },
        },
        {
            section = "Improvements",
            bullets = {
                "Axis: handheld and narrow layouts — patch notes and headers reflow without overlap, constrained search bar, sensible sidebar scroll when content fits, accordions and two-column tiles adapt on resize",
                "Vista: minimap button visibility and related settings grouped under Vista with other minimap UI options",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Focus: tracked world quests open on the correct zone map instead of the wrong area view",
                "Axis: dashboard layout stays usable on very small or handheld-sized windows (overlap, width, and resize edge cases)",
            },
        },
    },

    ["4.11.0"] = {
        date = "2026-04-10",
        {
            section = "New Features",
            bullets = {
                "Axis: dashboard search page with pinned sidebar and layout polish",
                "Axis: filter dashboard search results by module",
                "Axis: welcome scrollable feed with detail wiring and locale strings",
                "Focus: custom click profiles for the objective tracker — map your own modifier combos to each row, or choose Horizon+ for Horizon Suite's unified preset and row actions",
            },
        },
        {
            section = "Improvements",
            bullets = {
                "Axis: overhaul welcome view, module guide, and home toggle cards",
                "Axis: welcome refresh and minimap-open keyboard fix",
                "Focus: unify objective tracker icon clicks with click profiles",
                "Axis: settings search — ranked matches, visible descriptions, search only on Search page",
                "Axis: All module filter omits settings for disabled modules (Axis options still shown)",
                "Axis: news refresh and Focus click options aligned with Blizzard+ profile and Horizon+ bindings",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Insight: unit and item tooltips avoid errors from Midnight secret-value APIs",
            },
        },
    },

    ["4.10.0"] = {
        date = "2026-04-08",
        {
            section = "New Features",
            bullets = {
                "Insight: cursor tooltips can anchor to the left, right, or center of the cursor, with optional offsets for left and right",
            },
        },
        {
            section = "Improvements",
            bullets = {
                "Axis: release zip no longer ships docs and tools (pkgmeta and ignore updates)",
                "Insight: item quality for tooltip chrome uses current item info data",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Focus: quest-complete row keeps the inline timer on timed click-to-complete quests",
                "Insight: world-cursor NPC tooltips — fewer errors and sturdier default cursor anchoring",
                "Insight: player tooltips keep custom styling when re-hovering the same unit",
                "Insight: unit tooltips keep addon lines after a Blizzard SetUnit refresh",
            },
        },
    },

    ["4.9.4"] = {
        date = "2026-04-07",
        {
            section = "Improvements",
            bullets = {
                "Insight: NPC subtitles stay visible when the custom level line is on (level on line three when line two is real subtitle text)",
            },
        },
    },

    ["4.9.3"] = {
        date = "2026-04-06",
        {
            section = "Improvements",
            bullets = {
                "Axis: dashboard body text size, outline dropdown, and shadow toggle (migrates older keys)",
                "Axis: option widget fonts refresh when dashboard typography changes",
                "Axis: home tiles — class-colour hover ring; clearer preview and coming-soon states",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Axis: settings search stays visible when opening a module after Welcome or Quick Start",
                "Focus: omit tracked quests whose title or objectives contain [DNT] placeholders",
            },
        },
    },

    ["4.9.2"] = {
        date = "2026-04-06",
        {
            section = "Improvements",
            bullets = {
                "Focus: quest type icons on by default for existing profiles (migration)",
                "Focus: header text case default matches tracker uppercase",
                "Axis: sidebar module row opens that module and highlights its header; Home and subcategory card chrome aligned; Quick Start path glyphs fixed; batched module toggles use one deferred reload",
                "Insight: hook-sourced tooltip flags avoid unsafe secret boolean checks on Midnight",
                "Vista: difficulty text anchored to the minimap, independent of zone text",
                "Localization: plain commented locale stubs and safer multiline restructure output",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Axis: dashboard options search accordion no longer overlaps after jump-to-match",
            },
        },
    },

    ["4.9.1"] = {
        date = "2026-04-06",
        {
            section = "Improvements",
            bullets = {
                "Axis: German (deDE) options and dashboard text refreshed from a contributor export, with locale files restructured to match English key order",
            },
        },
    },

    ["4.9.0"] = {
        date = "2026-04-05",
        {
            section = "New Features",
            bullets = {
                "Focus: Auctionator craft dialog from the tracker includes a crafting tier menu (1–5)",
                "Focus: right-click auction house recipe search from the tracker can multiply reagent quantities by your craft count",
            },
        },
        {
            section = "Improvements",
            bullets = {
                "Focus: auction craft dialog scales with your UI scale and Cancel/OK layout is clearer",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Insight: tooltip handling no longer spams Lua errors when the game restricts certain boolean checks",
            },
        },
    },

    ["4.8.6"] = {
        date = "2026-04-05",
        {
            section = "Fixes",
            bullets = {
                "Focus: Delves section only includes Delve-tagged log quests in a delve, not every nearby quest",
            },
        },
        {
            section = "Improvements",
            bullets = {
                "Focus: long objectives wrap correctly after zone or affix rows; wrapped affix lines keep objectives aligned on the left under the full block",
            },
        },
    },

    ["4.8.5"] = {
        date = "2026-04-05",
        {
            section = "Improvements",
            bullets = {
                "Focus: optional Events in Zone bucket — turn off under Sorting & Filtering to hide nearby unaccepted and zone-event quests from the tracker",
                "Axis: more dashboard background themes, compressed art, Teldrassil preset migrates to burning Teldrassil for existing profiles",
            },
        },
    },

    ["4.8.4"] = {
        date = "2026-04-05",
        {
            section = "Improvements",
            bullets = {
                "Focus: delve affix names keep your font; separators use the game font to avoid missing glyphs with decorative typefaces",
                "Focus: long delve affix lines wrap and objectives align under the full affix block",
            },
        },
    },

    ["4.8.3"] = {
        date = "2026-04-05",
        {
            section = "Improvements",
            bullets = {
                "Focus: tracked achievement rows with optional progress bars and description fallback",
                "Focus: compact recipe reagent list by default with optional full schematic detail",
                "Focus: Auctionator shopping lists from recipes include quantities",
                "Focus: quest level display without a separate remove-L toggle",
                "Axis: dashboard JPG backgrounds, expanded themes, options and locales",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Insight: unit tooltips no longer error on some targets (secret unit token)",
            },
        },
    },

    ["4.8.2"] = {
        date = "2026-04-03",
        {
            section = "New Features",
            bullets = {
                "Focus: tracker rows — transmog appearances (map, menu, waypoints), better quest completion from clicks, optional WoWhead tooltip line",
                "Insight: grouped thousands for long numbers in tooltips and UI text (shared with Focus)",
            },
        },
        {
            section = "Improvements",
            bullets = {
                "Focus: optional gold/green X/Y objective progress colours while in progress or complete",
                "Focus: coloured progress mode also tints the slash between counts for one consistent token",
                "Axis: dashboard background defaults to Midnight; old flat choices migrate once; flat style labelled Minimalistic",
                "Axis: Night Fae and Zin-Azshari background art bundled; legacy theme ids map to Midnight",
            },
        },
    },

    ["4.8.1"] = {
        date = "2026-04-03",
        {
            section = "Improvements",
            bullets = {
                "Axis: dashboard Welcome tab is built from a configurable feed and dedicated view so sections are easier to maintain and extend",
                "Focus: bar left and pill left highlights place quest type icons beside the bar and remove extra title padding when icons are shown",
            },
        },
    },

    ["4.8.0"] = {
        date = "2026-04-03",
        {
            section = "New Features",
            bullets = {
                "Focus: introducing Blizzard+ as the standard; profile-based quest row clicks (including Classic Click) are available now, with Horizon+ and further customisation coming soon",
            },
        },
        {
            section = "Improvements",
            bullets = {
                "Axis: configurable font and text size for the settings window",
                "Focus: when you resize quest type icons larger, bar-left and pill-left layouts keep them inside the tracker panel",
            },
        },
    },

    ["4.7.0"] = {
        date = "2026-04-03",
        {
            section = "New Features",
            bullets = {
                "Focus: tracked transmog appearances in the tracker with Horizon and classic clicks (super-track, dressing room, map/TomTom when enabled)",
                "Insight: custom class icons from the addon media folder",
            },
        },
        {
            section = "Improvements",
            bullets = {
                "Insight: tooltip pipeline and shared display tweaks",
                "Focus: section headers and category order use localized UI labels",
                "Axis: BLP class icons, dashboard welcome polish, and community footer updates",
                "Axis: dashboard footer intrinsic wordmark sizing, optimized textures, mixed-script welcome font",
            },
        },
    },

    ["4.6.1"] = {
        date = "2026-04-02",
        {
            section = "Improvements",
            bullets = {
                "Insight: optional hide tooltips in combat — toggle under Global Tooltips; frames close on combat start and stay suppressed while in combat",
                "Axis: Discord invite links updated in dashboard, READMEs, and GitHub issue template",
                "Axis: README and CurseForge listing refresh — clearer install steps and expanded listing copy",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Focus: world quest / tracker quest item hover no longer double-triggers the item tooltip (Insight fade flicker)",
                "Insight: tooltip fade-in dedupes item tooltips by stable item id when the link string changes on refresh",
            },
        },
    },

    ["4.6.0"] = {
        date = "2026-04-01",
        {
            section = "New Features",
            bullets = {
                "Axis: dashboard Quick Start guide, streamlined Welcome, and locale updates",
            },
        },
        {
            section = "Improvements",
            bullets = {
                "Insight: stop shopping tooltip fade flicker on minimap and world quest item tooltips",
                "Axis: dashboard welcome with community link icons, mixed-script contributors, and Cache hero art",
                "Vista: minimap mouse-wheel zoom only; overlay zoom controls removed; reset overlay positions",
                "Focus: Alt + Click hint next to WoWhead link in tooltip",
                "Focus: quest level next to titles shows as [60] instead of [L60] when level display is on",
                "Axis: patch notes attention, labelling, and dashboard polish",
                "Insight: unit tooltip dismiss options and deferred dismiss behaviour",
                "Insight: player-frame unit tooltips; choose faction or class colour for the player name on the first line",
                "Axis: What's New shows version dates and capitalizes module bullets",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Insight: unit tooltip frame no longer sometimes stays unskinned on refresh",
            },
        },
    },

    ["4.5.0"] = {
        date = "2026-03-31",
        {
            section = "New Features",
            bullets = {
                "Presence: optional progress toasts for achievements that are not tracked",
            },
        },
        {
            section = "Improvements",
            bullets = {
                "Focus: stable achievement tracking and content-tracking refresh",
                "Focus: quest row pool increased from 25 to 50",
                "Focus: scenario and delve updates with fewer FPS dips from less layout churn",
                "Focus: dim unfocused affects only quest rows",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Presence: achievement progress toast uses the correct criterion on multi-part achievements",
            },
        },
    },

    ["4.4.2"] = {
        date = "2026-03-31",
        {
            section = "Improvements",
            bullets = {
                "Vista: Minimap Horizon icon, optional Vista bar integration, fade until hover over the map, anchored tooltip when the button moves",
                "Axis: Modular options dashboard, profile import/export, URL copy dialog, tooling layout",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Focus: Dim strength and dim alpha apply consistently when dimming unfocused entries",
                "Focus: Text shadow offsets apply consistently across headers, titles, and controls",
            },
        },
    },

    ["4.4.1"] = {
        date = "2026-03-30",
        {
            section = "Fixes",
            bullets = {
                "Focus: In Raid and In Dungeon master visibility is honored before per-difficulty options, so the tracker hides when those masters are off",
            },
        },
    },

    ["4.4.0"] = {
        date = "2026-03-29",
        {
            section = "New Features",
            bullets = {
                "Localisation 2.0 — restructured strings and tooling",
                "Insight: tooltip options on separate pages with dashboard preview; cursor-follow tooltips and offsets; live preview and mount ownership on the dashboard",
                "Font dropdowns show each font in its own typeface",
                "Focus: zone-change tracker refresh; Insight: per-type tooltip options",
            },
        },
        {
            section = "Improvements",
            bullets = {
                "Options dashboard: modular layout under options/dashboard",
                "Module names use fixed English labels in the UI",
                "Insight: Midnight-safe unit tooltips, per-section font sizes, and polish",
                "Vista: minimap FPS/latency strip — urgency colours, smoother layout and drag",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Presence: scenario progress toast shows the full count on the last objective of a step",
            },
        },
    },

    ["4.3.1"] = {
        date = "2026-03-26",
        {
            section = "Improvements",
            bullets = {
                "Axis: Rename Yield and Persona modules to Cache and Essence",
                "Axis: Patch Notes — inline patch notes in the Dashboard",
                "Axis: Dashboard — Meridian coming-soon tile, locales, and welcome layout",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Insight: Tooltip enhancements work more cleanly with the default UI, without error popups",
            },
        },
    },

    ["4.3.0"] = {
        date = "2026-03-25",
        {
            section = "New Features",
            bullets = {
                "Axis: Unified class colours — batch toggle and per-module tinting",
                "Focus: Colour choices for global, headers, and objectives",
                "Axis: Dashboard class icon with shared class media",
                "Axis: Global toggles for class colours and scale; module options grouped for on/off and minimap",
                "Axis: Dashboard background option uses current specialisation talent art",
                "Axis: Welcome screen and dashboard refresh",
            },
        },
        {
            section = "Improvements",
            bullets = {
                "Insight: Defer tooltip width clamping for more reliable layout",
                "Insight: Fade out stale unit tooltips when mouseover clears",
            },
        },
    },

    ["4.2.2"] = {
        date = "2026-03-24",
        {
            section = "Fixes",
            bullets = {
                "Focus: Bonus objectives stay visible when scenario row has no real content",
                "Focus: Quest update toast shows wrong objective on multi-objective quests",
            },
        },
    },

    ["4.2.1"] = {
        date = "2026-03-24",
        {
            section = "Fixes",
            bullets = {
                "Focus: Bonus objectives stay visible when scenario row has no real content",
                "Focus: Quest update toast shows wrong objective on multi-objective quests",
            },
        },
    },

    ["4.2.0"] = {
        date = "2026-03-23",
        {
            section = "New Features",
            bullets = {
                "Axis: New installs start with Horizon modules off until you enable them",
                "Axis: Dashboard welcome tab and first-run onboarding",
            },
        },
        {
            section = "Improvements",
            bullets = {
                "Focus: Remaining delve lives on the scenario line",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Axis: Colour pickers for Focus and Vista no longer freeze the client or fail to apply colours",
                "Axis: Dashboard accordion cards only toggle from the header row",
            },
        },
    },

    ["4.1.2"] = {
        date = "2026-03-18",
        {
            section = "Improvements",
            bullets = {
                "Focus: WoWhead link in tracker tooltips and copy-link box",
                "Axis: Draggable minimap button with lock and reset options",
            },
        },
    },

    ["4.1.0"] = {
        date = "2026-03-18",
        {
            section = "New Features",
            bullets = {
                "Essence: Module preview — custom character sheet with 3D model, item level, stats, and gear grid",
                "Focus: Auctionator search button on recipe entries in the tracker",
            },
        },
        {
            section = "Improvements",
            bullets = {
                "Focus: Auctionator recipe search uses named shopping lists",
                "Insight: Tooltip fixes — item identity reapply, item data fallback, and mouseover hide",
            },
        },
    },

    ["4.0.0"] = {
        date = "2026-03-18",
        {
            section = "New Features",
            bullets = {
                "Axis: Minimap icon and settings panel integration",
                "Focus: Tracker header — toggle quest count, divider, colour, and options button",
                "Focus: Objectives can render outside the tracker window",
                "Focus: Category groupings can be individually toggled on or off",
            },
        },
        {
            section = "Improvements",
            bullets = {
                "Axis: Dashboard refreshes live when modules are toggled",
                "Axis: Class colour tinting for the dashboard (separate toggle)",
                "Insight: Now shows transmog status for trinkets, rings, and necks",
                "Focus: Optional tooltip on hover in the tracker",
                "Focus: Delve affix tooltips in the tracker",
                "Axis: Global font size offset added to options",
            },
        },
        {
            section = "Fixes",
            bullets = {
                "Focus: Delve name no longer shows incorrectly during the reward stage",
                "Focus: Tracker no longer shifts position on /reload",
                "Focus: World quest timers no longer tick back one second during refresh",
                "Focus: Text case handles umlauts and accented characters correctly",
            },
        },
    },

}
