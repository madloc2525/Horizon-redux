# Changelog

All notable changes to Horizon Suite are documented here.

---

## [Unreleased]

<!-- Changelog entries are generated from merged main PRs (enriched with referenced issues) at release time. -->

---

## [6.11.1] – 2026-10-20

### 🐛 Fixes
- **(Focus)** Tracked achievements now list only the criteria you still need by default, as Blizzard's tracker does. Turn off Missing Criteria Only to see every criterion.
- **(Focus)** In Minimal mode the header chevron and Options text stay hidden after a reload, and they disappear again when the cursor leaves the tracker.

---

## [6.11.0] – 2026-10-19

### ✨ New Features
- **(Focus) Reverse sort order** — A new Reverse order switch under Sorting flips the Quest level, Alphabetical and Zone sorts, so you can work through your lowest-level quests first or read your list Z to A. Quests that tie stay in A to Z order.

### 🐛 Fixes
- **(Axis)** The bottom of a settings page is no longer cut off after it opens; Focus → Layout scrolls all the way down to the Spacing options again.

---

## [6.10.0] – 2026-10-18

### ✨ New Features
- **(Focus) Focused quest highlights** — Active quest highlight now offers Left bar, Right bar, Gradient fade, Pointer, Coloured title and None, and none of them push your quests out of line. Each style keeps its own colour and turns green when the quest is ready to turn in, and with Show progress on the bars light up in four steps as you complete objectives.

### 🔧 Improvements
- **(Focus) Fewer, cleaner highlight styles** — Top bar, Bottom bar, Outline, Glow, Dual bars, Pill accent and Highlight have been retired. If you used one, you're moved to Left bar or Gradient fade automatically.

---

## [6.9.0] – 2026-10-16

### ✨ New Features
- **(Augment) Faster auto-loot** — With auto-loot on, every item on a corpse is taken at once; anything that won't fit in your bags stays behind and the loot window opens straight away showing just those. Off by default: turn it on under Augment → Loot Frame → Loot window.
- **(Augment) Recipe learned alerts** — The "new recipe learned" pop-up can show in your Horizon alert style, and Train all at a trainer shows one "12 Recipes Learned" alert instead of one per recipe. Off by default: turn on Recipe learned in Augment Alerts.

### 🐛 Fixes
- **(Axis)** Hovering Reset loot window position no longer raises a Lua error, and settings search no longer shows "function: 0x…" as a setting's description.

---

## [6.8.1] – 2026-10-14

### 🐛 Fixes
- **(Augment)** Gold, currency and reputation toasts no longer play the friend-online chime: gold plays the coin clink, currency and reputation play the loot toast sound, and the durability, bags and mail alerts play a neutral chime.
- **(Focus)** Quest items the game can't look up no longer flood chat with a warning every second, and their cooldown shows on the quest item button again.
- **(Axis)** The Integrations page shows an installed add-on built for a different game version as "Out of date" instead of calling it missing.

---

## [6.8.0] – 2026-10-12

### ✨ New Features
- **(Vista) Map icon size** — A new slider under Layout → Size & shape resizes the inn, repair and herb icons on the minimap without switching Vista off. Both it and Minimap size now redraw as you drag.

### 🐛 Fixes
- **(Focus)** Lock position now only controls the lock: it can be turned off with Shrink to fit on, and both the header and the body obey it.
- **(Focus)** Turning on Shrink to fit redraws every quest in full instead of cutting entries off half-way with gaps between sections.
- **(Augment)** The money, currency and reputation toast sounds play the toast chime again, and the durability, bags and mail alerts do too.

---

## [6.7.1] – 2026-10-11

### 🐛 Fixes
- **(Focus · Forever)** Group quests no longer show a group finder eye that does nothing when clicked; its option is greyed out until Forever supports group search.
- **(Echo)** Long messages stay inside their chat bubble instead of spilling their last word into the next one.

---

## [6.7.0] – 2026-10-09

### ✨ New Features
- **(Axis) Rebuilt settings dashboard** — Every on-screen element now has one card, with its switch at the top and everything for it underneath, across every module. Related settings sit under topic headings inside each card.
- **(Axis) Smarter settings search** — Search forgives typos, understands synonyms, highlights what matched, remembers recent searches and takes you straight to the setting.
- **(Axis) New Welcome and News pages** — Welcome shows every module at a glance with its on or off state, and News carries what's new in each version, with stories you can open.
- **(Echo) Choose what Enter opens** — Pressing Enter to talk can open All chat instead of Nearby. It stays on Nearby unless you change it.

### 🔧 Improvements
- **(Axis) A cleaner settings window** — A modern look, a matching icon for every module, shorter labels, and smooth animation as sub-settings appear and disappear.
- **(Axis) See what you've changed** — A marker shows which settings differ from their defaults, each with a reset arrow, and every card shows how many of its settings you've changed.
- **(Axis)** Font, size and outline now sit together on one row.

### 🐛 Fixes
- **(Axis)** Settings that did nothing now work, and settings that can't apply right now are greyed out instead of silently ignored.

---

## [6.6.0] – 2026-10-05

### ✨ New Features
- **(Presence) Move the zone and quest text anywhere** — Drag the zone-entry and quest text from the settings page or Blizzard's Edit Mode, or set its position with two sliders, which helps on multi-monitor setups. Opening Edit Mode shows an empty box to drag, and Shift-clicking it plays a sample.
- **(Echo) Timestamps on conversations** — A new switch shows the time beside each message, just outside its bubble. It starts off, so nothing changes unless you turn it on.

### 🐛 Fixes
- **(Augment)** Opening Edit Mode no longer fills the screen with sample loot rolls and alerts; Shift-click a loot box to see a sample.
- **(Augment)** With Blizzard's controller interface on, Blizzard's loot window no longer flashes up beside Augment's loot toast when auto-looting.
- **(Echo)** Long messages sent in dungeons and fights fit inside their chat bubble instead of spilling into the next message.

---

## [6.5.1] – 2026-10-04

### ✨ New Features
- **(Focus) Hide the group finder button** — A new Focus option hides the group finder eye beside group quests, and the quest text uses the space it leaves. It starts on, so nothing changes unless you turn it off.

### 🐛 Fixes
- **(Augment)** With auto-loot on, items you can't pick up, such as when your bags are full, show in the loot window straight away instead of after several clicks.
- **(Augment)** With Blizzard's controller interface on, taking loot no longer triggers a "blocked action" warning; the loot window keeps Blizzard's own look in that mode.
- **(Core)** With Blizzard's controller interface on, the Escape menu no longer triggers a "blocked action" warning. Horizon Suite's button is left off that menu in controller mode, and `/horizon` still opens the settings.

---

## [6.5.0] – 2026-10-03

### ✨ New Features
- **(Augment) Separate switches for loot toasts and the loot window**: The Loot Frame page has two new switches, Loot Toasts and Loot Window Skin, so you can keep Augment's toasts with Blizzard's loot window, or the skinned loot window with Blizzard's loot alerts. Both start on, so nothing changes unless you turn one off.

### 🐛 Fixes
- **(Vista)** The queue eye and the Omnium Folio button sit behind the World Map instead of drawing on top of it.
- **(Augment)** With auto-loot on, Blizzard's loot window no longer flashes up beside Augment's loot toast. Looting by hand opens it as before.

---

## [6.4.1] – 2026-10-02

### 🐛 Fixes
- **(Core · Forever)** Horizon Suite recognises World of Warcraft: Forever again after the October 1 beta update, so dungeons and zones are no longer labelled as Delves, and settings for systems Forever does not have stay hidden.

---

## [6.4.0] – 2026-10-01

### ✨ New Features
- **(Augment) Ribbon and Rail toast styles**: Two new looks for loot toasts, alerts, loot rolls, Echo pop-ups and the loot window. Ribbon is a colour wash fading away from the icon, and Rail is a dark bar with a thin coloured stripe along the icon's edge.
- **(Augment) Card toast style**: A larger icon in a framed box, with a second line on loot toasts showing the item level and slot for gear, the type for other items, and your new total for gold and currencies. It can be picked anywhere the other styles can.

---

## [6.3.1] – 2026-09-30

### 🐛 Fixes
- **(Focus)** Quest level colours match the game's own quest log again, so a quest a few levels below you shows green instead of yellow.
- **(Insight)** Tooltip level colours match the game's target frame again, so a mob a few levels below you shows green instead of yellow.

---

## [6.3.0] – 2026-09-30

### ✨ New Features
- **(Augment) Square Framed border**: The Framed look for loot toasts, alerts, loot rolls and the loot window can use square corners instead of rounded ones, with a border thickness set in screen pixels so it stays crisp at any UI scale. Rounded stays the default.
- **(Focus) Quest level colours**: With Quest Level on, each quest's level is coloured by how hard it is for you (grey, green, yellow, orange or red), matching the game's quest log. It has its own switch, and it starts on.

### 🐛 Fixes
- **(Presence)** Boss emotes show once again, in Presence's style only, instead of also appearing in the game's own red text. Raid leader warnings are unaffected.

---

## [6.2.0] – 2026-09-29

### ✨ New Features
- **(Echo) Combat log in Echo**: With Blizzard's chat hidden, the combat log moves into Echo on its own tile. Opening it shows Blizzard's combat log, filter buttons and all, and it stays open when a fight starts. The new Combat log setting keeps it in Blizzard's own tab or hides it instead.

---

## [6.1.0] – 2026-09-28

### ✨ New Features
- **(Insight) Grow direction for fixed tooltips**: When tooltips are anchored to a fixed spot, choose whether they grow up and right, up and left, down and right, or down and left from the anchor. Automatic keeps the current behaviour and stays the default.
- **(Insight) Difficulty and target colours**: A creature's level is coloured by how hard it is for you, matching the game's nameplates, and the name on the Targeting line is coloured by class for players or by reaction for everything else. Each colour has its own switch, and both start on.

### 🔧 Improvements
- **(Echo)** Echo's highlight colour follows your class colour when you turn it on in Axis, and the "all modules" switch now includes Echo. Other people's colours stay their own.

### 🐛 Fixes
- **(Echo)** Right-clicking a player's line in the All feed offers Whisper and Invite as well as Pin, including on WoW: Forever.
- **(Echo)** On WoW: Forever, Echo uses your full name with surname in emotes, the All feed and pinned messages, and group members with surnames show their class colour.
- **(Axis)** The Discord button in the dashboard footer links to the current server again.

---

## [6.0.0] – 2026-09-27

### ✨ New Features
- **(Echo) New module**: Echo gives every conversation its own tile on the edge of your screen: each person you whisper, Battle.net friends, party, raid, guild, your channels, and feeds for loot, progress and system messages. Hover a tile to peek at the latest messages and reply, or click it to read the whole conversation as a thread. Whispers and guild chat are kept between sessions, any message can be pinned, and channels can share one tile with a tab for each. While Echo is on it takes the place of Blizzard's chat windows, with Blizzard's own input line docked beneath it so slash commands and replies work as before, and the combat log stays where it is. Echo starts switched off: turn it on under Axis → Modules and reload.

### 🔧 Improvements
- **(Augment)** Loot roll frames follow your loot toast style unless you have already chosen a style for them, and Match Loot Toasts now heads the roll frame style list.
- **(Augment)** The Modules page no longer labels Augment as a Preview module.

---

## [5.11.0] – 2026-09-26

### ✨ New Features
- **(Augment) Loot roll frames**: When your group rolls on loot, Horizon draws its own Need and Greed frame. It shows who has rolled so far and who is winning, whether the item's appearance is new to you, how its item level compares with what you have equipped, and whether it binds on pickup. Rolls below the quality you choose, and any beyond the number of frames you allow on screen, keep Blizzard's own frame, so no roll goes missing. Find it under Augment → Loot Rolls, and try it with Show Demo Rolls, which needs no group.

### 🐛 Fixes
- **(Presence)** Switching off an achievement, achievement progress or world quest notification brings back the game's own version of it immediately, with no need to turn Presence off.
- **(Presence)** Switching off zone names or area names brings back the game's own versions of them. With zone names off, area names no longer keep showing when the settings say they are off.
- **(Focus)** The dungeon run tracker no longer shows an error when a system chat message arrives inside a dungeon.

---

## [5.10.0] – 2026-09-20

### ✨ New Features
- **(Focus) Dungeon run tracker** — In any party dungeon that is not a Mythic+ run, a banner above the tracker shows how long you have been inside, the experience and money you have earned, and the rate of each per hour. Hover it for the bosses you have defeated, how long the next level is at your current pace, and a button to start the run over. The run carries on through a reload, and picks up where it left off after a corpse run.

### 🔧 Improvements
- **(Core)** Patch notes give the core of the addon its own colour, and each entry that applies to only one client carries a coloured badge naming it.

---

## [5.9.1] – 2026-09-19

### 🐛 Fixes
- **(Core · Forever)** Dungeons and cities are no longer treated as Delves, so the tracker heading, its colour and the zone banner say what you are actually in.
- **(Insight · Forever)** A character's surname appears once in the tooltip header instead of twice.
- **(Essence)** The character panel shows your full name, surname included, and a suffix title such as "the Explorer" no longer comes through cut short.
- **(Focus)** Switching the tracker off and back on without reloading brings its entries back, instead of leaving section headings over blank space.

---

## [5.9.0] – 2026-09-18

### ✨ New Features
- **(Core) World of Warcraft: Forever** — Horizon Suite now loads on the Forever beta from the same package as Retail. Settings for systems Forever does not have (Mythic+, Delves, housing, the Great Vault, specialisations and the Traveler's Log) stay out of the way there, and `/h platform` shows what your client supports. Known beta issue: the Forever client does not yet read saved settings back at login, so settings reset on reload until Blizzard fixes it.

### 🔧 Improvements
- **(Core)** SubtleGrind joins the supporters wall on the Welcome page.
- **(Core)** A module that fails to start now says so in chat instead of silently staying off.

---

## [5.8.0] – 2026-09-12

### ✨ New Features
- **(Focus) Frame strata** — Choose which layer the tracker draws on, so it sits in front of or behind other addon windows instead of competing with them on the default layer. Dialogs and tooltips always stay above it.

---

## [5.7.0] – 2026-09-09

### ✨ New Features
- **(Insight) Specialisation and hero talent on player tooltips** — The class line names the specialisation and ends with a colour-coded role tag, and the active hero talent sits on its own line beneath it. Both can be turned off independently under Insight › Player Characters › Class.

### 🐛 Fixes
- **(Insight)** The role tag no longer goes missing from the identity line when Total RP 3's race and class display is turned on.

---

## [5.6.5] – 2026-09-06

### 🐛 Fixes
- **(Core)** The patch notes panel was empty after updating to 5.6.4. Those notes now appear in game, below this release.

---

## [5.6.4] – 2026-09-06

### 🐛 Fixes
- **(Focus)** Collapsed categories no longer leave a gap when section headers are turned off.
- **(Focus)** Quests ready to turn in stay listed when Current Zone Only is on, including click-to-complete quests that have no zone of their own.

---

## [5.6.3] – 2026-08-24

### 🔧 Improvements
- Marked current for World of Warcraft 12.1 so the addon no longer shows as out of date.

### 🐛 Fixes
- **(Focus)** Clicking a tracked achievement opens the achievement journal again.

---

## [5.6.2] – 2026-08-22

### 🔧 Improvements
- **(Focus) Background opacity change on mouseover** — Optional stronger backdrop, and a border, only while the cursor is over the tracker.

---

## [5.6.1] – 2026-08-20

### 🐛 Fixes
- **(Augment)** Opening Edit Mode no longer errors when other addons show resource bars, such as Enhance QoL.

---

## [5.6.0] – 2026-08-20

### ✨ New Features
- **(Vista)** Default and combat minimap opacity, with hover restoring the cluster to full opacity. At 0 the map hides so tracking icons disappear; hover the empty square to bring it back.

---

## [5.5.3] – 2026-08-11

### 🐛 Fixes
- **(Focus)** Shrink to Fit Content applies on login and reload without toggling the setting.

---

## [5.5.2] – 2026-08-09

### 🐛 Fixes
- **(Augment)** Accent toast style matches on loot and alert toasts again.

---

## [5.5.1] – 2026-08-08

### 🐛 Fixes
- **(Augment)** Auto Vendor sells grey/junk items at merchants again, including items marked with the bag junk coin.

---

## [5.5.0] – 2026-08-07

### ✨ New Features
- **(Augment) Skinned personal loot window** — When Auto Loot is off, the personal loot window stays usable and matches Compact / Framed / Accent toast chrome, with a drag position that persists across reload.

---

## [5.4.1] – 2026-08-06

### 🐛 Fixes
- **(Vista)** Omnium Folio minimap button restored, with show, lock, size, and position options like other Vista buttons.

---

## [5.4.0] – 2026-08-04

### ✨ New Features
- **(Augment) Shared toast styles** — Compact, Framed, or Accent chrome for loot toasts and status alerts, with matching slide and fade timing (chosen separately so both can match or differ). Fresh installs default both stacks to Framed.

---

## [5.3.5] – 2026-08-02

### 🔧 Improvements
- **(Augment) Toast layout options** — Choose icon side, slide-in side, and grow direction separately for loot and alert toasts (including grow down for top-of-screen placement).

---

## [5.3.4] – 2026-07-21

### 🔧 Improvements
- **(Focus) Auto-Focus Behaviour** — Choose Always Closest, Respect Manual Focus, or Only When Unfocused so a nearby quest does not override the one you focused on purpose.

---

## [5.3.3] – 2026-07-20

### 🐛 Fixes
- **(Insight)** Total RP 3 character info once again shows inside Horizon's tooltip, while Blizzard Edit Mode stays free of errors blamed on Horizon Suite.

---

## [5.3.2] – 2026-07-18

### 🐛 Fixes
- **(Insight)** Player tooltips in battlegrounds and arenas no longer error when Midnight hides unit names from addons.

---

## [5.3.1] – 2026-07-18

### 🐛 Fixes
- **(Insight)** Opening Blizzard Edit Mode with Total RP 3 no longer shows Boss Warnings errors blamed on Horizon Suite.

---

## [5.3.0] – 2026-07-18

### ✨ New Features
- **(Augment) Alerts mini-module** — Status toasts for low durability, bags nearly full, new mail, Great Vault rewards ready, and friends coming online/offline, with a Dashboard page, Edit Mode positioning, and per-kind toggles (off by default until you enable them).

### 🐛 Fixes
- **(Core)** Opening the Game Menu with EllesmereUI no longer triggers a protected-action error blamed on Horizon.
- **(Augment)** Currency transfers no longer hit an action-forbidden error from loot-alert suppression.

---

## [5.2.0] – 2026-07-10

### ✨ New Features
- **(Vista) Vista button for quick teleport overview (toys, hearthstones, etc.)** — Minimap button opens a menu of unlocked teleports (hearthstones, profession, class, dungeon & raid, event) with favourites, recents, and cooldowns; cast in place without opening the map or bags.
- **(Focus) Proximity sort and auto-focus closest quest** — New Proximity (Closest First) sort mode, plus an optional Auto-Focus Closest Quest toggle (`/h focus autofocus` and a keybind) that keeps the waypoint on the nearest quest.

### 🔧 Improvements
- **(Focus) Total achievement points on Achievements header** — Optional readout of your account achievement points on the Achievements section header (off by default).

### 🐛 Fixes
- **(Options)** Colour picker hex and RGB values stay readable with large fonts, the window collapses when opacity is unused, and it remembers its dragged position.

---

## [5.1.2] – 2026-07-05

### 🔧 Improvements
- **(Presence)** The zone/area "Discovered" line now has its own font, outline, and size controls in Presence typography, instead of inheriting the subtitle font.

---

## [5.1.1] – 2026-07-05

### 🔧 Improvements
- **(General)** General updates and fixes.
- **(Focus)** The RareScanner and SilverDragon bridge add-ons now register as optional dependencies, so they load in the correct order and their integration alerts surface reliably.

---

## [5.1.0] – 2026-06-19

### ✨ New Features
- **(Augment) Quality-of-life mini-modules** — Augment now splits into five independently-toggled features: Loot Toasts, **Self Highlight** (highlights your character in combat and when targeted by hostiles), **Auto Vendor** (auto-sells junk and repairs gear at merchants), **Talking Head** (customise the Talking Head frame's font, position, and hold duration), and **Achievement Tracker** (auto-removes earned achievements from the objective tracker).
- **(Focus) RareScanner & SilverDragon integration** — Rare NPC, treasure, and event alerts from RareScanner and SilverDragon now surface inside the Focus tracker, with a 3D portrait, click-to-waypoint coordinates (TomTom or map pin), click-to-target with a raid marker, Ctrl+Click Wowhead link copy, time-since-detection, and a configurable alert queue. RareScanner alerts also show loot rows. Both appear as cards in the Dashboard Integrations view.

### 🔧 Improvements
- **(General) Horizon colour picker** — Every colour swatch in the Options panel and the Dashboard now opens a dark, Horizon-styled colour picker (hue/saturation wheel, brightness bar, hex and R/G/B entry, opacity, and a current-vs-new compare) with an account-wide saved-colours palette shared across all your characters.
- **(General)** Options sliders get a visual refresh — a gradient bar with a square handle and hover/drag feedback.
- **(Augment)** Loot toasts gain new options: show the item count before the name (`3 x Boarpelt`), and adjust icon size and icon-to-name spacing.
- **(Augment)** The Augment Style options are reworked into a cleaner two-column layout, and the text-outline toggle becomes an Outline Type dropdown (None / Thin / Thick).

### 🐛 Fixes
- **(Insight)** Cursor-anchored tooltips no longer get stuck using the Fixed anchor's dynamic position after switching anchor modes.
- **(Insight)** Tooltips no longer get stuck in cursor mode in certain cases.
- **(General)** Fixed a frame leak in the hidden-quests list and a dropdown popup highlight-clipping issue.

---

## [5.0.2] – 2026-06-02

### 🐛 Fixes
- **(General)** Various bug fixes and taint error fixes.

---

## [5.0.1] – 2026-05-29

### 🔧 Improvements
- **(Axis) Game Menu button toggle** — Added an option to show or hide the Horizon Suite entry in the Esc game menu.

### 🐛 Fixes
- **(Focus)** The bullet point option is now selectable in the objective prefix dropdown.
- **(Dashboard)** LibSharedMedia is now correctly detected as installed in the Integrations view when it loads on demand.
- **(Essence)** Custom fonts chosen via LibSharedMedia now display correctly, and a related refresh error has been fixed.
- **(Insight)** Resolved a frame-rate drop caused by repeated tooltip font hooks.

---

## [5.0.0] – 2026-05-22

### ✨ New Features
- **(Augment) New Module** — A full quality-of-life module with its own dashboard and settings. It currently includes our on-screen toast module for loot, currency and reputation (previously named "Cache").
- **(Dashboard) Integrations view** — Every third-party addon integrated with Horizon Suite now exists within a sidebar tab, showing at a glance which are installed, disabled, or missing. Each missing addon comes with an Install ↗ link directed to that addon's CurseForge page, while Installed addons come with a Settings ⚙ button that leads into the addon's own config.
- **(Insight) Total RP 3 profile integration** — Total RP 3's custom character icon, name colour, IC/OOC badge, pronouns, race, class, guild, and "Currently" text now render inside the existing Insight-styled tooltip rather than a separate TRP3 frame.
- **(Core) In-game menu button** — A "Horizon Suite" entry in the Esc game menu (between Shop and AddOns) that opens the dashboard.

### 🔧 Improvements
- **(Focus) Bullet point prefix** — Objectives can now be prefixed with a bullet point instead of the current hyphen or numbering system.
- **(Insight) Achievement points** — A player's total achievement points may now be shown, with or without a modifier next to a star in gold.
- **(Localisation)** German update and general upkeep across all locales.
- **(Backend) Refactor** — Began to introduce maintenance helpers and scaffolding for future upkeep.

### 🐛 Fixes
- **(Focus)** Coloured shadow text in objective rows no longer leaks colour escape codes into the shadow string.

---

## [4.18.2] – 2026-05-15

### 🐛 Fixes
- **(Focus)** Quest entries no longer throw "attempt to index a nil value" when the tracked quest's zone is anything other than "Activity" (regression from 4.18.1 locale-fallback hardening).

---

## [4.18.1] – 2026-05-15

### 🔧 Improvements
- **(Localisation)** Strings now fall back to English only when a locale key is missing, surfacing untranslated entries instead of masking them with English text.

### 🐛 Fixes
- **(Presence)** World Quest complete sound is no longer suppressed when the Presence banner replaces the default Blizzard banner.

---

## [4.18.0] – 2026-05-14

### ✨ New Features

- **(Presence) Talking Head customisation** — A new sub-category under Presence that lets you style Blizzard's Talking Head frame without a separate addon:
  - Enable/disable the frame entirely
  - Mute the voice-over independently of game volume
  - Separate font family, outline, and size for both the NPC name and dialogue text
  - Name colour picker
  - Show/hide the NPC portrait and decorative frame ring
  - Show/hide the cinematic background and close button
  - Frame scale (0.5×–2.0×)
- **(Focus) Focused Quest category** — Super-tracked quests hoist into their own reorderable **FOCUSED QUEST** section so the focused quest can be pinned anywhere in the tracker — including just above the bottom-anchored header when grow-up is enabled.
- **(Focus) Mythic+ split timers** — The M+ block adds a split-timer line showing remaining time to the +1, +2, and +3 cut-offs. Tiers you've already crossed dim out so it's clear at a glance which upgrades are still reachable. Configurable font size and colour, with a separate colour for crossed tiers.
- **(Insight) Tooltip Preview window & new toggles** — The dashboard preview now sizes player, NPC, and item tooltips to fit their actual content rather than a shared fixed width. Live player tooltips gain Shift-modifier refresh, per-stat (Mythic+ / item level / honor) Force/Modifier/Hide modes, per-status-badge toggles (Combat, AFK, DND, PvP, Group, Friend, Targeting You), a Spec-Override class-icon mode, a Realm Names dropdown, a Section Separation dropdown, and bundled race icons, including the new Haranir race plus Dracthyr and its Visage form.

### 🔧 Improvements

- **(Focus) Shrink-to-fit width** — The Focus tracker can grow in width to fit the longest visible row, capped at a configurable maximum, so progress bars no longer stretch wider than the tracked content needs.
- **(Focus) Progress bar text inherits objective colour** — Progress label text ("3/10 (30%)") now matches its category-aware objective colour by default instead of near-white, while a custom Progress Bar Text Colour pick still overrides.
- **Localisation** — German locale refreshed, plus ongoing locale hygiene across the other non-English locales.

### 🐛 Fixes

- **(Presence)** Disabling Zone Notifications now hides them correctly.
- **(Focus)** Objective lines with a leading dash no longer double up the bullet prefix.

---

## [4.17.7] – 2026-05-09

### 🔧 Improvements

- **(Vista) Circular Horizon button** — A round minimap-button variant so the Horizon icon matches addons like SexyMap and HidingBar that style their buttons round.
- **(Presence) Font outline options** — Presence text gains the same outline picker as the rest of the addon (None, Thin Outline, Thick Outline, Monochrome Outline, SLUG).
- **(Insight) Character titles and title colour** — Suffix titles now render correctly (including comma-prefixed forms like *"Aragorn, the Argent Champion"*), and a new Title Colour dropdown lets you pick **Match Name**, **Match Name (Gradient)**, or **Custom**.

### 🐛 Fixes

- **(Insight)** Guild rank now displays correctly in player tooltips — no more realm name leaking into the rank slot, and the rank sits inline beside the guild name.
- **(Vista)** Square minimap mode no longer errors when clearing the Horizon button's highlight texture.

---

## [4.17.6] – 2026-05-08

### 🔧 Improvements

- **(Focus)** Bar texture and colour changes now apply live without requiring a UI reload.
- **(Axis)** Welcome and News content now respects the Dashboard Font option instead of using a hardcoded font.
- **(Axis) Configurable Dashboard heading colour** — Choose a softer accent colour for the Welcome and News headings so pure white at full HDR luminance no longer dominates the UI.

---

## [4.17.5] – 2026-05-07

### 🐛 Fixes

- **(Focus)** Mythic+ block "Always Show" toggle now displays the block as a preview when you're outside a Mythic+ dungeon — previously it had no effect. The toggle is reset to off on upgrade so the new preview doesn't appear unexpectedly. Tooltip wording updated to match.

---

## [4.17.4] – 2026-05-04

### 🔧 Improvements

- **(Axis) SLUG font outline options** — The shared outline dropdown now offers SLUG, SLUG Outline, and SLUG Thick Outline choices alongside the existing Outline and Thick Outline variants.
- **Localisation** — English settings labels and tooltip descriptions now follow Title Case consistently (e.g. "Focus Objective Tracker", "Loot Toast Font", "Tooltip Anchor Mode").

---

## [4.17.3] – 2026-05-02

### 🐛 Fixes

- **Localisation** — Non-English clients (German, Spanish, French, Korean, Brazilian Portuguese, Simplified Chinese) once again display in the player's selected language instead of falling back to English. A file load order regression in 4.17.2 caused English strings to overwrite every translation at startup.

---

## [4.17.2] – 2026-05-02

### 🔧 Improvements

- **(Focus) Ritual Site objective counters** — Ritual Site scenario headers now display their currency icons and progress values alongside the rest of the scenario objectives.
- **(Vista) Configurable drawer icon picker** — When the floating drawer button is enabled, you can now choose a custom Blizzard icon or texture path for it instead of being stuck with the default.

---

## [4.17.1] – 2026-04-29

### 🐛 Fixes

- **(Insight)** Tooltip quality colour now matches the item's actual rarity instead of occasionally showing the wrong border and name colour.

---

## [4.17.0] – 2026-04-28

### ✨ New Features

- **(Focus) Static Background Size** — Optionally lock the Focus tracker background to a fixed size so it stays consistent regardless of how many quests, M+ timers, or scenarios are tracked.

### 🔧 Improvements

- **(Cache) Per-module font picker with locale-aware default** — Cyrillic, Korean, and other non-Latin glyphs now render correctly in the loot display, and each module can pick its own font.

---

## [4.16.1] – 2026-04-26

### 🔧 Improvements

- **(Vista)** Mail icon tooltip now lists senders like the default Blizzard tooltip — see who sent each piece of mail without opening the mailbox.

### 🐛 Fixes

- **(Focus)** Quest icon clicks in Blizzard+ mode now reliably focus the quest, even after the slot previously rendered a non-quest row.
- **(Focus)** Auctionator search button now appears immediately on tracked recipe entries when the Auction House opens.

---

## [4.16.0] – 2026-04-25

### ✨ New Features

- **(Axis) Dashboard smart open routing** — The dashboard now resumes wherever you left it (including module sub-categories), and the Welcome page only appears once on first install.
- **(Axis) Patch notes popup** — On the first reload after an update, a small standalone popup shows the latest release notes instead of taking over the dashboard, so your last view is preserved. "View all patch notes" jumps to the full history.

### 🐛 Fixes

- **(Vista)** The Crafting Orders minimap icon no longer flashes briefly on characters with no pending orders.
- **(Vista)** The Crafting Orders tooltip now lists each profession with a pending order beneath the total, instead of only showing a count.

---

## [4.15.0] – 2026-04-24

### ✨ New Features

- **(Axis) Settings overhaul — Axis first** — Start of a broader Horizon settings and Dashboard overhaul. Axis is the first module to land with a reorganised, more consistent options layout; other modules will follow in subsequent releases.

### 🔧 Improvements

- **(Axis) Staged Reload UI for profile changes** — Toggling Global profile, switching the current profile, enabling Spec Profiles, or picking a per-spec profile now stages a single "Reload UI" prompt (matching the Modules pattern) instead of reloading on every click. Dependent widgets update their enabled state live.
- **(Axis) Dashboard class-colour controls** — New master toggle gates the Dashboard's class-colour treatments, with sub-toggles for the class-colour background override and the class icon so each can be turned on independently.
- **(Focus) Independent Timer and Options fonts** — Timer Text and Options Text are no longer tied to the Title/Objective fonts and can be styled independently.
- **(Vista) Crafting Orders minimap indicator** — Adds Crafting Orders support to the Vista minimap with the same appearance and triggering conditions as the Blizzard default.
- **(Vista) Unlocked icons render semi-transparent** — Vista minimap icons now display semi-transparent when unlocked, providing a clear visual cue that they're in a movable state.
- **(Localisation)** Updated German (deDE) translations from a Discord submission.
- **(Localisation)** Options name labels now use headline-style capitalisation across the panel.

### 🐛 Fixes

- **(Focus)** Daily recurring quests now appear in their own Daily section instead of being grouped under Weekly.
- **(Focus)** Collapsing then quickly re-expanding a category no longer leaves a blank space with no quests rendered.
- **(Focus)** Accepting a quest now animates in smoothly instead of popping the slot open and flashing into position.
- **(Focus)** Disabling a per-element font toggle now reverts that element to the global font immediately.
- **(Vista)** Crafting Orders indicator now repairs correctly and honours the unified minimap drag positioning.
- **(Axis)** Toggling the minimap icon now saves immediately so the setting survives an instant reload.

---

## [4.14.0] – 2026-04-22

### ✨ New Features

- **(Focus) Delve Nemesis groups indicator** — While in a Delve, the main Focus row can show Nemesis enemy groups remaining (and the completed checkmark state).

### 🐛 Fixes

- **(Focus)** Blizzard+ Click Style: clicking a tracked line with the chat window open now shares the item to chat instead of untracking it, Ctrl+Left-click on collection items opens the preview/wardrobe window, and Right-click → Open Collections navigates to the correct category and item instead of the default first tab.

---

## [4.13.0] – 2026-04-21

### ✨ New Features
- **(Insight) Gradient tooltip fonts** — Item tooltips render in quality-colour gradients; player character tooltips use class-colour gradients.

### 🔧 Improvements
- **(Focus)** Significant performance improvements — quest update events are debounced, rare and treasure vignette scans are consolidated and cached, and layout passes are skipped when position hasn't changed.
- **(Vista)** Minimap button collector now offers alphabetical sorting for a more predictable button order.

---

## [4.12.6] – 2026-04-19

### 🔧 Improvements

- **(Focus) Tooltip no longer covers the tracker** — Focus hover tooltips now pin to the outer edge of the Horizon panel so they never overlap the tracker, whether the panel is docked on the left or right side of the screen.
- **(Insight) Dynamic Focus tooltips in Fixed mode** — New toggle keeps Focus tracker tooltips on the dynamic edge anchor even when all other Insight tooltips stay pinned to the fixed position.

### 🐛 Fixes

- **(Focus)** Focus hover tooltips (quests, rares, endeavors, recipes, LFG/AH buttons, floating quest item, M+ block) now honour the Insight anchor mode (Cursor / Fixed) instead of always anchoring right of the hovered widget.
- **(Insight)** Cursor:Center anchor now correctly centres the tooltip at the cursor instead of switching to the Fixed anchor position.
- **(Focus)** WoWhead click-combo hint now shows "Shift + Left click" and its variants instead of raw tokens like `shiftLeft`.

---

## [4.12.5] – 2026-04-18

### 🔧 Improvements

- **(Focus) Meta quests under Weekly** — Weekly meta quests now group under the Weekly section alongside other weekly-reset activities.
- **(Focus) Completed count tidier** — Completed-count suffixes (e.g. `0/1`, `1/1`) no longer appear on single-objective quests.

### 🐛 Fixes

- **(Focus)** Tracked recipe title and objective colours now follow the Axis Colors **Recipes** swatches instead of forcing the default sage-green.
- **(Axis)** Profile switching now fully refreshes class colours, frame positions, and imported settings without requiring a reload.

---

## [4.12.4] – 2026-04-16

### 🐛 Fixes

- **(Insight)** Rolled back a recent change that was causing issues.

---

## [4.12.3] – 2026-04-16

### 🔧 Improvements

- **(Axis) Module name style** — New setting to control how module names appear: **Horizon** (code-name only, default), **Subtitle** (e.g. "Vista – Minimap"), or **Simple** (plain-language name only). Applies across options navigation and section headers.
- **(Focus) Grow Upwards priority order** — With **Grow Upwards** enabled, section headers now visually flip so High priority sits closest to the Objectives header at the bottom, matching the reversed growth direction.

### 🐛 Fixes

- **(Focus)** Current Event now reappears for World Quests you have **untracked** when you enter their zone, so the in-area event banner works without needing to re-track the quest.

---

## [4.12.2] – 2026-04-14

### 🔧 Improvements

- **(Insight) Gate NotifyInspect on player tooltip options** — Disabling every option under Player Characters now fully stops Insight from sending inspect requests on player mouseover, so other inspect-dependent addons are no longer interrupted. A new "Spec icon & role" toggle controls the spec/role line and its inspect query.

---

## [4.12.1] – 2026-04-13

### 🐛 Fixes

- **(Focus)** Warbound weekly quests now sort and track correctly; right-click to untrack no longer fails for Warbound weeklies.
- **(Focus)** Quest item button cooldowns now update properly while in combat.

---

## [4.12.0] – 2026-04-12

### ✨ New Features

- **(Axis)** **Resizable dashboard** with a **corner grabber**, **saved size and position**, and shared **layout scaling** helpers
- **(Axis)** **Ctrl+F** opens dashboard **search** from the options UI, and the search field is **focused** after you change **sidebar** sections

### 🔧 Improvements

- **(Axis)** **Handheld and narrow layouts** — patch notes and headers reflow without overlap, the **search bar** stays constrained, the **sidebar** scroll resets sensibly when content fits, and **accordions** / **two-column tiles** adapt on resize
- **(Vista)** **Minimap button** visibility and related settings are grouped under **Vista** with other minimap UI options

### 🐛 Fixes

- **(Focus)** Tracked **world quests** open on the **correct zone map** instead of the wrong area view
- **(Axis)** Dashboard layout stays **usable** on very **small** or **handheld-sized** windows — overlap, width, and resize **edge cases**

---

## [4.11.0] – 2026-04-10

### ✨ New Features

- **(Axis)** Dashboard **search page** with pinned sidebar entry and layout polish
- **(Axis)** Dashboard search: **filter results by module**
- **(Axis)** Welcome **scrollable feed** with detail wiring and locale strings
- **(Focus)** **Custom click profiles** for the objective tracker — map your own modifier combos to each row, or choose **Horizon+** for Horizon Suite's unified preset and row actions

### 🔧 Improvements

- **(Axis)** Overhaul **welcome** view, module guide, and home toggle cards
- **(Axis)** Welcome refresh and **minimap-open** keyboard fix
- **(Focus)** Unify **objective tracker icon** clicks with click profiles
- **(Axis)** **Settings search** — ranked matches, visible descriptions, and search bar only on the Search page
- **(Axis)** **All** module filter omits settings for **disabled** modules (Axis options still appear)
- **(Axis)** **News** refresh and copy aligned with Focus click options and Horizon+ / Blizzard+ defaults

### 🐛 Fixes

- **(Insight)** Unit and item tooltips avoid errors from **Midnight secret-value** API usage

---

## [4.10.0] – 2026-04-08

### ✨ New Features

- **(Insight)** Tooltip anchoring — cursor-follow tooltips can appear to the **left**, **right**, or **center** of the cursor, with optional offsets when using left or right

### 🔧 Improvements

- **(Axis)** Release packages no longer include internal **docs** and **tools** folders after packager and ignore updates
- **(Insight)** Item quality used for tooltip styling follows current item info data more reliably

### 🐛 Fixes

- **(Focus)** Quest-complete row no longer wipes the **inline countdown** on timed click-to-complete quests
- **(Insight)** **World-cursor** NPC tooltips — fewer errors and sturdier default cursor anchoring
- **(Insight)** **Player** tooltips keep custom styling when you move away and hover the same unit again
- **(Insight)** **Unit** tooltips keep addon content when Blizzard refreshes the frame via SetUnit

---

## [4.9.4] – 2026-04-07

### 🔧 Improvements

- **(Insight)** NPC tooltips keep Blizzard’s subtitle on the second line when the custom level line is enabled — level moves to line three when the subtitle is real content, not the level row

---

## [4.9.3] – 2026-04-06

### 🔧 Improvements

- **(Axis)** Dashboard typography: body text size in pixels, outline style dropdown, and text shadow toggle, with migration from older offset/outline/shadow keys
- **(Axis)** Option widgets pick up font flag changes when dashboard typography is updated
- **(Axis)** Home module tiles: class-coloured hover ring and clearer preview and coming-soon idle and hover states

### 🐛 Fixes

- **(Axis)** Settings search bar stays visible when you open a module after Welcome or Quick Start
- **(Focus)** Tracked quests that use `[DNT]` placeholder titles or objectives are left out of the tracker

---

## [4.9.2] – 2026-04-06

### 🔧 Improvements

- **(Focus)** Quest type icons are on by default for existing profiles (saved migration)
- **(Focus)** Header text case option default matches the tracker’s uppercase style
- **(Axis)** Dashboard sidebar: clicking a module row opens that module’s view and highlights its header
- **(Axis)** Home and subcategory cards use aligned chrome; Quick Start path glyphs fixed
- **(Axis)** Batching module on/off toggles applies a single deferred UI reload
- **(Insight)** Tooltip flags use hook-sourced state to avoid unsafe Midnight secret boolean checks
- **(Vista)** Difficulty text is anchored to the minimap, independent of the zone label
- **(Localization)** Locale restructure uses plain commented stubs (no `NEEDS TRANSLATION` suffix); multiline commented stubs and tooling updated accordingly

### 🐛 Fixes

- **(Axis)** Dashboard options search: accordion rows no longer overlap after jumping to a match

---

## [4.9.1] – 2026-04-06

### 🔧 Improvements

- **(Axis)** German (deDE) options and dashboard strings updated from a contributor export — many new or revised translations (appearances, click actions, context menu, backgrounds, Presence options); all locale files aligned with English key order via restructure

---

## [4.9.0] – 2026-04-05

### ✨ New Features

- **(Focus)** Auctionator craft dialog from the tracker includes a crafting tier menu (1–5)
- **(Focus)** Right-click auction house recipe search from the tracker can multiply reagent quantities by your craft count

### 🔧 Improvements

- **(Focus)** Auction craft dialog scales with your UI scale and Cancel/OK layout is clearer

### 🐛 Fixes

- **(Insight)** Tooltip handling no longer spams Lua errors when the game restricts certain boolean checks (e.g. Mythic+)

---

## [4.8.6] – 2026-04-05

### 🐛 Fixes

- **(Focus)** Delves section only picks up Delve-tagged quests from your log while you’re in a delve, instead of treating every nearby quest as Delve content

### 🔧 Improvements

- **(Focus)** Long objective lines wrap within the tracker after zone or affix rows, and wrapped affix names keep the first objective left-aligned under the full affix block

---

## [4.8.5] – 2026-04-05

### 🔧 Improvements

- **(Focus)** Optional Events in Zone content — turn off under Sorting & Filtering → Grouping to hide nearby unaccepted and zone-event quests from the tracker
- **(Axis)** More dashboard background themes, smaller JPG bundles, Teldrassil preset becomes a burning Teldrassil image with automatic migration for existing profiles

---

## [4.8.4] – 2026-04-05

### 🔧 Improvements

- **(Focus)** Delve affix names keep your tracker font; middle-dot separators use the game font so narrow fonts no longer show missing glyphs between modifiers
- **(Focus)** Long delve affix lists wrap within the tracker width and objectives sit below the full affix block instead of overlapping

---

## [4.8.3] – 2026-04-05

### 🔧 Improvements

- **(Focus)** Tracked achievement rows in the tracker with optional progress bars and description fallback
- **(Focus)** Recipe tooltips use a compact reagent list by default, with an option for full schematic detail
- **(Focus)** Auctionator shopping lists built from recipes include quantities
- **(Focus)** Quest level next to titles no longer relies on a separate “remove L” toggle
- **(Axis)** Dashboard JPG background bundles, expanded themes, updated options and locales

### 🐛 Fixes

- **(Insight)** Unit tooltips no longer error when hovering certain targets (secret unit token)

---

## [4.8.2] – 2026-04-03

### ✨ New Features

- **(Focus)** Tracker row interactions — transmog appearances (map, context menu, waypoints where enabled), clearer completion from clicks on finished quests, optional WoWhead line on tooltips, and new locale strings
- **(Insight)** Long numeric runs in tooltip and UI text can show thousands grouping (shared formatting with Focus objective lines)

### 🔧 Improvements

- **(Focus)** Optional colours on X/Y objective progress (gold in progress, green when complete) — toggle under Focus display
- **(Focus)** When objective count colouring is on, the slash between X and Y uses the same tint so the whole token reads as one styled unit
- **(Axis)** Module dashboard background defaults to Midnight; existing flat defaults migrate once; the flat style is labelled Minimalistic in settings
- **(Axis)** Bundled Night Fae and Zin-Azshari dashboard background art; legacy stored theme ids normalise to Midnight while the options list stays streamlined

---

## [4.8.1] – 2026-04-03

### 🔧 Improvements

- **(Axis)** Dashboard Welcome tab is driven by a configurable feed and a dedicated view, so announcements and sections are easier to maintain and extend
- **(Focus)** Bar left and Pill left active-quest highlights place the quest type icon beside the highlight bar and align quest titles without extra left padding when icons are shown

---

## [4.8.0] – 2026-04-03

### ✨ New Features

- **(Focus)** Introducing Blizzard+ as the standard for Focus; profile-based quest row clicks (including Classic Click) ship now, with Horizon+ and further customisation coming soon.

### 🔧 Improvements

- **(Axis)** Configurable font and text size for the Axis settings window
- **(Focus)** Resizing quest type icons keeps them inside the tracker panel for bar-left and pill-left active-quest highlights

---

## [4.7.0] – 2026-04-03

### ✨ New Features

- **(Focus)** Tracked transmog appearances in the tracker — Horizon and classic click behaviour, stable super-track, optional map/TomTom and dressing room
- **(Insight)** Custom class icons from files in the addon media folder

### 🔧 Improvements

- **(Insight)** Tooltip pipeline and shared display tweaks
- **(Focus)** Section headers and category order use localized UI labels
- **(Axis)** BLP class icons, dashboard welcome polish, and community footer updates
- **(Axis)** Dashboard footer — intrinsic wordmark sizing, optimized textures, mixed-script welcome font

---

## [4.6.1] – 2026-04-02

### 🔧 Improvements

- **(Insight)** Optional hide tooltips in combat — toggle under Insight → Global Tooltips closes styled tooltip frames when you enter combat and blocks them from staying open while fighting
- **(Axis)** Discord invite links updated in the dashboard, READMEs, and GitHub issue template so community links point at the current server
- **(Axis)** README and CurseForge listing refresh — clearer install steps, expanded CurseForge page copy, Basic Commands table removed from short READMEs

---

## [4.6.0] – 2026-04-01

### ✨ New Features

- **(Axis)** Dashboard Quick Start guide, streamlined Welcome, and locale updates

### 🔧 Improvements

- **(Insight)** Stop shopping tooltip fade flicker on minimap and world quest item tooltips
- **(Axis)** Dashboard welcome — community links with icons, mixed-script contributor text, and Cache hero art
- **(Vista)** Minimap — mouse-wheel zoom only; overlay zoom controls removed; reset overlay positions
- **(Focus)** Show Alt + Click hint next to WoWhead link in tooltip
- **(Focus)** Quest level next to titles uses bracketed numbers (e.g. `[60]`) instead of an `L` prefix (`[L60]`) when level display is enabled
- **(Axis)** Patch notes attention, labelling, and dashboard polish
- **(Insight)** Unit tooltip dismiss options and deferred dismiss behaviour
- **(Insight)** Player-frame unit tooltips; choose faction or class colour for the player name on the first line
- **(Axis)** What's New — version dates and capitalized module bullets

### 🐛 Fixes

- **(Insight)** Unit tooltip frame sometimes stays unskinned on refresh

---

## [4.5.0] – 2026-03-31

### ✨ New Features

- **(Presence)** Untracked achievements — optional progress toasts when an achievement is not on the tracker

### 🔧 Improvements

- **(Focus)** Stable achievement tracking and content-tracking refresh
- **(Focus)** Quest row pool increased from 25 to 50
- **(Focus)** Scenario and delve updates — fewer FPS dips from reduced layout churn
- **(Focus)** Dim unfocused applies only to quest rows, not achievements, endeavors, or rares

### 🐛 Fixes

- **(Presence)** Achievement progress toast showed the wrong criterion for multi-part achievements

---

## [4.4.2] – 2026-03-31

### 🔧 Improvements

- **(Vista)** Minimap — Horizon icon refresh, optional Vista collector integration, fade until the cursor is over the map, and tooltip anchored to the minimap button when it moves or resizes
- **(Axis)** Core and options dashboard — modular dashboard layout, profile import/export, URL copy dialog, and tooling layout updates

### 🐛 Fixes

- **(Focus)** Dim strength and dim alpha apply consistently when dimming unfocused entries
- **(Focus)** Text shadow offsets apply consistently across section headers, quest titles, and related controls

---

## [4.4.1] – 2026-03-30

### 🐛 Fixes

- **(Focus)** Turning off In Raid or In Dungeon for the tracker now hides it reliably — master visibility is applied before per-difficulty raid/dungeon options, so stale granular settings no longer keep the panel visible.

---

## [4.4.0] – 2026-03-29

### ✨ New Features

- **(Axis)** Localisation 2.0 — restructured string files and maintainer tooling
- **(Insight)** Tooltip options split across focused pages with a contextual dashboard preview
- **(Insight)** Cursor-follow tooltips with optional position offsets
- **(Axis)** Font dropdowns show each option in its own typeface
- **(Insight)** Live Insight tooltip preview on the dashboard; mount ownership in relevant tooltips
- **(Focus)** Zone changes refresh tracker rows reliably
- **(Insight)** Per-type tooltip styling options

### 🔧 Improvements

- **(Axis)** Options dashboard — modular layout under options/dashboard
- **(Axis)** Horizon module names use consistent English labels in the UI
- **(Insight)** Midnight-safe unit tooltips, per-section font sizes, and polish
- **(Vista)** Minimap FPS/latency strip — urgency colours on values, improved layout and dragging (no extended performance hover panel)

### 🐛 Fixes

- **(Presence)** Scenario progress toast shows the full count on the last objective of a step

---

## [4.3.1] – 2026-03-26

### 🔧 Improvements

- **(Axis)** Rename Yield and Persona modules to Cache and Essence
- **(Axis)** What's New — inline patch notes in the Dashboard
- **(Axis)** Dashboard — Meridian coming-soon tile, locales, and welcome layout

### 🐛 Fixes

- **(Insight)** Tooltip enhancements work more cleanly with the default UI, without error popups

---

## [4.3.0] – 2026-03-25

### ✨ New Features

- **(Axis)** Unified class colours — batch toggle and per-module tinting
- **(Focus)** Colour choices for global accents, headers, and objectives
- **(Axis)** Dashboard class icon using shared class icon media
- **(Axis)** Global toggles for class colours and scale; module options grouped for on/off and minimap
- **(Axis)** Dashboard background can use your current specialization’s talent art
- **(Axis)** Welcome screen and dashboard refresh

### 🔧 Improvements

- **(Insight)** Defer tooltip width clamping for more reliable tooltip layout
- **(Insight)** Fade out stale unit tooltips when mouseover clears

---

## [4.2.2] – 2026-03-24

### 🐛 Fixes

- **(Axis)** In-game What's New includes the 4.2.1 Focus and Presence fixes — patch notes data was missing from the 4.2.1 build, and the panel only shows entries for the current version

---

## [4.2.1] – 2026-03-24

### 🐛 Fixes

- **(Focus)** Bonus objectives stay visible when scenario row has no real content
- **(Presence)** Quest update toast shows wrong objective on multi-objective quests

---

## [4.2.0] – 2026-03-23

### ✨ New Features

- **(Axis)** New installs start with Horizon modules off until you enable them
- **(Axis)** Dashboard welcome tab and first-run onboarding — Welcome sidebar above Home; first options open can show Welcome once per profile, then Home by default

### 🔧 Improvements

- **(Focus)** Remaining delve lives on the Focus tracker scenario line — at-a-glance during a run without extra panels

### 🐛 Fixes

- **(Axis)** Options colour pickers for Focus and Vista no longer freeze the client or fail to apply colours
- **(Axis)** Dashboard accordion cards expand and collapse only from the header row, not when clicking settings inside the card

---

## [4.1.2] – 2026-03-18

### 🔧 Improvements

- **(Focus) WoWhead link in Focus tracker tooltips and copy-link box**
- **(Axis) Draggable minimap button with lock and reset options**

### 🐛 Fixes

- **(Axis) Fix release pipeline YAML parse error in debug lines**

---

## [4.1.0] – 2026-03-18

### ✨ New Features

- **(Profile) Add Essence module (Preview): custom character sheet with 3D model, item level, stats, gear grid**
- **(Focus) Auctionator search button on recipe entries in Focus tracker**

### 🔧 Improvements

- **(Focus) Auctionator recipe search: use CreateShoppingList and named lists**
- **(Insight) Insight tooltip fixes: item identity reapply, GetItem fallback, mouseover hide**
- **(Core) Promote Insight to stable**

---

## [4.0.0] – 2026-03-18

### ✨ New Features

- **(Focus) Dev mode: show Blizzard tracker alongside Focus for comparison**
- **(Focus) Objectives can render outside the tracker window**
- **(Focus) Focus tracker header options: quest count, divider, color, height, options button**
- **(Focus) Groupings toggle on or off**
- **(Core) Minimap icon and WoW settings panel integration**

### 🔧 Improvements

- **(Core) Beta release zip no longer returns 404 when job artifacts expire**
- **(Core) Discord issuelog: rename Improvements to Improvement Requests**
- **(Core) Dashboard live refresh when modules are toggled**
- **(Core) Refactor color matrix to compact cards and add Section Overrides**
- **(Core) Restructure locale system, add locale debug and CI audit, improve options panel and Focus grouping**
- **(Core) Global font size offset and options panel visibility improvements**
- **(Vista) Minimap button fades in on hover**
- **(Focus) Defer map event handlers to avoid taint; show delve affix tooltip on hover**
- **(Core) Dashboard class colours: separate toggle and live refresh**
- **(Insight) Insight tooltip shows transmog status for trinkets, rings, necks**
- **(Core) Merge Profiles and Modules into single Axis group in options dashboard**
- **(Core) Dashboard: version API fallback, clean card/tile teardown, and sidebar collapse hides child tabs**
- **(Core) Release announcements include direct CurseForge and Wago links**
- **(Core) Cache: Draggable anchor frame for repositioning loot toasts**
- **(Core) Dashboard: Back button, sidebar state, and Focus colours refactor**
- **(Core) Animated card relayout when options visibility changes**
- **(Core) Options dashboard: hide dependent options when parent toggle is off**
- **(Core) Compact options widgets and move descriptions to tooltips**
- **(Focus) Setting to show or hide tooltips on hover in Focus tracker**
- **(Focus) Spacing preset dropdown (Default, Compact, Spaced, Custom) and title-to-content gap**
- **(Focus) Scenario tracker: stage line, objective deduplication, and current event suppression**
- **(Focus) French: Dedicated Traque Section**
- **(Insight) Insight tooltip options: background opacity, blank separator, show icons; remove accent bar**
- **(Insight) Optional RondoMedia class icons in Insight tooltips**

### 🐛 Fixes

- **(Focus) Delve name shows wrong or disappears during reward stage**
- **(Core) Relayout animation cancellation leaves card in inconsistent state**
- **(Core) Dashboard sidebar stays synced across home, module, and category views**
- **(Core) Fix Discord release announcement embed size limit**
- **(Presence) Fix stale 0/X in delve and scenario completion text**
- **(Focus) Focus tracker moves on /reload**
- **(Focus) Tracker panel nudges when toggling grow-up off**
- **(Focus) World Quest and task quest timers tick back up one second during refresh**
- **(Focus) Quest Level: Lowercase "L"**
- **(Focus) Typography: Improper Proper Case**

---

## [3.11.6] – 2026-03-13

### 🐛 Fixes

- **(Focus) Abundance scenario detection fails for localized clients** — use localized strings for scenario name and objective detection (Abondance, Überfluss, etc.)

---

## [3.11.5] – 2026-03-13

### 🐛 Fixes

- **(Focus) Bonus objectives not showing when entering zone** — e.g. Saltheril's Soiree; cache invalidation and relaxed map check
- **(Core) Defensive guard for OptionsWidgetsDef in Dashboard collapsible groups** — prevents nil error when opening options

---

## [3.11.4] – 2026-03-13

### 🐛 Fixes

- **(Presence) Zone change errors: attempt to index global 'L' (a nil value)**

---

## [3.11.3] – 2026-03-13

### 🔧 Improvements

- **(Presence) Animate preview button for Presence toast notifications in options**
- **(Core) Sidebar scroll height and sub-button parenting during category collapse**
- **(Presence) Live preview of Presence toast types in options with optional detached window**
- **(Core) Dashboard chevrons and sidebar polish**
- **(Presence) QUEST_UPDATE notifications use quest category color**
- **(Insight) Character title in player tooltip name line with configurable color**
- **(Presence) Presence individual notification sizes (large, medium, small)**
- **(Focus) Prey quest detection: relax colon requirement and improve French (Traque) localization**

---

## [3.11.2] – 2026-03-13

### 🐛 Fixes

- **(Insight) Player tooltip formatting not showing on first hover**

### 🔧 Improvements

- **(Core) Update README branding and links for GitLab migration**
- **(Core) Fix beta release job when release already exists**
- **(Core) Dashboard: add sidebar navigation and layout refinements**
- **(Core) Dashboard and options panel polish**
- **(Focus) Scenario timer bar updates every 0.5s instead of 1s**
- **(Focus) Localize Prey quest detection for Midnight hunting activity**
- **(Presence) Achievement toast shows redundant 1/1 for single-objective achievements when objective is finished**
- **(Insight) Improve Insight item tooltips: fix AH flashing, quality identity, transmog filter**

---

## [3.11.1] – 2026-03-11

### 🐛 Fixes

- **(Focus) Fix grow-up mode: scroll position and arrow overlay on header**

### 🔧 Improvements

- **(Core) Localization workflow: LocaleBase as source of truth**

---

## [3.11.0] – 2026-03-10

### 🐛 Fixes

- **(Insight) Insight tooltip content sometimes spills out of container for NPCs**
- **(Focus) Scenario tracker: fix weighted progress when quantity is percentage (0-100)**

### ✨ New Features

- **(Focus) Shift-click to link quests, achievements, endeavors, recipes, and adventure guide in chat;

### 🔧 Improvements

- **(Vista) 24-hour clock toggle for Vista time display**
- **(Vista) Class colour tinting for Vista and options panel**
- **(Core) Vertical scrollbar for options panel main content**
- **(Focus) Scenario tracker improvements**

---

## [3.10.0] – 2026-03-09

### ✨ New Features

- **(Focus) Progress bar texture selection via SharedMedia** — Choose progress bar fill textures (Blizzard, Solid, or addon packs). New dropdown in Focus Display options with search.

---

## [3.9.6] – 2026-03-08

### 🔧 Improvements

- **(Core) Update README contributors and localizations list** — Add allmoon as Chinese (zhCN) contributor; add Chinese and German to localizations list.
- **(Core) LocaleBase fallback and zhCN support** — Add zhCN locale fallback and Chinese localization support.

---

## [3.9.5] – 2026-03-08

### 🐛 Fixes

- **(Focus) Focus tracker only updates after combat ends during world scenarios** — Tracker (including world scenario objectives) now updates during combat.

---

## [3.9.4] – 2026-03-08

### 🐛 Fixes

- **(Presence) Quest objective text shows wrong progress (e.g. 2 instead of 8/12)** — Single-step strip pattern no longer incorrectly matches "8/1" in "8/12"; quest update toasts now display correct progress.

---

## [3.9.3] – 2026-03-08

### 🐛 Fixes

- **(Focus) Guard layout against combat lockdown** — Tracker layout no longer errors when updated during combat.

### 🔧 Improvements

- **(Focus) Exclude world quests from Current Quest grouping** — World quests no longer appear in the Current Quest group.
- **(Focus) Classic mode: quest icon click to super-track, Shift+Left to unfocus** — Click the quest icon to super-track; Shift+Left to unfocus or untrack.
- **(Presence) Scenario notifications: omit 1/1 from single-step objectives** — Single-step objectives no longer show redundant "1/1" in scenario toasts.

---

## [3.9.2] – 2026-03-07

### 🐛 Fixes

- **(Focus) Scenario tracker: suppress progress bar for boolean objectives and fix weighted progress edge case** — Boolean (yes/no) objectives no longer show incorrect progress bars; weighted progress handles edge cases correctly.
- **(Focus) Skip progress bar for objectives with arithmetic X/Y progress** — Objectives that show X/Y counts no longer display a redundant progress bar.
- **(Focus) Inline quest item button does not fade when scrolling past tracker bottom** — Item button now fades correctly when scrolled out of view.

### 🔧 Improvements

- **(Focus) Improve Abundance scenario tracker: widget parsing, progress bar labels, and bar visibility** — Better widget parsing, clearer progress bar labels, and improved bar visibility for Abundance scenarios.
- **(Focus) Deduplicate Rare Loot entries when multiple vignettes show the same treasure** — Same treasure from multiple vignettes now appears once in the Rare Loot list.

---

## [3.9.1] – 2026-03-07

### 🔧 Improvements

- **(Focus) Allow click-to-complete for auto-complete quests when using classic click behaviour** — Classic click behaviour now supports click-to-complete for auto-complete quests.
- **(Focus) Scope Abundance scenario widget fallback and bar styling to Abundance only** — Widget fallback and progress bar styling apply only to Abundance scenarios, not other scenario types.

---

## [3.9.0] – 2026-03-07

### ✨ New Features

- **(Focus) Rare Loot section** — Show treasure and item vignettes in a separate Rare Loot list with a toggle.
- **(Focus) TomTom waypoint when clicking rares or rare loot** — Set a TomTom waypoint when clicking a rare boss or rare loot item (requires TomTom addon; setting in options).
- **(Focus) RARE color** — Warm orange for rares and rare loot, distinct from Current Quest coral.
- **(Focus) Rare sound volume** — Slider to adjust rare alert volume (50–200%).

---

## [3.8.4] – 2026-03-07

### 🐛 Fixes

- **(Focus) Rare vignettes sometimes appear duplicated in Focus tracker** — Same rare creature from multiple vignette GUIDs now appears once; deduplicated by creature ID.

### 🔧 Improvements

- **(Vista) Mail icon can be unlocked and repositioned on minimap** — Option to unlock the mail indicator so it can be dragged and repositioned like the queue, tracking, and calendar buttons.
- **(Focus) Add Inline below title option to timer display dropdown** — Third timer display option: countdown always appears on its own line below the quest title instead of beside it.
- **(Focus) Abundance scenario bar turns green when full** — Progress bar turns green when abundance held reaches the target.
- **(Focus) Shift+Left-click opens or closes quest details; closes when already showing** — Toggle behaviour for quest details; closing when already open.
- **(Focus) Inline timer wraps to own line when narrow; layout reflows during resize** — Timer text wraps when panel is narrow; layout updates live during resize drag.

---

## [3.8.3] – 2026-03-06

### 🔧 Improvements

- **(Focus) Abundance scenario display improvements and scenario debug option** — Abundance scenario objectives (e.g. 46/300) now show correctly via widget fallback when C_ScenarioInfo returns percent-only; progress bar shows X/Y abundance held/bag; duplicate X/Y stripped in tracker and Presence toasts; new scenario debug logging toggle for diagnosing display issues.

---

## [3.8.2] – 2026-03-06

### 🔧 Improvements

- **(Focus) World quests in Current Event, auto-complete display, and quest map open fix** — World quests and callings in the quest area appear in Current Event; auto-complete quests show the turn-in prompt; quest map opens more reliably.
- **(Presence) Fix stale world quest count in Presence quest update toasts** — Quest update toasts now show accurate progress counts instead of outdated values.
- **(Core) Options dashboard redesign and options panel polish** — Centered layout, smooth scroll, cascade animations, shorter descriptions with tooltips, row hover highlight.

---

## [3.8.1] – 2026-03-06

### 🔧 Improvements

- **(Focus) World quest progress bar and objectives preserved when outside quest zone** — Progress bars and objective text remain visible when briefly leaving the zone (e.g. flying, hearth).

### 🐛 Fixes

- **(Insight) Tooltip font text comparison may error; add defensive pcall** — Prevents addon errors when processing tooltip text in edge cases.

---

## [3.8.0] – 2026-03-06

### ✨ New Features

- **(Focus) Sub-setting to filter progress bar by X/Y or percent-only objectives** — Dropdown under the progress bar toggle lets you show bars for X/Y objectives (e.g. 3/10), percent-only objectives (e.g. 45%), or both.
- **(Insight) NPC tooltips: reaction-colored border, level/classification/creature type, skull icon** — NPC tooltips now show a reaction-colored border, a single line with level (or skull for unknown), classification (Elite, Rare, etc.), and creature type (Humanoid, Beast, etc.).
- **(Focus) Rare boss tracking activated in Midnight** — Rares in Midnight zones (e.g. Zul'Aman) now appear in the tracker.

---

## [3.7.1] – 2026-03-05

### 🐛 Fixes

- **(Presence) Presence quest complete detection misses some localized strings** — Added ERR_QUEST_UNKNOWN_COMPLETE, QUEST_WATCH_QUEST_COMPLETE, and QUEST_WATCH_POPUP_QUEST_COMPLETE to the suppression check so quest complete notifications are not shown when the message matches these localized strings.

### 🔧 Improvements

- **(Focus) Event category transition re-sorts before fade-out completes** — Event quests moving between Current Event and Events in Zone now fade out from their current position, other rows slide, then the row fades in at its new position; no pre-animation snap to the new category order.

---

## [3.7.0] – 2026-03-05

### ✨ New Features

- **(Focus) Current Quest category with zone routing and animations** — Section at top with coral colour; quests with progress in the last minute (configurable 30–120 sec); expired quests route to Current Zone when in zone; fade-out and fade-in when moving between categories; horizontal fade-out for consistency.

### 🐛 Fixes

- **(Presence) Quest update toast missing quest name when quest is not super-tracked** — Non-super-tracked quests now show quest name and objective in the update toast.
- **(Focus) Skip percent calculation for single-objective quests in progress display** — Single-objective quests use discrete count instead of percent bar.

### 🔧 Improvements

- **(Focus) Use IsOnQuest for quest acceptance and preserve super-track when placing waypoints** — Authoritative quest acceptance check; waypoints no longer override quest super-track.
- **(Core) Options panel: default collapsed for advanced sections, header labels, persist sidebar group collapse** — Advanced sections collapsed by default; header labels; sidebar group collapse persisted.

---

## [3.6.7] – 2026-03-04

### 🐛 Fixes

- **(Focus) Objective progress bars fail to show when percent comes from text or type is progressbar** — Progress bars now appear for objectives that report percent via text or Blizzard progressbar type; single-objective (1/1) uses discrete count instead of bar.
- **(Presence) Quest acceptance detection fails in non-English locales** — Locale-safe keyword matching from Blizzard globals and addon translations; completion message matching strips trailing punctuation for locale variants.

### 🔧 Improvements

- **(Core) Reorganize Focus options into clearer categories** — Appearance, Sorting & Filtering, Animations, and Instances sections; renamed labels for clarity (e.g. Enemy forces size, Active instance only).

---

## [3.6.6] – 2026-03-04

### 🐛 Fixes

- **(Presence) Fix Presence debug function nil errors** — Quest update notifications and live debug no longer crash from undefined debug functions.

---

## [3.6.5] – 2026-03-04

### 🐛 Fixes

- **(Presence) Presence quest update notifications show duplicates or wrong text** — One notification per objective completion with correct text; no more duplicate popups or generic Blizzard messages.

### 🔧 Improvements

- **(Presence) Remove Presence debug logging** — Temporary debug output removed.
- **(Core) Options panel: refresh dependent widgets when parent toggle changes** — Dependent dropdowns and sliders update immediately when toggling options like Scroll indicator, Dim unfocused entries, or Rare sound alert.

---

## [3.6.4] – 2026-03-04

### 🔧 Improvements

- **(Focus, Presence) Fix scenario percentage display and delve completion notification subtitle** — Scenario criteria now show correct percentage values; delve completion toasts display the actual delve name instead of a generic fallback.

---

## [3.6.3] – 2026-03-03

### 🔧 Improvements

- **(Core) Options panel: class color accent and Delves and Dungeons section rename** — Tint the options panel accent with your class color; renamed Delves section to Delves and Dungeons with updated descriptions.
- **(Focus) Focus Delve tier sometimes wrong or missing in tracker** — Uses ScenarioHeaderDelvesWidget tierText for accurate tier display in delves.
- **(Focus) Focus tracker: improved collapse/expand behavior with grow-up header animations** — Clearer animated feedback when expanding/collapsing categories in grow-up layout.

---

## [3.6.2] – 2026-03-03

### 🔧 Improvements

- **(Focus) Right-click recipe to untrack and improved reagent display** — Crafting recipes can be untracked via right-click; reagent display improved.
- **(Focus) Show tracker in dungeons by default instead of hidden** — Tracker is visible in dungeons by default for easier objective tracking.

### 🐛 Fixes

- **(Focus) Apply combat fade alpha when tracker is shown in combat** — Tracker now respects combat fade when shown during combat.

---

## [3.6.0] – 2026-03-02

### ✨ New Features

- **(Focus) Sort ready-to-turn-in quests to bottom of Current Zone** — Completed quests in the Current Zone (Nearby) section sort to the bottom, keeping in-progress objectives visible at the top.
- **(Presence) Scenario and delve completion notification** — Cinematic toasts when completing a scenario or delve; delves show "Delve Complete" with name or tier, scenarios show "Scenario Complete".

### 🔧 Improvements

- **(Core) German (deDE) localization for options panel** — Options panel now fully translated into German.

### 🐛 Fixes

- **(Focus) World quest objectives show progress bars when the option is enabled** — World quest objectives now display progress bars like regular quests when the progress bar option is turned on.

---

## [3.5.0] – 2026-02-28

### ✨ New Features

- **(Presence) Achievement progress toast notifications** — Cinematic toasts when you make progress on tracked achievements (e.g. 50/300, 100/500), not only on completion.

### 🔧 Improvements

- **(Focus) Accurate delve tier display** — The tracker uses the correct API so the displayed tier matches what Blizzard considers active when in a delve.
- **(Focus) Instance name in dungeon scenario header** — Dungeon scenarios show the instance name (e.g. Blackrock Caverns) instead of blank or generic text.
- **(Focus) Restrict world quest fallback to bonus objectives only** — Zone events (bonus objectives) from the map appear in the tracker; unrelated task quests are excluded.
- **(Presence) Cleaner objective progress toasts** — Avoids duplicate numeric values when both quantity and text already contain the same info.

---

## [3.4.0] – 2026-02-28

### ✨ New Features

- **(Vista) All The Things minimap button can be tracked** — Add the All The Things minimap button to Vista's button bar.
- **(Focus) TomTom integration** — Click a quest in Focus to set TomTom's arrow to the next objective with distance display.
- **(Insight) Mount and All The Things info in character tooltips** — Character tooltips show the player's current mount and ATT collection data.

### 🔧 Improvements

- **(Presence) Option to hide "Quest Update" title on Presence toasts** — Show only the objective line without the redundant header.

### 🐛 Fixes

- **(Focus) Progress bar hides when objective is complete** — Bar no longer stays visible at full fill after completion.
- **(Presence) Event quest completion no longer shows 0/10 toast** — Completion state shown instead of a progress update.
- **(Focus) Quel'danas bonus objectives in Midnight intro now show in quest tracker** — Bonus objectives appear correctly during the phased intro.
- **(Focus) Quest tooltip no longer duplicates when in a party with All The Things** — Hover info shows once when in a party.
- **(Core) Settings search description displays fully on first open** — Clicking a search result no longer cuts off the description until you scroll.

---

## [3.3.1] – 2026-02-28

### 🔧 Improvements

- **(Core) Add Spanish (esES) locale for options panel** — Options panel now fully translated into Spanish; checkmark-for-completed option uses a texture icon for reliable display across locales and fonts.
- **(Insight) Strip health/power text and redundant Hero Talent line from unit tooltips** — Tooltip clutter reduced; Insight shows reaction and class info without duplicating stats; redundant Hero Talent line removed.

### 🐛 Fixes

- **(Focus) Quests in Ready to turn in section cannot be left-clicked to focus** — Left-click on turn-in quests now sets focus correctly so you get a waypoint to the turn-in NPC.

---

## [3.3.0] – 2026-02-27

### ✨ New Features

- **(Core) Unified slash command system with /h as primary shortcut** — Use /h, /hopt, and /hedit for help, options, and edit screen; module subcommands under /h focus, /h presence, and similar.
- **Beta can install alongside release** — Install both stable and beta versions simultaneously for testing without overwriting each other.

### 🔧 Improvements

- **(Focus) Events in Zone section label and event quest colour continuity** — Section renamed from "Available in Zone"; event quests keep their distinct colour when accepted and move to Current Zone.
- **(Core) Beta uses separate SavedVariable** — Profiles and settings stay separate between beta and release when running both.
- **(Insight) Suppress tooltip fade-in when refreshing unit tooltips** — Prevents animation flicker when the tooltip updates.

---

## [3.2.0] – 2026-02-27

### ✨ New Features

- **(Focus) Inline timer display mode and urgency-based timer coloring** — Show countdown timers beside quest titles or as bars; optionally color by remaining time (green, yellow, red).
- **(Focus) Alpha slider for progress bar and Mythic+ bar colors** — Make progress bars and M+ bars semi-transparent.
- **(Focus) Option to hide Focus tracker only in Mythic+** — Hide the tracker during Mythic+ runs while keeping it visible in normal, heroic, or mythic dungeons.
- **(Focus) Per-difficulty instance visibility** — Choose which dungeon and raid difficulties show the Focus tracker (normal, heroic, mythic, Mythic+ separately).
- **(Focus) Section dividers between categories** — Optional dividers with configurable color between tracker sections.
- **(Presence) Zone title color by zone type** — Zone text changes color by affiliation: green friendly, red enemy, yellow neutral, light blue sanctuary; toggle to enable.
- **(Presence) Option to disable Presence in battlegrounds** — Turn off zone and notification toasts during PvP matches.
- **(Core) Improve Brazilian Portuguese localization and enUS base template** — Additional ptBR translations; enUS template for creating new locale files.

### 🔧 Improvements

- **(Focus) Compact timer format for quests and scenarios** — Human-readable format (e.g. 2d 5h 30m, 45m 12s) instead of raw MM:SS.
- **(Focus) Backdrop opacity and shadow alpha sliders use 0–100%** — Finer control with integer steps while storing values internally.
- **(Focus) Untrack quest by re-clicking** — Defocus by clicking the same quest again.
- **(Focus) Options to desaturate or adjust alpha for dimmed non-focused quests** — Additional dimming controls beyond color.
- **(Focus) Completed nearby quests respect "Show nearby quests in their own group"** — Setting now applies consistently.
- **(Vista) Restore flash when unlocking mouseover bar** — Brief flash helps find the bar when repositioning.
- **(Insight) Tooltip polish** — Class-coloured separator lines, number formatting with commas, cursor tooltip clamping.
- **(Core) Options panel reorganization and Focus combat refresh** — Refined categories; tracker refreshes achievements, endeavors, decor, rares in combat.
- **(Core) Align core defaults and beta changelog sourcing** — Consistent out-of-box experience; beta workflow uses closed-issue filtering.

### 🐛 Fixes

- **(Focus) Typography shadow applies to section headers and quest titles** — Shadow on/off and X/Y offsets now affect all tracker text.
- **(Focus) Shadow offsets work with section headers and quest titles** — Typography shadow options apply correctly.
- **(Focus) Active Quest Highlight alpha, alignment, and outline** — Alpha slider has fine control; Highlight, Soft Glow, and Outline align with text.
- **(Focus) Section header text no longer clips at large font sizes** — Headers display fully when section font size is 16 or 18.
- **(Focus) LFG queue green eye shows and hides reliably** — Queue indicator visibility correct after moving tracker.
- **(Focus) Quest list height persists** — Vertical size setting no longer resets to default.
- **(Presence) Quest update text spacing** — Spacing matches other objective lines.
- **Missing scenario event timers** — World Soul Memory, Nightfall, Theater Troupe, Midnight Pre-Patch Rares now appear in tracker.

---

## [3.1.5] – 2026-02-25

### 🔧 Improvements

- **(Presence) Higher-priority notifications can interrupt current** — Level-up and achievements can preempt zone changes or quest accepts so important moments are never delayed by less important toasts.
- **(Core) Profile export strips machine-specific Vista button keys** — Exported profiles can be shared or imported without carrying per-machine minimap button state.
- **(Presence) Replace-in-queue for rapid same-type notifications** — Multiple quest or scenario updates replace the pending entry instead of stacking.
- **(Presence) Live update for quest and scenario progress** — Rapid objective updates appear as subtitle changes on the current toast instead of stacking in the queue.

### 🐛 Fixes

- **(Focus) Text case "Proper" with special characters** — Umlauts and European accented characters (ä, ö, ü, etc.) no longer incorrectly capitalize the following letter in German and other languages.

---

## [3.1.4] – 2026-02-25

### 🔧 Improvements

- **(Vista)** Removed duplicate variable declaration.

### 🐛 Fixes

- **(Vista)** Drawer button now opens panel when clicked in floating drawer mode.

---

## [3.1.3] – 2026-02-25

### 🔧 Improvements

- **(Vista) Configurable close delays** — Set how long the mouseover bar, right-click panel, and floating drawer stay open after the cursor leaves (0 = instant or never auto-close).
- **(Vista) Configurable background and border for mouseover button bar** — Customize color and optional border for the addon button bar.
- **(Vista) Reposition addon button bar discoverability** — Tooltip and option description explain how to drag the bar to reposition when unlocked.

---

## [3.1.2] – 2026-02-24

### 🔧 Improvements

- **(Vista)** Allow minimap pin tooltips to show when hovering over pins.

---

## [3.1.1] – 2026-02-24

### 🔧 Improvements

- **(Presence) Presence frame scale up to 2x** — Users can make notifications larger on high-DPI displays.
- **(Focus) Tracker max height fix for grow-up mode** — Correct max height when the tracker grows upward from the bottom.

### 🐛 Fixes

- **(Vista)** Minimap can be dragged when unlocked, even with right-click panel mode overlay enabled.

---

## [3.1.0] – 2026-02-24

### ✨ New Features

- **(Vista) Option for buttons per row/column and expand direction** — Choose how many addon buttons per row before wrapping and which direction they fill (right, left, down, up).
- **(Vista) Option to disable queue button handling** — Turn off Vista's queue status button anchoring when another addon manages it or you prefer Blizzard's placement.
- **(Vista) Draggable right-click panel with lock option** — Drag the addon button panel to reposition; lock toggle prevents accidental movement.
- **(Vista) Draggable difficulty text with lock option** — Drag Mythic/Heroic/Normal text to reposition; lock toggle in options.
- **(Vista) Option to set coordinate precision (0, 1, or 2 decimal places)** — Choose how many decimal places for X and Y coordinates.
- **(Focus) Option to use left-click for quest map and right-click for share/abandon on tracker quests** — Restore classic click behavior via a toggle.
- **(Vista) Color difficulty text by difficulty with customizable colors** — Per-difficulty color pickers (e.g. Mythic purple, Heroic red).
- **(Vista) Option to select zone display: general zone, subzone, or both** — Show zone only, subzone only, or both (e.g. Stormwind with Trade District below).
- **(Vista) Option to select which addon buttons are managed vs always visible** — Mark buttons as always visible (e.g. Plumber expansion summary) or managed in the mouseover bar.
- **(Vista) Separate addon button mouseover bar from zone text position** — Position zone text and addon buttons independently (e.g. zone at top, buttons at bottom).
- **(Vista) Option to change the size of the difficulty text** — Scale or resize Mythic/Heroic/Normal text.

### 🔧 Improvements

- **(Vista) Correct zone/subzone display for interior zones** — Zone text shows the correct location in interior zones (e.g. inside buildings).
- **(Vista) Suppress minimap ping when right-clicking to open addon panel** — Right-click opens the panel without pinging the minimap.
- **(Focus) Option to change header divider color** — Customize the Focus tracker header divider color.

### 🐛 Fixes

- **(Vista) Minimap addon button gold borders misaligned after changing button size** — Gold borders stay aligned with buttons at any configured size.
- **(Vista) Border thickness slider drops FPS from 74 to 10 when dragging** — Slider no longer causes severe FPS drops.
- **(Core) Options pane scrolls infinitely and does not stop at end of list** — Scroll stops at the end of the options list.
- **(Focus) Queue status tracker appears only in dungeon and persists after leaving** — Queue/LFG status shows when queued and hides when no longer relevant.
- **(Vista) Option to use local time in Vista clock** — Clock can display local time instead of server time.
- **(Focus) Right-click to abandon quest only untracks when World Quest Tracker (WQT) is enabled** — Abandon behavior works correctly with WQT enabled.

---

## [3.0.2] – 2026-02-24

### 🔧 Improvements

- **(Vista) Zone, coordinates, and clock above or below minimap** — Choose to place zone name, coordinates, and clock above or below the minimap in Vista options.
- **(Focus) Scenario bars match progress bar styling** — Timer and progress bars in scenarios now use the same font, colors, and height as quest objective progress bars.
- **(Presence) More reliable notification display** — Level-up, boss emotes, and scenario toasts display correctly when event frames load.

---

## [3.0.1] – 2026-02-23

### 🐛 Fixes

- **Dev addon fix.**

---

## [3.0.0] – 2026-02-23

### ✨ New Features

- **(Vista) Minimap sizing and free positioning.**
- **(Vista) Minimap border thickness and visibility control.**
- **(Vista) Replace MinimapButtonButton/Hiding bar with built-in opt-out list of addon buttons to show.**
- **(Vista) Zone text control: position, background color and visibility, font size, font.**
- **(Vista) Coordinates text: position and styling; optional format (decimal precision, X/Y prefixes).**
- **(Vista) Time/clock text: same controls as coords; optional format options.**
- **(Vista) Default map button visibility, position, size, and custom icons.**
- **(Presence) Per-type toggles for Presence notifications.**
- **(Core) Options panel localization for Russian (ruRU)** — Options panel is now fully translated into Russian.

---

## [2.6.1] – 2026-02-23

---

## [2.6.0] – 2026-02-23

### ✨ New Features

- **(Presence) Option to show only subzone when staying in same major zone** — Zone notifications display the local area name instead of the full zone when moving between subzones within the same zone.
- **(Vista) Square minimap option** — Choose a square minimap shape in Vista options.

### 🔧 Improvements

- **(Focus) Improve tracker performance and responsiveness.**
- **(Core) Option to scale Horizon Suite when WoW UI scale is lowered** — Scale addon elements independently so they remain readable at different game UI scale settings.

### 🐛 Fixes

- **(Focus)** Quest tracker no longer triggers errors when quest rows fade out during combat.

---

## [2.5.0] – 2026-02-22

### ✨ New Features

- **(Focus) Scroll indicators when quest list is truncated** — Arrows or fade at top and bottom show when more content is available above or below.
- **(Focus) Dungeon journal objectives in tracker** — Objectives tracked via the dungeon journal (checkmarked in the journal UI) now appear in the Focus tracker.
- **(Focus) Achievement progress tracking** — Tracked achievements with numeric goals (e.g. harvest 250 lumber) now show live progress (e.g. 1/250, 200/250) in the tracker.
- **(Presence) Setting to disable quest update notifications** — Option to turn off quest objective progress toasts (e.g. "Boar Pelts: 7/10") so they no longer distract during dungeons.
- **(Focus) Option to always show Campaign and Important quests in their own categories** — Keep purple triangle quests in dedicated sections even after completion instead of moving to Current Zone or Ready to Turn In.
- **(Focus) Font selector options for header, sections, and quest titles** — Customize typography for each element in the Typography section.
- **(Focus) Preview mode for the M+ block** — Configure and position the Mythic+ block without being inside an active key.
- **(Focus) Find group button for group quests** — Quick access to Group Finder for group quests in the tracker.
- **(Focus) Option to show quest objective progress as a bar** — Display progress (e.g. 3/10, 45%) as a visual bar instead of raw numbers.

### 🔧 Improvements

- **(Focus) Objective progress bar toggle animates like other options** — Panel refresh is deferred so the toggle animates consistently with other toggles.
- **(Core) Localization for typography font options in French, Korean, and Portuguese (Brazil)** — Title font, zone font, objective font, and section font labels are now localized.
- **(Focus) Tracker mouseover detection and options panel UI** — Reliable hover detection over child frames; title bar drag only from the bar; section cards reset on open; improved toggle and dropdown styling.
- **(Focus) Restructured options into clearer categories** — Panel, Display, Typography, Behaviour, Mythic+, Delves, and Content Types as dedicated sections.
- **(Focus) Separate fonts for quest title, quest text, and zone text** — Choose different fonts for each element in the Typography section.

### 🐛 Fixes

- **(Focus)** Floating quest item button and per-entry quest item buttons now appear when quests have usable items.
- **(Focus)** Dungeon eye icon now shows for world boss group finder entries.
- **(Focus)** Disable world quests option now works correctly when World Quest Tracker is enabled.
- **(Focus)** Achievements with many objectives no longer get cut off in the tracker.
- **(Focus)** Category prefix now renders as a dash instead of a square across fonts.
- **(Focus)** Quest items with cooldowns now update correctly when used in combat.

---

## [2.4.0] – 2026-02-21

### 🔧 Improvements

- **(Presence)** Suppress zone changes in Mythic+ and combat lockdown guards — New option under Presence → Notification types. When enabled, zone, quest, and scenario notifications are hidden during M+ runs. Frame Hide/Show and drag handlers are guarded during combat across Focus, Cache, and Options.

### 🐛 Fixes

- **(Focus)** Tracker collapse/expand no longer causes errors during combat.
- **(Presence)** Zone name and completion percentage no longer spam during Mythic+ runs.

---

## [2.3.0] – 2026-02-21

### ✨ New Features

- **(Focus) Raid quest category in tracker** — Raid quests now appear in their own red section in the Focus tracker, distinct from dungeon quests.
- **(Focus) Full profile support with import/export, per-spec and global account modes** — Create, switch, copy, and delete named profiles. Use per-character, per-specialization, or global (account-wide) modes. Import and export profiles as shareable text strings in the Profiles options section.

### 🔧 Improvements

- **(Focus) Auto-track icon choice for in-zone entries** — Choose which radar icon to display next to auto-tracked world quests and weeklies/dailies that are not yet in your quest log (in-zone only).
- **(Core) Panel backdrop colour and opacity** — Customize the tracker panel background colour and opacity in the Visuals options.

### 🐛 Fixes

- **(Core)** Debug command no longer errors when counting quests by log index.

---

## [2.2.0] – 2026-02-21

### ✨ New Features

- **(Focus) Option to fade objectives during combat instead of fully hiding them** — Objectives remain visible but partially transparent in combat; opacity returns to normal out of combat.

### 🔧 Improvements

- **(Core) Changelog sections use emoji icons for quicker scanning** — Section headers now have emoji prefixes for visual distinction.
- **(Core) Update credits section with French localization contributor and development attribution** — Credits now list Aishuu for French localization and development attribution for feanor21.
- **(Core) Add Presence notification strings to French and Korean localization** — Level-up, achievement, quest complete, and other Presence notification text is now localized for French and Korean.
- **(Core) Improve French localization clarity and consistency in options panel** — French labels and tooltips are clearer and align better with game terminology.

### 🐛 Fixes

- **(Core)** Beta release workflow no longer crashes when creating the beta tag.
- **(Core)** SharedMedia_Noto fonts now appear in the font dropdown alongside other SharedMedia fonts.

---

## [2.1.0] – 2026-02-21

### ✨ New Features

- **(Core) Search bar in font dropdown** — Filter fonts by typing in the Typography section when many fonts are available.
- **(Focus) Tracker fades by default and appears on mouseover** — Tracker is hidden by default and shows when you hover over it.

### 🔧 Improvements

- **(Core) French localization for options panel** — Options panel displays all labels, descriptions, and section headers in French when the player's client is set to French.
---

## [2.0.4] – 2026-02-21

### 🐛 Fixes

- **(Focus)** Font selection in Typography section now updates the displayed font immediately.
---

## [2.0.3] – 2026-02-21

### 🐛 Fixes

- **(Focus)** M+ block no longer triggers protected frame errors during Mythic+ runs.
---

## [2.0.2] – 2026-02-21

### ✨ New Features

- **(Cache) Cinematic loot notifications module** — Items, money, currency, and reputation gains appear as styled toasts with quality-based colours and smooth animations. Epic and legendary loot get extra flair. Enable in options; use `/horizon cache` for test commands.

### 🐛 Fixes

- **(Core)** Font selection now persists after reload, log out, or game exit.
---

## [2.0.1] – 2026-02-20

### 🔧 Improvements

- **(Presence) Presence module enabled by default for new installs** — New users get the full Horizon Suite experience (cinematic zone text, quest notifications, achievements, etc.) immediately after install. Users migrating from the legacy Vista module have their previous enabled/disabled preference preserved.
---

## [2.0.0] – 2026-02-20

### ✨ New Features

- **(Presence) Configurable colors, animations, and subtitle transitions for Presence notifications** — Tailor the look and feel of Presence toasts to match your UI theme. Per-type colors for boss emotes, discovery lines, and other categories; configurable animations; smooth subtitle fade when multi-line notifications update.
- **(Focus) Show achievement progress for numeric objectives in tracker** — Tracked achievements with numeric goals (e.g., collect 300 decors) now display current progress (e.g. 247/300) in the tracker at a glance.
---

## [1.2.4] – 2026-02-20

### ✨ New Features

- **(Presence) Delve and scenario objective progress toasts** — Objective updates in Delves, party dungeons, and other scenarios now show Presence toasts (e.g. "Slay enemies 5/10").
- **(Focus) Separate Hide in dungeons from M+ timer** — You can now hide the tracker in dungeons independently of the Mythic+ timer block.
- **(Focus) Show unaccepted quests in the current zone** — Quests available to accept in your current zone appear in the tracker.
- **(Focus) Scenario start notification** — Entering a Delve, scenario, or dungeon triggers a Presence notification.
- **(Focus) Deaths in M+ block** — The Mythic+ module now displays death count.
- **(Focus) Separate font, size, and color for M+ module** — Typography for the M+ block can be customized separately from the main tracker.

### 🔧 Improvements

- **(Core) Add missing non-options strings to koKR locale** — Strings in modules (Focus, Presence) are now in koKR so Korean users can fork and translate.
---

## [1.2.3] – 2026-02-20

### 🐛 Fixes

- **(Core)** En Dash character now renders correctly in the Korean WoW client for collapsible color groups in options.
---

## [1.2.2] – 2026-02-20

### ✨ New Features

- **(Focus) Show season affix names in Delves on quest list entries** — Delve entries now display season affixes and tier (e.g. Tier 5) in the tracker, with an option to toggle and tooltips for tier and affix details.
---

## [1.2.1] – 2026-02-20

### 🔧 Improvements

- **(Focus) M+ timer verification, debug cleanup, and localization** — Follow-up polish from recent Mythic+ and world quest improvements.
---

## [1.2.0] – 2026-02-19

### ✨ New Features

- **(Focus) Per-objective progress (e.g. 15/18) on individual objectives** — Objectives with multiple instances (e.g. "Pressure Valve fixed", "Cache and Release" valves) now display numeric progress when the game provides it, so you can see partial completion at a glance.
- **(Focus) Configurable fading animations and smoother transitions** — Adjust flash intensity (subtle, medium, strong) and optionally customize the flash color when objectives update; collapse/expand transitions are smoother.
- **(Focus) Option to show tick instead of green color for completed objectives** — Toggle to display a checkmark instead of color for completed objectives, for easier scanning or different color schemes.
- **(Focus) Setting to hide or show the options button.**
- **(Core) Add Korean language support.**

### 🔧 Improvements

- **(Focus) Hovering quest objectives now shows party member progress** — Parity with default UI tooltip.
- **(Focus) Option for a current-zone quest item button that can be keybound** — ExtraQuestButton-style: use without clicking.

### 🐛 Fixes

- **(Focus) Focus Tracker — ADDON_ACTION_BLOCKED** — Fixed error when changing options during combat; dimension changes are now deferred until after combat.
- **(Focus) Scenario and Delve objectives now show per-objective progress (e.g. 0/5 Workers rescued)** — Objectives from Delves, scenarios, and dungeons now display the correct count.
- **(Focus) Options to set header color and header height.**
---

## [1.1.5] – 2026-02-19

### ✨ New Features

- **(Focus) Option to fade or hide completed quest objectives** — Completed objectives (e.g. 1/1) can be faded or hidden so remaining tasks are visible at a glance.

### 🐛 Fixes

- **(Core)** Beta Release Action now runs correctly; release zipping and workflow updated.
- **(Focus)** Click to complete quest in old content (no turn-in NPC) now works; users no longer need to disable the addon to complete those quests.
---

## [1.1.4] – 2026-02-16

### ✨ New Features

- **(Focus) Quest text adapts to tracker height** — Full text shows or hides based on available space when the tracker is short.
- **(Vista)** Game reports addon action no longer blocked when opening the World Map.
- **Setting to hide or show the drag-to-resize handle** — Option for the bottom-right corner of the quest list.

### 🐛 Fixes

- **(Focus)** Quest titles with apostrophes no longer show wrong capitalization (e.g. "Traitor'S Rest").
- **(Core)** Version number in settings window now matches the addon version.
- **(Presence)** Quest update bugs fixed: race conditions causing 0/X display, intermediate progress numbers, and suppressed completion toasts.
- **(Focus)** World quest zone labels corrected; in-zone redundancy and off-map missing labels fixed.
- **(Core)** Font dropdown is now scrollable so fonts below the fold can be selected.
- **(Focus)** SharedMedia compatibility added so addons and custom fonts can be used across the suite.
---

## [1.1.3] – 2026-02-15

### ✨ New Features

- **(Focus) In-zone world quests, weeklies and dailies** — Shown when in zone; right-click untracks and hides until zone change (not subzone). Option in Display → List to show a suffix for in-zone but not yet in log.

### 🔧 Improvements

- **(Focus) Tracked WQs and in-log weeklies/dailies** — Now sort to the top of their section.
- **(Focus) Promotion animation** — Only the promoted quest fades out then fades in at the top; fixed blank space until next event.
- **(Focus) Right-click on world quests** — Untracks only (no abandon popup); Ctrl+right-click still abandons.

### 🐛 Fixes

- **(Focus) Category reordering** — Drop target now matches cursor; auto-scroll direction when dragging near top or bottom corrected.
---

## [1.1.2] – 2026-02-15

### 🐛 Fixes

- **(Focus)** Game sounds no longer muted or clipped when endeavor cache primes at login.
---

## [1.1.1] – 2026-02-14

### ✨ New Features

- **(Focus) Auto-track accepted quests** — Accepted quests are now automatically added to the Focus tracker. You can enable or disable this in Organization -> Behaviour.

### 🔧 Improvements

- **(Focus) Endeavor tooltip rewards** — Endeavor hover tooltips now use the panel-style layout and include House XP with the chevron icon in the rewards section.

### 🐛 Fixes

- **UI taint errors** — Fixed taint errors that could appear when opening Blizzard panels such as Character Frame and Game Menu.
- **(Focus) Shift+Right-click abandon** — Confirm abandon now works correctly when using Shift+Right-click on quests.
---

## [1.1.0] – 2026-02-14

### ✨ New Features

- **(Focus) Decor tracking** — Track Decor items in the Focus list. Shows item names; left-click opens the catalog; Shift+Left-click opens the map to the drop location.
- **(Focus) Endeavor tracking** — Track Endeavors in the Focus list. Names load on reload without opening the panel; left-click opens the housing dashboard.
- **(Focus) Achievement requirements display** — Option to only show missing requirements for tracked achievements; completed criteria are shown in green.

### 🔧 Improvements

- **(Focus) Spacing slider** — Slider in Display → Spacing to adjust the gap below the objectives bar (0–24 px), preventing the first line from being cut off.
- **(Focus) Dim non-focused quests** — Display option to dim full quest details and section headers for non-focused quests.

### 🐛 Fixes

- **(Focus)** World quests no longer remain in the tracker after changing zones (e.g. hearthing to another zone).
- **(Focus)** Confirm abandon quest now works when using Shift+Right-click.
---

## [1.0.6] – 2026-02-14

### 🐛 Fixes

- **(Focus)** Quest text (objectives, timers) now updates during combat — Content-only refresh runs when ScheduleRefresh is requested in combat.
- **(Presence)** Quest progress and kills in combat now show Presence toasts — Removed combat lock in QueueOrPlay so progress and kills (e.g. Argent Tournament jousting) appear.
---

## [1.0.5] – 2026-02-14

### ✨ New Features

- **(Focus) Super-compact mode — options and collapse** — Super-minimal mode now has a thin bar with expand/collapse and a compact "O" options button. Objectives can be opened when "Start collapsed" is set.
---

## [1.0.4] – 2026-02-14

### 🔧 Improvements

- **Focus — Quest-area world quests when option is off** — When "Show in-zone world quests" is disabled, the tracker still shows WQs when you physically enter their quest area (distance-based proximity using C_TaskQuest.GetQuestLocation, matching default Blizzard behavior). Zone-wide WQs remain hidden.
- **Presence — Colours and quest-type icon aligned with Focus** — Presence notifications now use the same colour palette and options as Focus. Quest Complete and Quest Accept colours are driven by quest type (campaign, world, default, etc.); Achievement uses Focus bronze; World Quest uses Focus purple; Quest Update uses Nearby blue; zone/subzone use default title and campaign gold subtitle. Boss emote uses a dedicated red in Config. When "Show quest type icons" is enabled in options, quest-related Presence toasts (accept, complete, world quest) show the same quest-type icon as the Focus tracker.

### 🐛 Fixes

- **Focus Tracker — ADDON_ACTION_BLOCKED** — Fixed error when `HSFrame:Hide()` was called during combat. Protected Hide() calls are now guarded by InCombatLockdown() and deferred until PLAYER_REGEN_ENABLED.
---

## [1.0.3] – 2026-02-13

### ✨ New Features

- **Quest header count** — Option to show quest count as tracked/in-log (e.g. 4/19, default) or in-log/max-slots (e.g. 19/35). Uses `isHidden` for an accurate in-log count.

### 🔧 Improvements

- **Focus — Granular spacing options** — Vertical gaps are now user-configurable via sliders in Display → Spacing: between quest entries (2–20 px), before and after category headers (0–24 px, 0–16 px), and between objectives (0–8 px). Compact mode applies a preset (4 px entries, 1 px objectives).
- **Presence — World Quest Accept** — World quest accepts now use a dedicated purple-style notification type (`WORLD_QUEST_ACCEPT`) instead of sharing the standard quest accept style.
---

## [1.0.2] – 2026-02-13

### ✨ New Features

- **Track specific world quests when WQs are off** — Watch-list and super-tracked world quests now appear in the tracker even when the general world quests option is disabled. You can turn off auto-added zone WQs while still seeing the ones you explicitly track.

### 🔧 Improvements

- **Mythic+ design** — Improved M+ block layout and styling in the Focus tracker.

### 🐛 Fixes

- **Focus Tracker — per-category collapse** — Section header collapse (clicking category headers like Campaign, World Quests) no longer delays or flickers. The collapse animation starts immediately and section headers stay visible during the animation.
- **Focus Tracker — main collapse** — Main tracker collapse behaviour refined: ensures the update loop runs when toggling collapse, and section headers display correctly when a single category is collapsed.
---

## [1.0.1] – 2026-02-13

### 🐛 Fixes

- **Focus Tracker — completed achievements** — The tracker no longer clutters the list with achievements you’ve already finished. Completed achievements are hidden by default; you can turn on “Show completed achievements” in options if you want to see them.
- **Focus Tracker — collapse** — Collapsing the tracker now behaves correctly: the collapse animation starts right away, section headers stay visible while it animates, and a single category still shows its header when collapsed.
---

## [1.0.0] – 2026-02-13

### ✨ New Features

- **Modular architecture** — Horizon Suite is now a core addon with pluggable modules. The Focus (objective tracker) is the first module. A new **Modules** category in options lets you enable or disable each suite. Use `/horizon toggle` or Options → Modules → Enable Focus module to turn the tracker on or off. Additional suites will appear as modules in the same options panel. SavedVariables remain compatible; existing installs default to Focus enabled.
- **Presence module** — Cinematic zone text and notifications. Replaces default zone/subzone text, level-up, boss emotes, achievements, quest accept/complete/update, and world quest banners with styled notifications. Priority queueing, smooth entrance/exit animations, and "Discovered" lines for zone discoveries. Enable in Options → Modules → Enable Presence module. Test with `/horizon presence` (e.g. `/horizon presence zone`, `/horizon presence all`). Blizzard frames are fully restored when Presence is disabled. (Renamed from Vista; `/horizon vista` is now `/horizon presence`.)

### 🔧 Improvements

- **Performance optimizations** — Reduced CPU usage by replacing per-frame OnUpdate with event-driven logic and timers: scenario heartbeat and map check now use C_Timer tickers; main tracker OnUpdate runs only when animating or lerping; Presence OnUpdate runs only during cinematics; scenario timer bars use a shared 1s tick instead of per-bar updates; options toggle OnUpdate runs only during its short animation.
- **Options panel UX overhaul** — Cinematic, modern, minimalistic redesign: softer colour palette with low-contrast borders and dividers; pill-shaped search input; taller sidebar tabs with hover states; minimal X close button; section cards with inset backgrounds; refined toggles, sliders, dropdowns, and colour swatches; subtle dividers between colour-matrix sections; consistent hover feedback on buttons and tabs.
- **Search bar redesign** — Custom-styled search input without Blizzard template: search icon (spyglass) on the left, integrated clear button (visible only when typing), subtle focus state with accent-colour border, and tighter visual connection to the results dropdown.
---

## [0.7.1] – 2026-02-13

### 🔧 Improvements

- **Zone labels** — Refined how quest zone names are chosen so objectives show clearer, more accurate zone labels, especially when quests span parent/child maps.
- **Mythic+ integration** — Improved how Mythic+ objectives and blocks behave in the tracker and options, with clearer descriptions and more consistent behaviour.
- **Options usability** — Polished several option labels and descriptions (including Mythic+ and zone-related settings) to better explain what they do and how they interact.
- **Options panel overhaul** — Fixed search so clicking a result now switches to the correct category and scrolls to that setting. Settings are reorganized into eight categories (Layout, Visibility, Display, Features, Typography, Appearance, Colors, Organization) for easier discovery. Toggles use a rounded pill style; search results show category and section with the option name emphasised.
- **World quest map fallback removed** — World quests are now sourced only from live APIs (`GetTasksTable`, `C_QuestLog.GetQuestsOnMap`, `C_TaskQuest` map APIs, and waypoint fallback) without requiring the world map to be open. The previous map-open cache and heartbeat fallback have been removed.
---

## [0.7.0] – 2026-02-13

### 🔧 Improvements

- **Version 0.7.0** — Release bump.
---

## [0.6.9] – 2026-02-13

### ✨ New Features

- **Nearby group toggle** — Toggle to show or hide the nearby group section, with key binding support. Key bindings can be set in the game’s Key Bindings → AddOns → Horizon Suite. Animation and behaviour for the nearby group section have been enhanced.
- **Dungeon support** — Quest tracking now supports Dungeon quests so dungeon objectives appear correctly in the tracker.
- **Delve support** — Delve quests are supported with updated event handling so Delve objectives are tracked and displayed.

### 🔧 Improvements

- **Floating quest item button** — Styling, text case options, and UI layout improved. Button behaviour and layout (e.g. icon, label, progress) are more consistent and configurable.
- **Quest caching** — Quest ID retrieval and caching logic refactored for better reliability. Event handling and debugging around quest updates have been improved.
- **README** — Documentation revised for clarity and formatting.
---

## [0.6.6] – 2026-02-11

### ✨ New Features

- **Weekly quests** — New category for weekly (recurring) quests with its own section in the tracker. Weekly quests in your current zone are auto-added like world quests. Quest classification now uses a single source of truth for determining world quests.
- **Daily quests** — Daily quests are supported with their own section and labeling. Daily quests in your current zone are auto-added to the tracker. Quests that are available to accept but not yet accepted show an **"— Available"** label.
- **Focus sort mode** — In Options → Categories, you can choose how entries are ordered within each category: **Alphabetical**, **Quest Type**, **Zone**, or **Quest Level**. A new options section controls sorting within categories.

### 🔧 Improvements

- **Quest caching** — Quest caching logic improved for your current zone and parent maps so quests display correctly without needing to open the map first.
- **Quest bar layout** — Left offset for quest bars adjusted for more consistent layout.
- **Database refactor** — All references updated from `HorizonSuiteDB` to `HorizonDB` for consistency. Options panel and quest tracking aligned to the new saved variable name; TOC and changelog updated accordingly.
---

## [0.6.5] – 2025-02-10

### ✨ New Features

- **Hide in combat** — New option in General (Combat section): when enabled, the tracker panel and floating quest item button are hidden while in combat. When combat ends, visibility is restored according to your existing settings (instance visibility, collapsed state, quest content). When **Animations** is enabled, the tracker and floating button fade out over ~0.2s on entering combat and fade in on leaving combat.
- **Focus category order** — The order of categories in the Focus list (Campaign, World Quests, Rares, etc.) can now be customised. In the options popout (Appearance), reorder categories via drag-and-drop; the new order is saved and used for section headers and section header colors. Use "Reset order" to restore the default order.

### 🔧 Improvements

- **Settings panel** — The options/settings UI has been updated for clearer layout and easier navigation.
- **New settings** — A range of new options have been added across General, Appearance, and other sections so you can tailor the tracker and behaviour to your preference.
---

## [0.6] – 2025-02-09

### ✨ New Features

- **World quest tracking** — World quests in your current zone now appear in the tracker automatically, using both `C_QuestLog` and `C_TaskQuest` data. No need to track every WQ manually.
- **Cross-zone world quest tracking** — World quests you track via the map watch list stay in the tracker when you leave their zone. They are shown with an **[Off-map]** label and their zone name. Use **Shift+click** on a world quest entry to add it to your watch list so it appears on other maps.
- **World map cache** — Opening the world map caches quest data for the viewed map and your current zone. World quests appear more reliably and update when you change map or close the map.
- **Map-close sync** — Closing the world map after untracking world quests there updates the tracker immediately so untracked WQs are removed.
- **Per-category collapse** — Section headers (Campaign, World Quests, Rares, etc.) can be clicked to collapse or expand that category. Collapse state is saved per category. Collapsing uses a short staggered slide-out animation.
- **Combat-safe scrolling** — Mouse wheel scrolling on the tracker is disabled during combat to avoid taint.

### 🔧 Improvements

- **Focus category reorder UX** — The category order list in options now uses live drag-and-drop: a ghost row follows the cursor, an insertion line shows the drop position, the list auto-scrolls when dragging near the edges, and Reset order updates the list immediately. All Focus groups (Campaign, Important, Quests, etc.) are always shown.
- **Nearby quest detection** — Parent and child maps are considered when finding “nearby” quests, so quests in subzones and parent zones are included.
- **Active task quests** — Quests from `C_TaskQuest.IsActive` (e.g. bonus objectives, invasion points) are shown in the tracker under World Quests.
- **Zone change behaviour** — World quest cache is cleared on major zone changes (`ZONE_CHANGED_NEW_AREA`) but kept when moving between subzones, reducing flicker when moving within a zone.
- **Delayed refresh** — An extra refresh runs 1.5s after login and after zone changes so late-loading quest data is picked up.

### 🐛 Fixes

- **TOC** — Version set to 0.6. SavedVariables corrected to a single line: `HorizonDB`.
- **Debug overlay removed** — The development-only world quest cache indicator (bottom-left of screen when the map was open) has been removed from release builds.
- **World map hook polling** — Reduced from 30 retry timers to 5 when waiting for the world map to load; map show/hide hooks no longer reference the removed indicator.

### Technical

- World quest data flow uses `C_QuestLog.GetQuestsOnMap`, `C_TaskQuest.GetQuestsForPlayerByMapID`, and optional `WorldQuestDataProviderMixin.RefreshAllData` hook when available.
- Per-category collapse state is stored in `HorizonDB.collapsedCategories`.
---

## [0.5] and earlier

Initial release and earlier versions. See README.md for full feature list.
